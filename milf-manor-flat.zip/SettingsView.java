package com.neighborvn;

import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

/** Настройки в стиле оригинала: розовая панель, ползунки, выпадающий список, переключатели. */
final class SettingsView extends View {
    private final MainActivity a;
    private final GameState gs;
    private final boolean fromMap;
    private final RectF titleR = new RectF(), panelR = new RectF(), musicR = new RectF(), sfxR = new RectF(),
            langR = new RectF(), tutR = new RectF(), resetR = new RectF(), heartsT = new RectF(),
            hintsT = new RectF(), backR = new RectF();
    private int drag = -1;
    private Paint bgP;

    SettingsView(MainActivity a, boolean fromMap) {
        super(a);
        this.a = a;
        this.gs = a.gs;
        this.fromMap = fromMap;
    }

    void back() {
        a.closeOverlay();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        bgP = new Paint();
        bgP.setShader(new LinearGradient(0, 0, w, h, 0xFF3B1F4F, 0xFF1F2A44, Shader.TileMode.CLAMP));
        panelR.set(w * 0.31f, h * 0.19f, w * 0.70f, h * 0.80f);
        titleR.set(w * 0.33f, h * 0.08f, w * 0.68f, h * 0.20f);
        float x0 = panelR.left + panelR.width() * 0.25f, x1 = panelR.right - panelR.width() * 0.08f;
        musicR.set(x0, h * 0.27f, x1, h * 0.31f);
        sfxR.set(x0, h * 0.37f, x1, h * 0.41f);
        langR.set(x0, h * 0.47f, x1, h * 0.54f);
        tutR.set(panelR.left + panelR.width() * 0.08f, h * 0.58f, panelR.right - panelR.width() * 0.08f, h * 0.645f);
        resetR.set(panelR.left + panelR.width() * 0.08f, h * 0.655f, panelR.right - panelR.width() * 0.08f, h * 0.72f);
        float ts = h * 0.07f;
        heartsT.set(panelR.left + panelR.width() * 0.08f, h * 0.725f, panelR.left + panelR.width() * 0.08f + ts, h * 0.725f + ts);
        hintsT.set(panelR.centerX() + panelR.width() * 0.02f, h * 0.725f, panelR.centerX() + panelR.width() * 0.02f + ts, h * 0.725f + ts);
        backR.set(w * 0.41f, h * 0.84f, w * 0.59f, h * 0.94f);
    }

    private void slider(Canvas c, RectF r, float v, String icon, int h) {
        c.drawRoundRect(r, r.height() / 2f, r.height() / 2f, Ui.fill(0xFFFFFFFF));
        RectF f = new RectF(r.left, r.top, r.left + r.width() * v, r.bottom);
        c.drawRoundRect(f, r.height() / 2f, r.height() / 2f, Ui.fill(0xFFA99BCB));
        c.drawRoundRect(r.left + r.width() * v - r.height() * 0.3f, r.top - r.height() * 0.2f,
                r.left + r.width() * v + r.height() * 0.3f, r.bottom + r.height() * 0.2f,
                r.height() * 0.2f, r.height() * 0.2f, Ui.fill(0xFFB06AE0));
        Ui.centerText(c, icon, r.left - panelR.width() * 0.1f, r.centerY(), Ui.text(0xFFFFFFFF, h * 0.07f, false));
    }

    private void toggle(Canvas c, RectF r, boolean on, String label, int h) {
        c.drawRoundRect(r, r.width() * 0.22f, r.width() * 0.22f, Ui.fill(0xFFFFFFFF));
        Paint st = new Paint(Paint.ANTI_ALIAS_FLAG);
        st.setStyle(Paint.Style.STROKE);
        st.setStrokeWidth(r.width() * 0.06f);
        st.setColor(0xFFB06AE0);
        c.drawRoundRect(r, r.width() * 0.22f, r.width() * 0.22f, st);
        if (on) {
            Paint f = Ui.fill(0xFFB06AE0);
            for (int k = 0; k < 2; k++) {
                c.save();
                c.rotate(k * 45f, r.centerX(), r.centerY());
                float q = r.width() * 0.26f;
                c.drawRoundRect(r.centerX() - q, r.centerY() - q, r.centerX() + q, r.centerY() + q, q * 0.3f, q * 0.3f, f);
                c.restore();
            }
        }
        android.text.TextPaint tp = Ui.text(0xFF8A3F7F, h * 0.04f, true);
        tp.setTextAlign(Paint.Align.LEFT);
        Paint.FontMetrics fm = tp.getFontMetrics();
        c.drawText(label, r.right + r.width() * 0.2f, r.centerY() - (fm.ascent + fm.descent) / 2f, tp);
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawRoundRect(panelR, 24f, 24f, Ui.fill(0xFFEEC2E8));
        c.drawRoundRect(titleR.left, titleR.top, titleR.right, panelR.top + 30f, 24f, 24f, Ui.fill(0xFFFFFFFF));
        Ui.centerText(c, "Настройки", titleR.centerX(), titleR.top + titleR.height() * 0.45f,
                Ui.text(0xFFE07A9F, h * 0.075f, true));

        slider(c, musicR, gs.music(), "[i:music]", h);
        slider(c, sfxR, gs.sfx(), "[i:speaker]", h);

        c.drawRoundRect(langR, 8f, 8f, Ui.fill(0xFFF2F2F2));
        Ui.centerText(c, "Русский", langR.centerX(), langR.centerY(), Ui.text(0xFFA99BCB, h * 0.05f, true));
        Ui.centerText(c, "[i:globe]", langR.left - panelR.width() * 0.1f, langR.centerY(), Ui.text(0xFFFFFFFF, h * 0.07f, false));
        Ui.centerText(c, "[i:chevron_down]", langR.right - langR.height() * 0.5f, langR.centerY(), Ui.text(0xFF333333, h * 0.05f, true));

        Ui.button(c, tutR, "Повторить обучение", 0xFFB06AE0, 0xFFFFFFFF, h * 0.04f);
        Ui.button(c, resetR, "Сбросить прогресс", 0xFFE0485F, 0xFFFFFFFF, h * 0.04f);
        toggle(c, heartsT, gs.heartsOn(), "Сердечки", h);
        toggle(c, hintsT, gs.hintsOn(), "Подсказки", h);

        Ui.slant(c, backR, "Назад", 0xFFE0869F, 0xFFFFFFFF, h * 0.06f);
    }

    private float val(RectF r, float x) {
        return Math.max(0f, Math.min(1f, (x - r.left) / r.width()));
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_DOWN) {
            drag = -1;
            if (y > musicR.top - 20f && y < musicR.bottom + 20f && x > musicR.left - 30f) drag = 0;
            else if (y > sfxR.top - 20f && y < sfxR.bottom + 20f && x > sfxR.left - 30f) drag = 1;
        }
        if ((act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_MOVE) && drag >= 0) {
            if (drag == 0) { gs.setMusic(val(musicR, x)); Sound.applyMusicVolume(); }
            else gs.setSfx(val(sfxR, x));
            invalidate();
            return true;
        }
        if (act != MotionEvent.ACTION_UP) return true;
        if (drag == 1) Sound.sfx("sfx_click");
        drag = -1;
        if (backR.contains(x, y)) { back(); return true; }
        if (heartsT.contains(x, y) || (y > heartsT.top && y < heartsT.bottom && x > heartsT.right && x < hintsT.left)) {
            gs.setHeartsOn(!gs.heartsOn());
            invalidate();
        } else if (hintsT.contains(x, y) || (y > hintsT.top && y < hintsT.bottom && x > hintsT.right)) {
            gs.setHintsOn(!gs.hintsOn());
            invalidate();
        } else if (tutR.contains(x, y)) {
            gs.setTutorialDone(false);
            back();
        } else if (resetR.contains(x, y)) {
            new AlertDialog.Builder(a)
                    .setTitle("Сбросить весь прогресс?")
                    .setPositiveButton("Да", (d, w2) -> {
                        gs.reset();
                        a.showMenu();
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
        }
        return true;
    }
}
