package com.neighborvn;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;

/** Казино: колесо с призами. Одно вращение стоит один жетон (жетоны продаются в магазине). */
final class CasinoView extends View {
    // тип: 0 алмазы, 1 бустер (k), 2 жетон, 3 подарок (k)
    private static final int[] TYPE = {0, 1, 0, 3, 1, 0, 2, 3, 1, 0, 3, 0};
    private static final int[] ARG = {100, 0, 250, 0, 1, 500, 1, 2, 2, 1000, 1, 150};
    private static final String[] ICON = {"[i:gem]", Data.BOOST_ICON[0], "[i:gem]", Data.GIFT_ICON[0], Data.BOOST_ICON[1], "[i:gem]",
            "[i:ticket]", Data.GIFT_ICON[2], Data.BOOST_ICON[2], "[i:gem]", Data.GIFT_ICON[1], "[i:gem]"};
    private static final int[] WEIGHT = {20, 10, 12, 8, 10, 6, 6, 3, 10, 2, 8, 5};
    private static final int[] COL = {0xFFE2A0B0, 0xFFF6EBB0, 0xFF9FD0F5, 0xFFF6EBB0, 0xFFE2A0B0, 0xFF9FD0F5};

    private final MainActivity a;
    private final GameState gs;
    private final Random rnd = new Random();
    private final RectF wheelR = new RectF(), spinR = new RectF();
    private float cx, cy, rad;
    private float angle = 0f, from, to;
    private long t0;
    private boolean spinning;
    private int prize = -1;
    private String banner;
    private long bannerUntil;
    private Paint bgP;

    CasinoView(MainActivity a) {
        super(a);
        this.a = a;
        this.gs = a.gs;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        bgP = new Paint();
        bgP.setShader(new LinearGradient(0, 0, 0, h, 0xFF3A1F45, 0xFF150E22, Shader.TileMode.CLAMP));
        cx = w * 0.5f;
        cy = h * 0.5f;
        rad = h * 0.42f;
        wheelR.set(cx - rad, cy - rad, cx + rad, cy + rad);
        spinR.set(cx - rad * 0.24f, cy - rad * 0.24f, cx + rad * 0.24f, cy + rad * 0.24f);
    }

    private int pick() {
        int sum = 0;
        for (int v : WEIGHT) sum += v;
        int r = rnd.nextInt(sum);
        for (int i = 0; i < WEIGHT.length; i++) {
            r -= WEIGHT[i];
            if (r < 0) return i;
        }
        return 0;
    }

    private String label(int i) {
        switch (TYPE[i]) {
            case 0: return String.valueOf(ARG[i]);
            case 2: return "x" + ARG[i];
            case 1: return "x1";
            default: return "x1";
        }
    }

    private void start() {
        if (spinning) return;
        if (gs.tokens() <= 0) {
            banner = "НЕТ ЖЕТОНОВ";
            bannerUntil = System.currentTimeMillis() + 1800;
            invalidate();
            return;
        }
        gs.addTokens(-1);
        prize = pick();
        float finalAngle = 270f - (prize + 0.5f) * 30f;
        from = angle % 360f;
        to = from + 360f * 5f + ((finalAngle - from) % 360f + 360f) % 360f;
        t0 = System.nanoTime();
        spinning = true;
        banner = null;
        invalidate();
    }

    private void award(int i) {
        String text;
        switch (TYPE[i]) {
            case 0:
                gs.addDiamonds(ARG[i]);
                text = "+" + ARG[i] + " [i:gem]";
                break;
            case 1:
                int bk = i == 1 ? 0 : (i == 4 ? 1 : 2);
                gs.addBooster(bk, 1);
                text = Data.BOOST_ICON[bk] + " " + Data.BOOST_NAME[bk];
                break;
            case 2:
                gs.addTokens(ARG[i]);
                text = "[i:ticket] +" + ARG[i];
                break;
            default:
                int gk = i == 3 ? 0 : (i == 7 ? 2 : 1);
                gs.addGift(gk, 1);
                text = Data.GIFT_ICON[gk] + " " + Data.GIFT_NAME[gk];
        }
        banner = "ВЫИГРЫШ: " + text;
        bannerUntil = System.currentTimeMillis() + 3000;
        a.hearts.burst(cx, cy, 24);
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawRect(0, 0, w, h, bgP);

        if (spinning) {
            float t = (System.nanoTime() - t0) / 1e9f / 4.2f;
            if (t >= 1f) {
                angle = to;
                spinning = false;
                award(prize);
            } else {
                float e = 1f - (float) Math.pow(1f - t, 3);
                angle = from + (to - from) * e;
            }
        }

        // Колесо
        c.drawCircle(cx, cy + rad * 0.03f, rad * 1.06f, Ui.fill(0x66000000));
        c.drawCircle(cx, cy, rad * 1.04f, Ui.fill(0xFFB48CE6));
        c.drawCircle(cx, cy, rad * 0.97f, Ui.fill(0xFF7E5BB5));
        c.save();
        c.rotate(angle, cx, cy);
        RectF arc = new RectF(cx - rad * 0.92f, cy - rad * 0.92f, cx + rad * 0.92f, cy + rad * 0.92f);
        for (int i = 0; i < 12; i++) {
            c.drawArc(arc, i * 30f, 30f, true, Ui.fill(COL[i % 6]));
            double mid = Math.toRadians(i * 30f + 15f);
            float ix = cx + (float) Math.cos(mid) * rad * 0.66f, iy = cy + (float) Math.sin(mid) * rad * 0.66f;
            c.save();
            c.rotate(i * 30f + 15f + 90f, ix, iy);
            Ui.centerText(c, ICON[i], ix, iy - rad * 0.04f, Ui.text(0xFFFFFFFF, rad * 0.2f, false));
            Ui.outlined(c, label(i), ix, iy + rad * 0.15f, rad * 0.12f, 0xFFFFFFFF, 0xFF4A2D7A);
            c.restore();
        }
        for (int i = 0; i < 12; i++) {
            double ang = Math.toRadians(i * 30f);
            c.drawLine(cx, cy, cx + (float) Math.cos(ang) * rad * 0.92f, cy + (float) Math.sin(ang) * rad * 0.92f,
                    Ui.fill(0x55FFFFFF));
        }
        c.restore();
        for (int i = 0; i < 24; i++) {
            double ang = Math.toRadians(i * 15f);
            boolean lit = ((i + (int) (System.nanoTime() / 3e8)) & 1) == 0;
            c.drawCircle(cx + (float) Math.cos(ang) * rad * 0.99f, cy + (float) Math.sin(ang) * rad * 0.99f,
                    rad * 0.028f, Ui.fill(lit ? 0xFFFFF3C0 : 0xFF444455));
        }

        // Указатель сверху
        Path p = new Path();
        p.moveTo(cx - rad * 0.07f, cy - rad * 1.1f);
        p.lineTo(cx + rad * 0.07f, cy - rad * 1.1f);
        p.lineTo(cx, cy - rad * 0.9f);
        p.close();
        c.drawPath(p, Ui.fill(0xFFE0485F));

        // Кнопка вращения
        c.drawCircle(cx, cy, spinR.width() / 2f * 1.18f, Ui.fill(0xFFE3D2FA));
        c.drawCircle(cx, cy, spinR.width() / 2f, Ui.fill(0xFF8A52C4));
        Ui.outlined(c, "КРУТИТЬ", cx, cy, rad * 0.1f, 0xFFFFFFFF, 0xFF4A2D7A);

        // Баннер
        if (banner != null && System.currentTimeMillis() < bannerUntil) {
            c.drawRect(0, cy - h * 0.09f, w, cy + h * 0.09f, Ui.fill(0xCC9B1FB8));
            Ui.outlined(c, banner, cx, cy, h * 0.1f, 0xFFFFFFFF, 0xFF3A1F6A);
        }

        Hud.backChevron(c, new RectF(w * 0.012f, h * 0.36f, w * 0.04f, h * 0.60f));
        Hud.currency(c, gs, w * 0.99f, h * 0.95f, h * 0.055f);
        postInvalidateOnAnimation();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) return true;
        if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
        float x = e.getX(), y = e.getY();
        if (x < getWidth() * 0.07f && y > getHeight() * 0.30f && y < getHeight() * 0.66f) {
            if (!spinning) a.showMap();
            return true;
        }
        if (Math.hypot(x - cx, y - cy) < spinR.width() * 0.6f) start();
        return true;
    }
}
