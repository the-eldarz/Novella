package com.neighborvn;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.StaticLayout;
import android.text.TextPaint;

/** Мелкие помощники для рисования. */
final class Ui {
    private Ui() {}

    static Paint fill(int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        return p;
    }

    static TextPaint text(int color, float size, boolean bold) {
        TextPaint p = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        p.setTextSize(size);
        if (bold) p.setTypeface(Typeface.DEFAULT_BOLD);
        return p;
    }

    static int darken(int color, float f) {
        int r = (int) (((color >> 16) & 0xFF) * f);
        int g = (int) (((color >> 8) & 0xFF) * f);
        int b = (int) ((color & 0xFF) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    static void centerText(Canvas c, String s, float cx, float cy, TextPaint p) {
        p.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fm = p.getFontMetrics();
        c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, p);
    }

    /** Рисует текст с переносами строк, возвращает высоту блока. */
    static int wrapped(Canvas c, String s, float x, float y, int width, TextPaint p) {
        if (s.isEmpty() || width <= 0) return 0;
        p.setTextAlign(Paint.Align.LEFT);
        StaticLayout l = StaticLayout.Builder.obtain(s, 0, s.length(), p, width)
                .setLineSpacing(0f, 1.1f).build();
        c.save();
        c.translate(x, y);
        l.draw(c);
        c.restore();
        return l.getHeight();
    }

    static void button(Canvas c, RectF r, String label, int bg, int fg, float size) {
        float rad = r.height() / 3f;
        c.drawRoundRect(r, rad, rad, fill(bg));
        centerText(c, label, r.centerX(), r.centerY(), text(fg, size, true));
    }

    /** Временная заглушка вместо арта героини. Замени на свою картинку. */
    static void portrait(Canvas c, RectF r, int color, String initial, String name) {
        float rad = r.width() * 0.08f;
        c.drawRoundRect(r, rad, rad, fill(color));
        Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(Math.max(2f, r.width() * 0.015f));
        border.setColor(0xCCFFFFFF);
        c.drawRoundRect(r, rad, rad, border);
        centerText(c, initial, r.centerX(), r.centerY() - r.height() * 0.08f,
                text(0xFFFFFFFF, r.width() * 0.5f, true));
        centerText(c, name, r.centerX(), r.bottom - r.height() * 0.13f,
                text(0xFFFFFFFF, r.width() * 0.12f, true));
        centerText(c, "(здесь будет арт)", r.centerX(), r.bottom - r.height() * 0.05f,
                text(0xCCFFFFFF, r.width() * 0.07f, false));
    }
}
