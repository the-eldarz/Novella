package com.neighborvn;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.text.StaticLayout;
import android.text.TextPaint;

/** Мелкие помощники для рисования. */
final class Ui {
    private Ui() {}

    private static final Paint BMP = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);

    static Paint fill(int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        return p;
    }

    static TextPaint text(int color, float size, boolean bold) {
        TextPaint p = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        p.setTextSize(size);
        if (Art.font != null) p.setTypeface(Typeface.create(Art.font, bold ? Typeface.BOLD : Typeface.NORMAL));
        else if (bold) p.setTypeface(Typeface.DEFAULT_BOLD);
        return p;
    }

    static int darken(int color, float f) {
        int r = (int) (((color >> 16) & 0xFF) * f);
        int g = (int) (((color >> 8) & 0xFF) * f);
        int b = (int) ((color & 0xFF) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    static int lighten(int color, float f) {
        int r = Math.min(255, (int) (((color >> 16) & 0xFF) * f + 40));
        int g = Math.min(255, (int) (((color >> 8) & 0xFF) * f + 40));
        int b = Math.min(255, (int) ((color & 0xFF) * f + 40));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    static void centerText(Canvas c, String s, float cx, float cy, TextPaint p) {
        p.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fm = p.getFontMetrics();
        c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, p);
    }

    /** Текст с контуром, хорошо читается на любом фоне. */
    static void outlined(Canvas c, String s, float cx, float cy, float size, int fillCol, int strokeCol) {
        TextPaint st = text(strokeCol, size, true);
        st.setStyle(Paint.Style.STROKE);
        st.setStrokeWidth(size * 0.16f);
        st.setStrokeJoin(Paint.Join.ROUND);
        centerText(c, s, cx, cy, st);
        centerText(c, s, cx, cy, text(fillCol, size, true));
    }

    /** Рисует текст с переносами строк, возвращает высоту блока. */
    static int wrapped(Canvas c, String s, float x, float y, int width, TextPaint p) {
        if (s.isEmpty() || width <= 0) return 0;
        p.setTextAlign(Paint.Align.LEFT);
        StaticLayout l = StaticLayout.Builder.obtain(s, 0, s.length(), p, width)
                .setLineSpacing(0f, 1.1f).build();
        c.save();
        c.translate(x, y);
        l.draw(c);
        c.restore();
        return l.getHeight();
    }

    /** Объёмная плашка: толщина снизу, градиент, блик сверху. */
    static void plate(Canvas c, RectF r, int color, float rad) {
        float d = Math.max(3f, r.height() * 0.08f);
        RectF under = new RectF(r.left, r.top + d, r.right, r.bottom + d);
        c.drawRoundRect(under, rad, rad, fill(darken(color, 0.55f)));
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom, lighten(color, 1.15f), color, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        RectF g = new RectF(r.left + rad * 0.35f, r.top + r.height() * 0.06f,
                r.right - rad * 0.35f, r.top + r.height() * 0.46f);
        Paint gp = new Paint(Paint.ANTI_ALIAS_FLAG);
        gp.setShader(new LinearGradient(0, g.top, 0, g.bottom, 0x66FFFFFF, 0x05FFFFFF, Shader.TileMode.CLAMP));
        c.drawRoundRect(g, rad * 0.7f, rad * 0.7f, gp);
    }

    static void button(Canvas c, RectF r, String label, int bg, int fg, float size) {
        plate(c, r, bg, r.height() / 3f);
        centerText(c, label, r.centerX(), r.centerY(), text(fg, size, true));
    }

    /** Картинка на весь экран без искажений (с обрезкой). */
    static void cover(Canvas c, Bitmap b, float w, float h) {
        float s = Math.max(w / b.getWidth(), h / b.getHeight());
        float dw = b.getWidth() * s, dh = b.getHeight() * s;
        RectF dst = new RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f);
        c.drawBitmap(b, null, dst, BMP);
    }

    /** Героиня в полный рост: прижата к низу и по центру прямоугольника. Нет арта: заглушка. */
    static void figure(Canvas c, RectF r, int heroine) {
        Bitmap b = Art.bitmap(Data.HFILE[heroine]);
        if (b == null) {
            portrait(c, r, Data.HCOLORS[heroine], Data.HINIT[heroine], Data.HNAMES[heroine]);
            return;
        }
        float s = Math.min(r.width() / b.getWidth(), r.height() / b.getHeight());
        float dw = b.getWidth() * s, dh = b.getHeight() * s;
        RectF dst = new RectF(r.centerX() - dw / 2f, r.bottom - dh, r.centerX() + dw / 2f, r.bottom);
        c.drawBitmap(b, null, dst, BMP);
    }

    /** Лицо героини в закруглённой рамке (для меток и карточек). Берёт face_*.png либо верх портрета. */
    static void face(Canvas c, RectF r, int heroine, float rad) {
        Bitmap b = Art.bitmap("face_" + Data.HFILE[heroine]);
        Rect src = null;
        if (b == null) b = Art.bitmap(Data.HFILE[heroine]);
        if (b != null) {
            float want = r.height() / r.width();
            int sw = b.getWidth();
            int sh = Math.min(b.getHeight(), Math.round(sw * want));
            sw = Math.min(sw, Math.round(sh / want));
            src = new Rect((b.getWidth() - sw) / 2, 0, (b.getWidth() + sw) / 2, sh);
        }
        c.save();
        Path clip = new Path();
        clip.addRoundRect(r, rad, rad, Path.Direction.CW);
        c.clipPath(clip);
        if (b != null) {
            c.drawRect(r, fill(darken(Data.HCOLORS[heroine], 0.6f)));
            c.drawBitmap(b, src, r, BMP);
        } else {
            c.drawRect(r, fill(Data.HCOLORS[heroine]));
            centerText(c, Data.HINIT[heroine], r.centerX(), r.centerY(),
                    text(0xFFFFFFFF, Math.min(r.width(), r.height()) * 0.6f, true));
        }
        c.restore();
    }

    /** Временная заглушка вместо арта героини. Положи sasha.png, madina.png, ani.png в assets. */
    static void portrait(Canvas c, RectF r, int color, String initial, String name) {
        float rad = r.width() * 0.08f;
        c.drawRoundRect(r, rad, rad, fill(color));
        Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(Math.max(2f, r.width() * 0.015f));
        border.setColor(0xCCFFFFFF);
        c.drawRoundRect(r, rad, rad, border);
        centerText(c, initial, r.centerX(), r.centerY() - r.height() * 0.08f,
                text(0xFFFFFFFF, r.width() * 0.5f, true));
        centerText(c, name, r.centerX(), r.bottom - r.height() * 0.13f,
                text(0xFFFFFFFF, r.width() * 0.12f, true));
        centerText(c, "(здесь будет арт)", r.centerX(), r.bottom - r.height() * 0.05f,
                text(0xCCFFFFFF, r.width() * 0.07f, false));
    }

    /** Скошенная кнопка-параллелограмм, как в оригинале. */
    static void slant(Canvas c, RectF r, String label, int color, int fg, float size) {
        float k = r.height() * 0.22f;
        Path p = new Path();
        p.moveTo(r.left + k, r.top);
        p.lineTo(r.right, r.top);
        p.lineTo(r.right - k, r.bottom);
        p.lineTo(r.left, r.bottom);
        p.close();
        Path under = new Path(p);
        under.offset(0, r.height() * 0.07f);
        c.drawPath(under, fill(darken(color, 0.6f)));
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        g.setShader(new LinearGradient(0, r.top, 0, r.bottom, lighten(color, 1.1f), color, Shader.TileMode.CLAMP));
        c.drawPath(p, g);
        Paint hl = new Paint(Paint.ANTI_ALIAS_FLAG);
        hl.setStyle(Paint.Style.STROKE);
        hl.setStrokeWidth(Math.max(2f, r.height() * 0.03f));
        hl.setColor(0x66FFFFFF);
        c.drawPath(p, hl);
        if (label != null && !label.isEmpty()) {
            outlined(c, label, r.centerX(), r.centerY(), size, fg, darken(color, 0.55f));
        }
    }

    /** Текст-кнопка меню: светлая заливка и сиреневый контур. */
    static void menuText(Canvas c, String s, float cx, float cy, float size, boolean dim) {
        outlined(c, s, cx, cy, size, dim ? 0xAAEDE3FF : 0xFFFFFFFF, dim ? 0xAA7D5BB5 : 0xFFA070E0);
    }
}
