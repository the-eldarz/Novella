package com.neighborvn;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Хозяин экранов: меню, имя, карта, диалоги, головоломка, сцены, магазин, галерея. */
public class MainActivity extends Activity {
    private static final int MENU = 0, MAP = 1, OTHER = 2, NAME = 3;

    GameState gs;
    HeartLayer hearts;
    private FrameLayout root;
    private View current;
    private int screen = MENU;
    private boolean galleryFromMenu = false;
    private String dialogBg = null;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        Art.init(this);
        gs = new GameState(this);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF1B1B2F);
        setContentView(root);
        hearts = new HeartLayer(this);
        root.addView(hearts, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        showMenu();
    }

    private void setScreen(View v, int kind) {
        if (current != null) root.removeView(current);
        current = v;
        screen = kind;
        root.addView(v, 0, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** Сердечки вылетают при каждом касании экрана. */
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getActionMasked() == MotionEvent.ACTION_DOWN && hearts != null && gs.heartsOn()) {
            hearts.burst(ev.getX(), ev.getY(), 6);
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public void onBackPressed() {
        if (current instanceof SettingsView) ((SettingsView) current).back();
        else if (screen == MENU) super.onBackPressed();
        else if (screen == OTHER) {
            if (galleryFromMenu && current instanceof GalleryView) showMenu();
            else showMap();
        } else showMenu();
    }

    // ---------- экраны ----------

    void showMenu() {
        dialogBg = null;
        setScreen(new MenuScreen(this), MENU);
    }

    /** Кнопка «История»: имя спрашиваем только если его ещё нет. */
    void startStory() {
        if (gs.name().isEmpty()) showNameEntry();
        else showMap();
    }

    void showNameEntry() {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(0xFF2B2D42);
        Bitmap bg = Art.bitmap("name_bg");
        if (bg == null) bg = Art.bitmap("menu");
        if (bg != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(bg);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            f.addView(iv, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setPadding(60, 30, 60, 30);
        GradientDrawable panel = new GradientDrawable();
        panel.setColor(0xCC1B1B2F);
        panel.setCornerRadius(40f);
        l.setBackground(panel);

        TextView s = new TextView(this);
        s.setText("Как тебя зовут?");
        s.setTextColor(Color.WHITE);
        s.setTextSize(26);
        s.setGravity(Gravity.CENTER);
        s.setPadding(0, 0, 0, 16);
        l.addView(s);

        final EditText e = new EditText(this);
        e.setHint("Введи имя");
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(0x99FFFFFF);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setTextSize(22);
        e.setImeOptions(EditorInfo.IME_FLAG_NO_EXTRACT_UI | EditorInfo.IME_ACTION_DONE);
        l.addView(e, new LinearLayout.LayoutParams(620, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        Button back = new Button(this);
        back.setText("Назад");
        back.setOnClickListener(v -> showMenu());
        row.addView(back);
        Button go = new Button(this);
        go.setText("Начать");
        go.setOnClickListener(v -> {
            String n = e.getText().toString().trim();
            if (n.isEmpty()) n = "Хозяин";
            gs.setName(n);
            startIntro();
        });
        row.addView(go);
        l.addView(row);

        f.addView(l, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        setScreen(f, NAME);
    }

    private void startIntro() {
        dialogBg = null;
        Data.Line[] lines = new Data.Line[]{
                new Data.Line(4, "Ты успешный владелец офисной компании. А дома тебя ждут особняк и самые близкие люди."),
                new Data.Line(0, "Добро пожаловать домой, {name}! Давай я покажу, как тут всё устроено.")
        };
        showDialogue(0, lines, this::showMap);
    }

    void showMap() {
        dialogBg = null;
        setScreen(new MapView(this), MAP);
    }

    void showDialogue(int heroine, Data.Line[] lines, Runnable done) {
        setScreen(new DialogueView(this, heroine, lines, gs.name(), dialogBg, done), OTHER);
    }

    void startLevel(int li) {
        Data.Level L = Data.LEVELS[li];
        dialogBg = L.bg();
        int h = gs.hearts(li);
        if (h == 0) showDialogue(L.heroine, L.intro, () -> showMatch(li, 0));
        else if (h == 1) showDialogue(L.heroine, L.mid1, () -> showMatch(li, 1));
        else if (h == 2) showDialogue(L.heroine, L.mid2, () -> showMatch(li, 2));
        else showMap();
    }

    void showMatch(final int li, final int sub) {
        setScreen(new Match3View(this, li, sub, new Match3View.Listener() {
            @Override public void onWin() { onSubWin(li, sub); }
            @Override public void onLose() { showMatch(li, sub); }
            @Override public void onExit() { showMap(); }
        }), OTHER);
    }

    private void onSubWin(int li, int sub) {
        gs.setHearts(li, Math.max(gs.hearts(li), sub + 1));
        gs.addDiamonds(20);
        Data.Level L = Data.LEVELS[li];
        dialogBg = L.bg();
        if (sub == 0) showDialogue(L.heroine, L.mid1, () -> showMatch(li, 1));
        else if (sub == 1) showDialogue(L.heroine, L.mid2, () -> showMatch(li, 2));
        else showDialogue(L.heroine, L.outro, () -> showScene(li, this::showMap));
    }

    /** Сцена остаётся на экране, пока игрок не нажмёт «Выход». */
    void showScene(int li, Runnable done) {
        setScreen(new SceneScreen(this, li, done), OTHER);
    }

    void showShop() {
        setScreen(new ShopView(this), OTHER);
    }

    /** sel = -1: выбор героини, 0..2: сцены выбранной героини. */
    void showGallery(int sel) {
        setScreen(new GalleryView(this, sel), OTHER);
    }

    void openGallery(boolean fromMenu) {
        galleryFromMenu = fromMenu;
        showGallery(-1);
    }

    void leaveGallery() {
        if (galleryFromMenu) showMenu();
        else showMap();
    }

    void showSettings(boolean fromMap) {
        setScreen(new SettingsView(this, fromMap), OTHER);
    }

    void showCasino() {
        setScreen(new CasinoView(this), OTHER);
    }
}
