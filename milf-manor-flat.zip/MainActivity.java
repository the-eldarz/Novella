package com.neighborvn;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Хозяин экранов: карта, диалоги, головоломка, сцены, магазин, галерея. */
public class MainActivity extends Activity {
    GameState gs;
    HeartLayer hearts;
    private FrameLayout root;
    private View current;
    private boolean onMap = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        gs = new GameState(this);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF1B1B2F);
        setContentView(root);
        hearts = new HeartLayer(this);
        root.addView(hearts, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (gs.name().isEmpty()) showNameEntry();
        else showMap();
    }

    private void setScreen(View v, boolean map) {
        if (current != null) root.removeView(current);
        current = v;
        onMap = map;
        root.addView(v, 0, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** Сердечки вылетают при каждом касании экрана. */
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getActionMasked() == MotionEvent.ACTION_DOWN && hearts != null) {
            hearts.burst(ev.getX(), ev.getY(), 6);
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public void onBackPressed() {
        if (!onMap && current != null && gs != null && !gs.name().isEmpty()) showMap();
        else super.onBackPressed();
    }

    // ---------- экраны ----------

    void showNameEntry() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(0xFF2B2D42);
        l.setPadding(60, 30, 60, 30);

        TextView t = new TextView(this);
        t.setText("Milf Manor");
        t.setTextColor(Color.WHITE);
        t.setTextSize(34);
        t.setGravity(Gravity.CENTER);
        l.addView(t);

        TextView s = new TextView(this);
        s.setText("Как тебя зовут?");
        s.setTextColor(0xCCFFFFFF);
        s.setTextSize(18);
        s.setGravity(Gravity.CENTER);
        s.setPadding(0, 20, 0, 10);
        l.addView(s);

        final EditText e = new EditText(this);
        e.setHint("Введи имя");
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(0x99FFFFFF);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setTextSize(20);
        l.addView(e, new LinearLayout.LayoutParams(600, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button go = new Button(this);
        go.setText("Начать");
        go.setOnClickListener(v -> {
            String n = e.getText().toString().trim();
            if (n.isEmpty()) n = "Хозяин";
            gs.setName(n);
            startIntro();
        });
        l.addView(go);
        setScreen(l, false);
    }

    private void startIntro() {
        Data.Line[] lines = new Data.Line[]{
                new Data.Line(4, "Ты успешный владелец офисной компании. А дома тебя ждут особняк и самые близкие люди."),
                new Data.Line(0, "Добро пожаловать домой, {name}! Давай я покажу, как тут всё устроено.")
        };
        showDialogue(0, lines, this::showMap);
    }

    void showMap() {
        setScreen(new MapView(this), true);
    }

    void showDialogue(int heroine, Data.Line[] lines, Runnable done) {
        setScreen(new DialogueView(this, heroine, lines, gs.name(), done), false);
    }

    void startLevel(int li) {
        Data.Level L = Data.LEVELS[li];
        int h = gs.hearts(li);
        if (h == 0) showDialogue(L.heroine, L.intro, () -> showMatch(li, 0));
        else if (h == 1) showDialogue(L.heroine, L.mid1, () -> showMatch(li, 1));
        else if (h == 2) showDialogue(L.heroine, L.mid2, () -> showMatch(li, 2));
        else showMap();
    }

    void showMatch(final int li, final int sub) {
        setScreen(new Match3View(this, li, sub, new Match3View.Listener() {
            @Override public void onWin() { onSubWin(li, sub); }
            @Override public void onLose() { showMatch(li, sub); }
            @Override public void onExit() { showMap(); }
        }), false);
    }

    private void onSubWin(int li, int sub) {
        gs.setHearts(li, Math.max(gs.hearts(li), sub + 1));
        gs.addDiamonds(20);
        Data.Level L = Data.LEVELS[li];
        if (sub == 0) showDialogue(L.heroine, L.mid1, () -> showMatch(li, 1));
        else if (sub == 1) showDialogue(L.heroine, L.mid2, () -> showMatch(li, 2));
        else showDialogue(L.heroine, L.outro, () -> showScene(li, this::showMap));
    }

    void showScene(int li, Runnable done) {
        setScreen(new SceneView(this, li, done), false);
    }

    void showShop() {
        setScreen(new ShopView(this), false);
    }

    /** sel = -1: выбор героини, 0..3: сцены выбранной героини. */
    void showGallery(int sel) {
        setScreen(new GalleryView(this, sel), false);
    }

    void showSettings() {
        final String[] items = {"Повторить обучение", "Сбросить весь прогресс"};
        new AlertDialog.Builder(this)
                .setTitle("Настройки")
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        gs.setTutorialDone(false);
                        showMap();
                    } else {
                        new AlertDialog.Builder(this)
                                .setTitle("Сбросить весь прогресс?")
                                .setPositiveButton("Да", (d2, w2) -> {
                                    gs.reset();
                                    showNameEntry();
                                })
                                .setNegativeButton("Отмена", null)
                                .show();
                    }
                })
                .show();
    }
}
