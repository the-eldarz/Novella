package com.neighborvn;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Хозяин экранов: меню, имя, карта, диалоги, головоломка, сцены, магазин, галерея. */
public class MainActivity extends Activity {
    private static final int MENU = 0, MAP = 1, OTHER = 2, NAME = 3;

    GameState gs;
    HeartLayer hearts;
    private FrameLayout root;
    private View current;
    private View overlay;
    private View overlayDim;
    private int screen = MENU;
    private boolean galleryFromMenu = false;
    private String dialogBg = null;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        Art.init(this);
        gs = new GameState(this);
        Sound.init(this, gs);
        Sound.music("music");
        Sound.preload("sfx_click", "sfx_next", "sfx_pop", "sfx_win", "sfx_lose");
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF1B1B2F);
        setContentView(root);
        hearts = new HeartLayer(this);
        root.addView(hearts, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        showMenu();
    }

    private void setScreen(View v, int kind) {
        removeOverlayNow();
        final View old = current;
        current = v;
        screen = kind;
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        boolean fancyIn = v instanceof ShopView || v instanceof CasinoView;
        boolean fancyOut = old instanceof ShopView || old instanceof CasinoView;
        if (old != null && fancyIn) {
            // магазин выезжает снизу, казино приближается к центру; старый экран виден под ними
            root.addView(v, root.getChildCount() - 1, lp);
            animateIn(v, () -> root.removeView(old));
        } else if (old != null && fancyOut) {
            // магазин и казино уходят, под ними уже новый экран
            root.addView(v, 0, lp);
            animateOut(old);
        } else {
            if (old != null) root.removeView(old);
            root.addView(v, 0, lp);
        }
    }

    private void animateIn(View v, Runnable end) {
        v.setAlpha(0f);
        if (v instanceof ShopView) {
            v.setTranslationY(root.getHeight() * 0.35f);
            v.animate().translationY(0f).alpha(1f).setDuration(300)
                    .setInterpolator(new DecelerateInterpolator(2f)).withEndAction(end).start();
        } else {
            v.setScaleX(0.15f);
            v.setScaleY(0.15f);
            v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(420)
                    .setInterpolator(new DecelerateInterpolator(1.8f)).withEndAction(end).start();
        }
    }

    private void animateOut(final View old) {
        Runnable end = () -> root.removeView(old);
        if (old instanceof ShopView) {
            old.animate().translationY(root.getHeight() * 0.35f).alpha(0f).setDuration(240)
                    .setInterpolator(new AccelerateInterpolator(1.6f)).withEndAction(end).start();
        } else {
            old.animate().scaleX(0.15f).scaleY(0.15f).alpha(0f).setDuration(260)
                    .setInterpolator(new AccelerateInterpolator(1.6f)).withEndAction(end).start();
        }
    }

    // ---------- панели поверх экрана (пауза, настройки) ----------

    /** Панель «выпрыгивает» из центра с лёгким перелётом, экран за ней затемняется. */
    private void showOverlay(View v) {
        removeOverlayNow();
        View dim = new View(this);
        dim.setBackgroundColor(0x66000000);
        dim.setAlpha(0f);
        root.addView(dim, root.getChildCount() - 1, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(v, root.getChildCount() - 1, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        overlay = v;
        overlayDim = dim;
        dim.animate().alpha(1f).setDuration(200).start();
        v.setAlpha(0f);
        v.setScaleX(0.88f);
        v.setScaleY(0.88f);
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240)
                .setInterpolator(new OvershootInterpolator(1.1f)).start();
    }

    /** Закрывает панель: плавно уменьшается и гаснет. */
    void closeOverlay() {
        if (overlay == null) return;
        final View v = overlay, dim = overlayDim;
        overlay = null;
        overlayDim = null;
        dim.animate().alpha(0f).setDuration(180).start();
        v.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f).setDuration(180).withEndAction(() -> {
            root.removeView(v);
            root.removeView(dim);
        }).start();
    }

    private void removeOverlayNow() {
        if (overlay != null) {
            overlay.animate().cancel();
            root.removeView(overlay);
            overlay = null;
        }
        if (overlayDim != null) {
            overlayDim.animate().cancel();
            root.removeView(overlayDim);
            overlayDim = null;
        }
    }

    /** Сердечки вылетают при каждом касании экрана. */
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getActionMasked() == MotionEvent.ACTION_DOWN && hearts != null && gs.heartsOn()) {
            hearts.burst(ev.getX(), ev.getY(), 6);
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    protected void onPause() {
        Sound.pause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Sound.resume();
    }

    @Override
    protected void onDestroy() {
        Sound.release();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (overlay instanceof SettingsView) ((SettingsView) overlay).back();
        else if (overlay != null) closeOverlay();
        else if (screen == MENU) super.onBackPressed();
        else if (screen == OTHER) {
            if (galleryFromMenu && current instanceof GalleryView) showMenu();
            else showMap();
        } else showMenu();
    }

    // ---------- экраны ----------

    void showMenu() {
        dialogBg = null;
        setScreen(new MenuScreen(this), MENU);
    }

    /** Кнопка «История»: имя спрашиваем только если его ещё нет. */
    void startStory() {
        if (gs.name().isEmpty()) showNameEntry();
        else showMapWithDoors();
    }

    /** Меню -> карта через двери лифта. */
    private void showMapWithDoors() {
        ElevatorDoors d = new ElevatorDoors(this, this::showMap);
        root.addView(d, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        d.start();
    }

    void showNameEntry() {
        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(0xFF2B2D42);
        Bitmap bg = Art.bitmap("name_bg");
        if (bg == null) bg = Art.bitmap("menu");
        if (bg != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(bg);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            f.addView(iv, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setPadding(60, 30, 60, 30);
        GradientDrawable panel = new GradientDrawable();
        panel.setColor(0xCC1B1B2F);
        panel.setCornerRadius(40f);
        l.setBackground(panel);

        TextView s = new TextView(this);
        s.setText("Как тебя зовут?");
        s.setTextColor(Color.WHITE);
        s.setTextSize(26);
        s.setGravity(Gravity.CENTER);
        s.setPadding(0, 0, 0, 16);
        l.addView(s);

        final EditText e = new EditText(this);
        e.setHint("Введи имя");
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(0x99FFFFFF);
        e.setSingleLine(true);
        e.setGravity(Gravity.CENTER);
        e.setTextSize(22);
        e.setImeOptions(EditorInfo.IME_FLAG_NO_EXTRACT_UI | EditorInfo.IME_ACTION_DONE);
        l.addView(e, new LinearLayout.LayoutParams(620, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        Button back = new Button(this);
        back.setText("Назад");
        back.setOnClickListener(v -> showMenu());
        row.addView(back);
        Button go = new Button(this);
        go.setText("Начать");
        go.setOnClickListener(v -> {
            String n = e.getText().toString().trim();
            if (n.isEmpty()) n = "Хозяин";
            gs.setName(n);
            startIntro();
        });
        row.addView(go);
        l.addView(row);

        f.addView(l, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        setScreen(f, NAME);
    }

    private void startIntro() {
        dialogBg = null;
        Data.Line[] lines = new Data.Line[]{
                new Data.Line(4, "Ты успешный владелец офисной компании. А дома тебя ждут особняк и самые близкие люди."),
                new Data.Line(3, "*Каким бы тяжёлым ни был день, домой всегда хочется вернуться.*"),
                new Data.Line(0, "Добро пожаловать домой, {name}! Давай я покажу, как тут всё устроено."),
                new Data.Line(3, "Спасибо. Дом такой большой, что без проводника я бы заблудился."),
                new Data.Line(0, "Тогда держись рядом. Поможешь мне и девочкам, а мы поможем тебе почувствовать себя дома."),
                new Data.Line(3, "*Хорошее начало. Кажется, здесь мне будет уютно.*")
        };
        showDialogue(0, lines, this::showMap);
    }

    void showMap() {
        dialogBg = null;
        setScreen(new MapView(this), MAP);
    }

    void showDialogue(int heroine, Data.Line[] lines, Runnable done) {
        setScreen(new DialogueView(this, heroine, lines, gs.name(), dialogBg, done), OTHER);
    }

    void startLevel(int li) {
        Data.Level L = Data.LEVELS[li];
        dialogBg = L.bg();
        int h = gs.hearts(li);
        if (h == 0) showDialogue(L.heroine, L.intro, () -> showMatch(li, 0));
        else if (h == 1) showDialogue(L.heroine, L.mid1, () -> showMatch(li, 1));
        else if (h == 2) showDialogue(L.heroine, L.mid2, () -> showMatch(li, 2));
        else showMap();
    }

    void showMatch(final int li, final int sub) {
        setScreen(new Match3View(this, li, sub, new Match3View.Listener() {
            @Override public void onWin() { onSubWin(li, sub); }
            @Override public void onLose() { showMatch(li, sub); }
            @Override public void onExit() { showMap(); }
        }), OTHER);
    }

    private void onSubWin(int li, int sub) {
        gs.setHearts(li, Math.max(gs.hearts(li), sub + 1));
        gs.addDiamonds(20);
        Data.Level L = Data.LEVELS[li];
        dialogBg = L.bg();
        if (sub == 0) showDialogue(L.heroine, L.mid1, () -> showMatch(li, 1));
        else if (sub == 1) showDialogue(L.heroine, L.mid2, () -> showMatch(li, 2));
        else showDialogue(L.heroine, L.outro, () -> showScene(li, this::showMap));
    }

    /** Сцена остаётся на экране, пока игрок не нажмёт «Выход». */
    void showScene(int li, Runnable done) {
        setScreen(new SceneScreen(this, li, done), OTHER);
    }

    void showShop() {
        setScreen(new ShopView(this), OTHER);
    }

    /** sel = -1: выбор героини, 0..2: сцены выбранной героини. */
    void showGallery(int sel) {
        setScreen(new GalleryView(this, sel), OTHER);
    }

    void openGallery(boolean fromMenu) {
        galleryFromMenu = fromMenu;
        showGallery(-1);
    }

    void leaveGallery() {
        if (galleryFromMenu) showMenu();
        else showMap();
    }

    void showSettings(boolean fromMap) {
        showOverlay(new SettingsView(this, fromMap));
    }

    void showPause() {
        showOverlay(new PauseView(this));
    }

    void showCasino() {
        setScreen(new CasinoView(this), OTHER);
    }
}
