package com.neighborvn;

import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.text.TextPaint;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

/**
 * Карта: иллюстрация особняка (assets/map.png с прозрачным фоном) лежит поверх узорного фона
 * (свой файл map_bg.jpg/png либо узор по умолчанию). Карта не двигается.
 * Метки уровней стоят в комнатах (координаты fx, fy в Data.LEVELS).
 */
final class MapView extends View {
    private static final long INCOME_MS = 60000L;
    private static final int INCOME_REWARD = 25;

    private static final String[] TUT_TEXT = {
        "Это наш особняк. В каждой комнате ждёт своя история.",
        "Здесь твой прогресс: сколько сердечек ты уже собрал.",
        "Это алмазы и жетоны казино. Алмазы нужны для подарков и новых комнат.",
        "Прибыль компании. Когда круг заполнится, нажми на него и забери алмазы.",
        "Внизу бустеры. Они пригодятся в головоломках.",
        "Справа магазин и казино. Попытай удачу!",
        "Начнём с моей спальни. Нажми на метку с моим портретом!"
    };

    private final MainActivity a;
    private final GameState gs;
    private final int n = Data.LEVELS.length;
    private final RectF areaR = new RectF(), mapR = new RectF(), heartsR = new RectF(), pctR = new RectF(),
            curR = new RectF(), incomeR = new RectF(), gearR = new RectF(), portraitR = new RectF(),
            shopR = new RectF(), casinoR = new RectF(), boostR = new RectF(), backR = new RectF(),
            tmp = new RectF();
    private final RectF[] pinR = new RectF[n];
    private final RectF[] bR = new RectF[3];
    private Bitmap map, bg;
    private float pinW, pinH;
    private int tut;

    MapView(MainActivity a) {
        super(a);
        this.a = a;
        this.gs = a.gs;
        for (int i = 0; i < n; i++) pinR[i] = new RectF();
        for (int i = 0; i < 3; i++) bR[i] = new RectF();
        tut = gs.tutorialDone() ? -1 : 0;
        map = Art.bitmap("map");
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        bg = Art.bitmap("map_bg");
        if (bg == null) bg = Hud.pattern(w, h, 0xFFD9D2B4, 0xFFC9D4A8, 0xFFE8E2C8);

        areaR.set(w * 0.06f, h * 0.02f, w * 0.80f, h * 0.87f);
        float imgW = map != null ? map.getWidth() : 1535f, imgH = map != null ? map.getHeight() : 1024f;
        float s = Math.min(areaR.width() / imgW, areaR.height() / imgH);
        float mw = imgW * s, mh = imgH * s;
        mapR.set(areaR.centerX() - mw / 2f, areaR.centerY() - mh / 2f,
                areaR.centerX() + mw / 2f, areaR.centerY() + mh / 2f);
        pinW = h * 0.095f;
        pinH = h * 0.12f;

        float cs = h * 0.09f;
        gearR.set(w * 0.985f - cs, h * 0.02f, w * 0.985f, h * 0.02f + cs);
        incomeR.set(gearR.left - cs - w * 0.01f, h * 0.02f, gearR.left - w * 0.01f, h * 0.02f + cs);
        portraitR.set(w * 0.82f, h * 0.14f, w * 0.98f, h * 0.48f);
        shopR.set(w * 0.80f, h * 0.51f, w * 0.99f, h * 0.61f);
        casinoR.set(w * 0.78f, h * 0.65f, w * 0.97f, h * 0.75f);
        curR.set(w * 0.74f, h * 0.90f, w * 0.99f, h * 0.99f);
        heartsR.set(w * 0.01f, h * 0.74f, w * 0.17f, h * 0.81f);
        pctR.set(w * 0.01f, h * 0.84f, w * 0.17f, h * 0.91f);
        backR.set(w * 0.012f, h * 0.36f, w * 0.04f, h * 0.60f);
        boostR.set(w * 0.34f, h * 0.885f, w * 0.34f + w * 0.075f * 3f, h * 0.885f + h * 0.085f);
        float bw = w * 0.075f;
        for (int i = 0; i < 3; i++) {
            bR[i].set(boostR.left + i * bw * 1.05f, boostR.top, boostR.left + i * bw * 1.05f + bw, boostR.bottom);
        }
    }

    private void placePin(int i) {
        Data.Level lv = Data.LEVELS[i];
        float cx = mapR.left + lv.fx * mapR.width(), cy = mapR.top + lv.fy * mapR.height();
        pinR[i].set(cx - pinW / 2f, cy - pinH / 2f, cx + pinW / 2f, cy + pinH / 2f);
    }

    private RectF tutRect(int step) {
        switch (step) {
            case 0: return mapR;
            case 1: return heartsR;
            case 2: return curR;
            case 3: return incomeR;
            case 4: tmp.set(boostR.left, boostR.top, boostR.right, boostR.bottom + boostR.height() * 0.4f); return tmp;
            case 5: tmp.set(casinoR.left, shopR.top, shopR.right, casinoR.bottom); return tmp;
            default: placePin(0); return pinR[0];
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (bg != null) {
            if (bg.getWidth() == w && bg.getHeight() == h) c.drawBitmap(bg, 0, 0, null);
            else Ui.cover(c, bg, w, h);
        }

        // Карта особняка поверх фона
        if (map != null) {
            c.drawBitmap(map, null, mapR, new Paint(Paint.FILTER_BITMAP_FLAG));
        } else {
            Ui.centerText(c, "Нет файла map.png", mapR.centerX(), mapR.centerY(), Ui.text(0xFF000000, h * 0.05f, true));
        }
        for (int i = 0; i < n; i++) {
            placePin(i);
            drawPin(c, i);
        }

        // Назад и верхние кнопки
        Hud.backChevron(c, backR);
        drawIncome(c);
        c.drawCircle(gearR.centerX(), gearR.centerY(), gearR.width() / 2f, Ui.fill(0xFFA58BD6));
        Ui.centerText(c, "[i:gear]", gearR.centerX(), gearR.centerY(), Ui.text(0xFFFFFFFF, h * 0.06f, false));

        // Героиня, магазин, казино
        Ui.figure(c, portraitR, 0);
        Ui.slant(c, shopR, "Магазин", 0xFF9B7EDE, 0xFFFFFFFF, h * 0.05f);
        Ui.slant(c, casinoR, "Казино", 0xFF9B7EDE, 0xFFFFFFFF, h * 0.05f);

        // Левый нижний угол: прогресс
        int total = n * 3, got = gs.totalHearts();
        Ui.slant(c, heartsR, "[i:heart] " + got + " / " + total, 0xFFA58BD6, 0xFFFFFFFF, h * 0.04f);
        Ui.slant(c, pctR, "[i:crown] " + (got * 100 / total) + "%", 0xFFA58BD6, 0xFFFFFFFF, h * 0.04f);

        // Бустеры и валюта
        Hud.boosters(c, bR, gs, h);
        Hud.currency(c, gs, curR.right, curR.centerY(), h * 0.055f);

        if (tut >= 0) drawTutorial(c, w, h);
        postInvalidateDelayed(500);
    }

    private void drawIncome(Canvas c) {
        float p = Math.min(1f, (System.currentTimeMillis() - gs.lastIncome()) / (float) INCOME_MS);
        boolean ready = p >= 1f;
        float cx = incomeR.centerX(), cy = incomeR.centerY(), rad = incomeR.width() / 2f;
        c.drawCircle(cx, cy, rad, Ui.fill(0xFFE0485F));
        Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(rad * 0.2f);
        arc.setColor(ready ? 0xFFFFD54F : 0xFFFFFFFF);
        RectF o = new RectF(cx - rad * 0.82f, cy - rad * 0.82f, cx + rad * 0.82f, cy + rad * 0.82f);
        c.drawArc(o, -90f, 360f * p, false, arc);
        Ui.centerText(c, "[i:bag]", cx, cy, Ui.text(0xFFFFFFFF, rad * 1.15f, false));
    }

    /** Метка уровня: карточка с портретом, сердечками сверху, подписью или замком. */
    private void drawPin(Canvas c, int i) {
        Data.Level lv = Data.LEVELS[i];
        RectF r = pinR[i];
        boolean locked = !gs.unlocked(i);
        int hearts = gs.hearts(i);
        boolean done = hearts >= 3;
        int frame = locked ? 0xFFEDE8FF : (done ? 0xFFE9B949 : 0xFFFFFFFF);
        float rad = pinH * 0.12f;

        // стрелка-указатель вниз
        Path tri = new Path();
        tri.moveTo(r.centerX() - pinW * 0.14f, r.bottom);
        tri.lineTo(r.centerX() + pinW * 0.14f, r.bottom);
        tri.lineTo(r.centerX(), r.bottom + pinH * 0.12f);
        tri.close();
        c.drawPath(tri, Ui.fill(0xFF6E8CE0));

        Ui.plate(c, r, 0xFF6E8CE0, rad);
        RectF in = new RectF(r.left + pinW * 0.07f, r.top + pinW * 0.07f, r.right - pinW * 0.07f, r.bottom - pinW * 0.07f);
        Ui.face(c, in, lv.heroine, rad * 0.7f);
        if (locked) c.drawRoundRect(in, rad * 0.7f, rad * 0.7f, Ui.fill(0xCCD8D0F0));
        Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(pinW * 0.025f);
        border.setColor(frame);
        c.drawRoundRect(r, rad, rad, border);

        if (locked) {
            // золотой замок по центру, как в оригинале
            float lr = pinW * 0.26f;
            c.drawCircle(in.centerX(), in.centerY() - pinH * 0.03f, lr, Ui.fill(0xFFF2B233));
            Ui.centerText(c, "[i:lock]", in.centerX(), in.centerY() - pinH * 0.03f, Ui.text(0xFFFFFFFF, lr * 1.2f, false));
        }

        // Сердечки сверху
        float hs = pinH * 0.11f;
        c.drawRoundRect(in.left, in.top, in.right, in.top + hs * 1.5f, rad * 0.7f, rad * 0.7f, Ui.fill(0x88000000));
        for (int k = 0; k < 3; k++) {
            int hc = k < hearts ? 0xFFFF4D6D : 0x66FFFFFF;
            Ui.centerText(c, "[i:heart]", in.centerX() + (k - 1) * hs * 1.25f, in.top + hs * 0.75f,
                    Ui.text(hc, hs * 1.15f, true));
        }

        // Подпись снизу
        float ls = pinH * 0.13f;
        RectF lab = new RectF(in.left, in.bottom - ls * 1.4f, in.right, in.bottom);
        c.drawRoundRect(lab, rad * 0.7f, rad * 0.7f, Ui.fill(locked ? 0xAA7D5BB5 : 0xAA000000));
        String t = locked ? "Закрыто" : lv.room;
        TextPaint tp = Ui.text(0xFFFFFFFF, ls, true);
        while (tp.measureText(t) > lab.width() * 0.95f && tp.getTextSize() > 8f) tp.setTextSize(tp.getTextSize() - 1f);
        Ui.centerText(c, t, lab.centerX(), lab.centerY(), tp);
    }

    private void drawTutorial(Canvas c, int w, int h) {
        RectF t = tutRect(tut);
        float pad = h * 0.01f;
        Path dim = new Path();
        dim.setFillType(Path.FillType.EVEN_ODD);
        dim.addRect(0, 0, w, h, Path.Direction.CW);
        dim.addRoundRect(t.left - pad, t.top - pad, t.right + pad, t.bottom + pad, 24f, 24f, Path.Direction.CW);
        c.drawPath(dim, Ui.fill(0xAA000000));

        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(5f);
        stroke.setColor(0xFFFFD54F);
        c.drawRoundRect(t.left - pad, t.top - pad, t.right + pad, t.bottom + pad, 24f, 24f, stroke);

        float bw = w * 0.5f, bh = h * 0.24f, bx = w * 0.2f;
        float by = t.centerY() < h * 0.5f ? h * 0.62f : h * 0.14f;
        RectF b = new RectF(bx, by, bx + bw, by + bh);
        c.drawRoundRect(b, 28f, 28f, Ui.fill(0xF2FFFFFF));
        Ui.centerText(c, "Саша", b.left + w * 0.05f, b.top + bh * 0.14f, Ui.text(Data.HCOLORS[0], h * 0.045f, true));
        TextPaint tp = Ui.text(0xFF2B2D42, h * 0.042f, false);
        Ui.wrapped(c, TUT_TEXT[tut], b.left + w * 0.02f, b.top + bh * 0.27f, (int) (bw - w * 0.04f), tp);
        Ui.centerText(c, "Нажми, чтобы продолжить", b.centerX(), b.bottom - bh * 0.1f,
                Ui.text(0xFF8E8EA8, h * 0.032f, false));
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) return true;
        if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
        tap(e.getX(), e.getY());
        return true;
    }

    private void tap(float x, float y) {
        if (tut >= 0) {
            tut++;
            if (tut >= TUT_TEXT.length) {
                tut = -1;
                gs.setTutorialDone(true);
            }
            invalidate();
            return;
        }
        if (gearR.contains(x, y)) { a.showSettings(true); return; }
        if (x < getWidth() * 0.07f && y > getHeight() * 0.30f && y < getHeight() * 0.66f) { a.showMenu(); return; }
        if (shopR.contains(x, y)) { a.showShop(); return; }
        if (casinoR.contains(x, y)) { a.showCasino(); return; }
        if (incomeR.contains(x, y)) { claimIncome(); return; }
        for (int i = 0; i < 3; i++) {
            if (bR[i].contains(x, y)) {
                Toast.makeText(a, Data.BOOST_NAME[i] + ": " + Data.BOOST_DESC[i] + " (есть " + gs.booster(i) + ")",
                        Toast.LENGTH_SHORT).show();
                return;
            }
        }
        for (int i = n - 1; i >= 0; i--) {
            placePin(i);
            if (pinR[i].contains(x, y)) {
                onRoomTap(i);
                return;
            }
        }
    }

    private void claimIncome() {
        long now = System.currentTimeMillis();
        if (now - gs.lastIncome() >= INCOME_MS) {
            gs.addDiamonds(INCOME_REWARD);
            gs.setLastIncome(now);
            Toast.makeText(a, "Прибыль компании: +" + INCOME_REWARD + " алмазов", Toast.LENGTH_SHORT).show();
        } else {
            long left = (INCOME_MS - (now - gs.lastIncome())) / 1000L + 1L;
            Toast.makeText(a, "Прибыль будет готова через " + left + " с", Toast.LENGTH_SHORT).show();
        }
        invalidate();
    }

    private void onRoomTap(final int i) {
        final Data.Level lv = Data.LEVELS[i];
        if (!gs.unlocked(i)) {
            new AlertDialog.Builder(a)
                    .setTitle("Открыть комнату «" + lv.room + "»?")
                    .setMessage("Стоимость: " + lv.cost + " алмазов")
                    .setPositiveButton("Открыть", (d, wh) -> {
                        if (gs.spend(lv.cost)) {
                            gs.unlock(i);
                            invalidate();
                        } else {
                            Toast.makeText(a, "Не хватает алмазов", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
            return;
        }
        if (gs.hearts(i) >= 3) {
            Toast.makeText(a, "Комната пройдена. Сцена доступна в галерее.", Toast.LENGTH_SHORT).show();
            return;
        }
        a.startLevel(i);
    }
}
