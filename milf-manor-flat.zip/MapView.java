package com.neighborvn;

import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.text.TextPaint;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

/**
 * Карта: одна большая иллюстрация особняка (assets/map.jpg), которую можно двигать пальцем.
 * Метки уровней стоят в комнатах (координаты fx, fy в Data.LEVELS).
 */
final class MapView extends View {
    private static final long INCOME_MS = 60000L;
    private static final int INCOME_REWARD = 25;

    private static final String[] TUT_TEXT = {
        "Это наш особняк. Карту можно двигать пальцем. В каждой комнате ждёт своя история.",
        "Здесь твой прогресс: сколько сердечек ты уже собрал.",
        "Это алмазы. На них покупают подарки и открывают новые комнаты.",
        "Прибыль компании. Когда круг заполнится, нажми на него и забери алмазы.",
        "Внизу бустеры. Они пригодятся в головоломках.",
        "Справа магазин и галерея. В галерее хранятся сцены, которые ты уже открыл.",
        "Начнём с моей спальни. Нажми на метку с моим портретом!"
    };

    private final MainActivity a;
    private final GameState gs;
    private final int n = Data.LEVELS.length;
    private final RectF clipR = new RectF(), progR = new RectF(), diaR = new RectF(),
            incomeR = new RectF(), gearR = new RectF(), portraitR = new RectF(),
            shopR = new RectF(), galR = new RectF(), boostR = new RectF(),
            upR = new RectF(), downR = new RectF(), tmp = new RectF();
    private final RectF[] pinR = new RectF[n];
    private final RectF[] bR = new RectF[3];
    private Bitmap map;
    private float px, py, mapW, mapH, pinW, pinH;
    private float downX, downY, lastX, lastY;
    private boolean dragging;
    private int tut;
    private Paint sideP;

    MapView(MainActivity a) {
        super(a);
        this.a = a;
        this.gs = a.gs;
        for (int i = 0; i < n; i++) pinR[i] = new RectF();
        for (int i = 0; i < 3; i++) bR[i] = new RectF();
        tut = gs.tutorialDone() ? -1 : 0;
        map = Art.bitmap("map");
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        sideP = new Paint();
        sideP.setShader(new LinearGradient(0, 0, 0, h, 0xFF2A2250, 0xFF14122A, Shader.TileMode.CLAMP));

        clipR.set(0, 0, w * 0.80f, h);
        float imgW = map != null ? map.getWidth() : 1535f, imgH = map != null ? map.getHeight() : 1024f;
        float s = 1.25f * h / imgH;
        mapW = imgW * s;
        mapH = imgH * s;
        px = (clipR.width() - mapW) / 2f;
        py = h * 0.5f - 0.42f * mapH;
        clampPan();
        pinW = h * 0.12f;
        pinH = h * 0.15f;

        float cs = h * 0.09f;
        incomeR.set(w * 0.82f, h * 0.02f, w * 0.82f + cs, h * 0.02f + cs);
        gearR.set(w * 0.82f + cs + w * 0.01f, h * 0.02f, w * 0.82f + 2 * cs + w * 0.01f, h * 0.02f + cs);
        diaR.set(w * 0.82f, h * 0.13f, w * 0.98f, h * 0.21f);
        portraitR.set(w * 0.82f, h * 0.24f, w * 0.98f, h * 0.65f);
        shopR.set(w * 0.82f, h * 0.69f, w * 0.98f, h * 0.78f);
        galR.set(w * 0.82f, h * 0.82f, w * 0.98f, h * 0.91f);
        progR.set(w * 0.02f, h * 0.89f, w * 0.20f, h * 0.98f);
        boostR.set(w * 0.22f, h * 0.88f, w * 0.60f, h * 0.99f);
        float bw = boostR.width() / 3f;
        for (int i = 0; i < 3; i++) {
            bR[i].set(boostR.left + i * bw + 4f, boostR.top, boostR.left + (i + 1) * bw - 4f, boostR.bottom);
        }
        float as = h * 0.08f;
        upR.set(clipR.right - as * 1.3f, h * 0.14f, clipR.right - as * 0.3f, h * 0.14f + as);
        downR.set(clipR.right - as * 1.3f, h * 0.80f - as, clipR.right - as * 0.3f, h * 0.80f);
    }

    private void clampPan() {
        if (mapW <= clipR.width()) px = (clipR.width() - mapW) / 2f;
        else px = Math.max(clipR.right - mapW, Math.min(clipR.left, px));
        if (mapH <= clipR.height()) py = (clipR.height() - mapH) / 2f;
        else py = Math.max(clipR.bottom - mapH, Math.min(clipR.top, py));
    }

    private void placePin(int i) {
        Data.Level lv = Data.LEVELS[i];
        float cx = px + lv.fx * mapW, cy = py + lv.fy * mapH;
        pinR[i].set(cx - pinW / 2f, cy - pinH / 2f, cx + pinW / 2f, cy + pinH / 2f);
    }

    private RectF tutRect(int step) {
        switch (step) {
            case 0: return clipR;
            case 1: return progR;
            case 2: return diaR;
            case 3: return incomeR;
            case 4: return boostR;
            case 5: tmp.set(shopR.left, shopR.top, galR.right, galR.bottom); return tmp;
            default: placePin(0); return pinR[0];
        }
    }

    private void panel(Canvas c, RectF r, String label, float size) {
        Ui.plate(c, r, 0xFF3A3358, r.height() / 3f);
        Ui.centerText(c, label, r.centerX(), r.centerY(), Ui.text(0xFFFFFFFF, size, true));
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawRect(0, 0, w, h, sideP);

        // Карта особняка
        c.save();
        c.clipRect(clipR);
        c.drawRect(clipR, Ui.fill(0xFF000000));
        if (map != null) {
            c.drawBitmap(map, null, new RectF(px, py, px + mapW, py + mapH), new Paint(Paint.FILTER_BITMAP_FLAG));
        } else {
            Ui.centerText(c, "Нет файла map.jpg", clipR.centerX(), clipR.centerY(), Ui.text(0xFFFFFFFF, h * 0.05f, true));
        }
        for (int i = 0; i < n; i++) {
            placePin(i);
            if (RectF.intersects(pinR[i], clipR)) drawPin(c, i);
        }
        c.restore();

        // Стрелки прокрутки
        if (py < clipR.top - 1f) drawArrow(c, upR, "▲");
        if (py + mapH > clipR.bottom + 1f) drawArrow(c, downR, "▼");

        // Верх и право
        drawIncome(c);
        c.drawCircle(gearR.centerX(), gearR.centerY(), gearR.width() / 2f, Ui.fill(0xAA000000));
        Ui.centerText(c, "⚙", gearR.centerX(), gearR.centerY(), Ui.text(0xFFFFFFFF, h * 0.055f, false));
        panel(c, diaR, "💎 " + gs.diamonds(), h * 0.05f);
        Ui.figure(c, portraitR, 0);
        Ui.button(c, shopR, "🛒 Магазин", 0xFF9B7EDE, 0xFFFFFFFF, h * 0.04f);
        Ui.button(c, galR, a.gs.anyScene() ? "🖼 Галерея" : "🔒 Галерея",
                a.gs.anyScene() ? 0xFF9B7EDE : 0xFF55556B, 0xFFFFFFFF, h * 0.04f);

        // Внизу: прогресс и бустеры
        panel(c, progR, "♥ " + gs.totalHearts() + " / " + (n * 3), h * 0.045f);
        for (int i = 0; i < 3; i++) {
            Ui.plate(c, bR[i], 0xFF5A4C8C, 22f);
            Ui.centerText(c, Data.BOOST_ICON[i], bR[i].centerX() - bR[i].width() * 0.15f, bR[i].centerY(),
                    Ui.text(0xFFFFFFFF, bR[i].height() * 0.5f, false));
            Ui.centerText(c, "x" + gs.booster(i), bR[i].centerX() + bR[i].width() * 0.2f, bR[i].centerY(),
                    Ui.text(0xFFFFFFFF, bR[i].height() * 0.3f, true));
        }

        if (tut >= 0) drawTutorial(c, w, h);
        if (!dragging) postInvalidateDelayed(500);
    }

    private void drawArrow(Canvas c, RectF r, String s) {
        c.drawCircle(r.centerX(), r.centerY(), r.width() / 2f, Ui.fill(0xAA000000));
        Ui.centerText(c, s, r.centerX(), r.centerY(), Ui.text(0xFFFFFFFF, r.width() * 0.5f, true));
    }

    private void drawIncome(Canvas c) {
        float p = Math.min(1f, (System.currentTimeMillis() - gs.lastIncome()) / (float) INCOME_MS);
        boolean ready = p >= 1f;
        float cx = incomeR.centerX(), cy = incomeR.centerY(), rad = incomeR.width() / 2f;
        c.drawCircle(cx, cy, rad, Ui.fill(0xAA000000));
        Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(rad * 0.18f);
        arc.setColor(ready ? 0xFFFFD54F : 0xFFE0485F);
        RectF o = new RectF(cx - rad * 0.88f, cy - rad * 0.88f, cx + rad * 0.88f, cy + rad * 0.88f);
        c.drawArc(o, -90f, 360f * p, false, arc);
        Ui.centerText(c, "💰", cx, cy, Ui.text(0xFFFFFFFF, rad * 0.9f, false));
    }

    /** Метка уровня: карточка с портретом, сердечками сверху, подписью или замком. */
    private void drawPin(Canvas c, int i) {
        Data.Level lv = Data.LEVELS[i];
        RectF r = pinR[i];
        boolean locked = !gs.unlocked(i);
        int hearts = gs.hearts(i);
        boolean done = hearts >= 3;
        int frame = locked ? 0xFF6E6E80 : (done ? 0xFFE9B949 : Data.HCOLORS[lv.heroine]);
        float rad = pinH * 0.14f;

        Ui.plate(c, r, frame, rad);
        RectF in = new RectF(r.left + pinW * 0.07f, r.top + pinW * 0.07f, r.right - pinW * 0.07f, r.bottom - pinW * 0.07f);
        Ui.face(c, in, lv.heroine, rad * 0.7f);
        if (locked) c.drawRoundRect(in, rad * 0.7f, rad * 0.7f, Ui.fill(0xAA101018));

        // Сердечки сверху
        float hs = pinH * 0.13f;
        c.drawRoundRect(in.left, in.top, in.right, in.top + hs * 1.5f, rad * 0.7f, rad * 0.7f, Ui.fill(0x88000000));
        for (int k = 0; k < 3; k++) {
            int hc = k < hearts ? 0xFFFF4D6D : 0x66FFFFFF;
            Ui.centerText(c, "♥", in.centerX() + (k - 1) * hs * 1.2f, in.top + hs * 0.75f,
                    Ui.text(hc, hs * 1.15f, true));
        }

        // Подпись снизу
        float ls = pinH * 0.18f;
        RectF lab = new RectF(in.left, in.bottom - ls * 1.4f, in.right, in.bottom);
        c.drawRoundRect(lab, rad * 0.7f, rad * 0.7f, Ui.fill(0xAA000000));
        String t = locked ? "🔒 Закрыто" : lv.room;
        TextPaint tp = Ui.text(0xFFFFFFFF, ls, true);
        while (tp.measureText(t) > lab.width() * 0.95f && tp.getTextSize() > 8f) tp.setTextSize(tp.getTextSize() - 1f);
        Ui.centerText(c, t, lab.centerX(), lab.centerY(), tp);
    }

    private void drawTutorial(Canvas c, int w, int h) {
        RectF t = tutRect(tut);
        float pad = h * 0.01f;
        Path dim = new Path();
        dim.setFillType(Path.FillType.EVEN_ODD);
        dim.addRect(0, 0, w, h, Path.Direction.CW);
        dim.addRoundRect(t.left - pad, t.top - pad, t.right + pad, t.bottom + pad, 24f, 24f, Path.Direction.CW);
        c.drawPath(dim, Ui.fill(0xAA000000));

        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(5f);
        stroke.setColor(0xFFFFD54F);
        c.drawRoundRect(t.left - pad, t.top - pad, t.right + pad, t.bottom + pad, 24f, 24f, stroke);

        float bw = w * 0.5f, bh = h * 0.24f, bx = w * 0.2f;
        float by = t.centerY() < h * 0.5f ? h * 0.62f : h * 0.14f;
        RectF b = new RectF(bx, by, bx + bw, by + bh);
        c.drawRoundRect(b, 28f, 28f, Ui.fill(0xF2FFFFFF));
        Ui.centerText(c, "Саша", b.left + w * 0.05f, b.top + bh * 0.14f, Ui.text(Data.HCOLORS[0], h * 0.045f, true));
        TextPaint tp = Ui.text(0xFF2B2D42, h * 0.042f, false);
        Ui.wrapped(c, TUT_TEXT[tut], b.left + w * 0.02f, b.top + bh * 0.27f, (int) (bw - w * 0.04f), tp);
        Ui.centerText(c, "Нажми, чтобы продолжить", b.centerX(), b.bottom - bh * 0.1f,
                Ui.text(0xFF8E8EA8, h * 0.032f, false));
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = x;
                downY = lastY = y;
                dragging = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (tut >= 0) return true;
                if (!dragging && clipR.contains(downX, downY)
                        && Math.hypot(x - downX, y - downY) > getHeight() * 0.025f) dragging = true;
                if (dragging) {
                    px += x - lastX;
                    py += y - lastY;
                    clampPan();
                    invalidate();
                }
                lastX = x;
                lastY = y;
                return true;
            case MotionEvent.ACTION_UP:
                if (dragging) {
                    dragging = false;
                    invalidate();
                    return true;
                }
                tap(x, y);
                return true;
            default:
                return true;
        }
    }

    private void tap(float x, float y) {
        if (tut >= 0) {
            tut++;
            if (tut >= TUT_TEXT.length) {
                tut = -1;
                gs.setTutorialDone(true);
            }
            invalidate();
            return;
        }
        if (gearR.contains(x, y)) { a.showSettings(true); return; }
        if (shopR.contains(x, y)) { a.showShop(); return; }
        if (galR.contains(x, y)) {
            if (gs.anyScene()) a.openGallery(false);
            else Toast.makeText(a, "Галерея откроется после первой сцены", Toast.LENGTH_SHORT).show();
            return;
        }
        if (incomeR.contains(x, y)) { claimIncome(); return; }
        if (upR.contains(x, y) && py < clipR.top - 1f) { py += getHeight() * 0.3f; clampPan(); invalidate(); return; }
        if (downR.contains(x, y) && py + mapH > clipR.bottom + 1f) { py -= getHeight() * 0.3f; clampPan(); invalidate(); return; }
        for (int i = 0; i < 3; i++) {
            if (bR[i].contains(x, y)) {
                Toast.makeText(a, Data.BOOST_NAME[i] + ": " + Data.BOOST_DESC[i] + " (есть " + gs.booster(i) + ")",
                        Toast.LENGTH_SHORT).show();
                return;
            }
        }
        if (!clipR.contains(x, y)) return;
        for (int i = n - 1; i >= 0; i--) {
            placePin(i);
            if (pinR[i].contains(x, y)) {
                onRoomTap(i);
                return;
            }
        }
    }

    private void claimIncome() {
        long now = System.currentTimeMillis();
        if (now - gs.lastIncome() >= INCOME_MS) {
            gs.addDiamonds(INCOME_REWARD);
            gs.setLastIncome(now);
            Toast.makeText(a, "Прибыль компании: +" + INCOME_REWARD + " 💎", Toast.LENGTH_SHORT).show();
        } else {
            long left = (INCOME_MS - (now - gs.lastIncome())) / 1000L + 1L;
            Toast.makeText(a, "Прибыль будет готова через " + left + " с", Toast.LENGTH_SHORT).show();
        }
        invalidate();
    }

    private void onRoomTap(final int i) {
        final Data.Level lv = Data.LEVELS[i];
        if (!gs.unlocked(i)) {
            new AlertDialog.Builder(a)
                    .setTitle("Открыть комнату «" + lv.room + "»?")
                    .setMessage("Стоимость: " + lv.cost + " алмазов")
                    .setPositiveButton("Открыть", (d, wh) -> {
                        if (gs.spend(lv.cost)) {
                            gs.unlock(i);
                            invalidate();
                        } else {
                            Toast.makeText(a, "Не хватает алмазов", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
            return;
        }
        if (gs.hearts(i) >= 3) {
            Toast.makeText(a, "Комната пройдена. Сцена доступна в галерее.", Toast.LENGTH_SHORT).show();
            return;
        }
        a.startLevel(i);
    }
}
