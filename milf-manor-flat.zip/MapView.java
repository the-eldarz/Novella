package com.neighborvn;

import android.app.AlertDialog;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.text.TextPaint;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

/** Карта особняка: комнаты-уровни, прогресс, алмазы, доход, бустеры, магазин, галерея и обучение. */
final class MapView extends View {
    private static final long INCOME_MS = 60000L;
    private static final int INCOME_REWARD = 25;

    private static final String[] TUT_TEXT = {
        "Это карта нашего особняка. Каждая комната — отдельная история.",
        "Здесь твой прогресс: сколько сердечек ты уже собрал.",
        "Это алмазы. На них покупают подарки и открывают новые комнаты.",
        "Прибыль компании. Когда круг заполнится, нажми на него и забери алмазы.",
        "Внизу бустеры. Они пригодятся в головоломках.",
        "Справа магазин и галерея. В галерее хранятся сцены, которые ты уже открыл.",
        "Начнём с гостиной. Нажми на первую комнату!"
    };

    private final MainActivity a;
    private final GameState gs;
    private final RectF mapR = new RectF(), heartsR = new RectF(), diaR = new RectF(),
            incomeR = new RectF(), gearR = new RectF(), portraitR = new RectF(),
            shopR = new RectF(), galR = new RectF(), boostR = new RectF();
    private final RectF[] roomR = new RectF[10];
    private final RectF[] bR = new RectF[3];
    private final RectF tmp = new RectF();
    private int tut;
    private Paint bgP;

    MapView(MainActivity a) {
        super(a);
        this.a = a;
        this.gs = a.gs;
        for (int i = 0; i < 10; i++) roomR[i] = new RectF();
        for (int i = 0; i < 3; i++) bR[i] = new RectF();
        tut = gs.tutorialDone() ? -1 : 0;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        bgP = new Paint();
        bgP.setShader(new LinearGradient(0, 0, 0, h, 0xFF3B3355, 0xFF1F2A44, Shader.TileMode.CLAMP));

        heartsR.set(w * 0.03f, h * 0.02f, w * 0.23f, h * 0.10f);
        diaR.set(w * 0.50f, h * 0.02f, w * 0.70f, h * 0.10f);
        float s = h * 0.09f;
        incomeR.set(w * 0.80f, h * 0.015f, w * 0.80f + s, h * 0.015f + s);
        gearR.set(w * 0.90f, h * 0.015f, w * 0.90f + s, h * 0.015f + s);

        mapR.set(w * 0.03f, h * 0.13f, w * 0.73f, h * 0.84f);
        portraitR.set(w * 0.77f, h * 0.14f, w * 0.97f, h * 0.60f);
        shopR.set(w * 0.77f, h * 0.65f, w * 0.97f, h * 0.75f);
        galR.set(w * 0.77f, h * 0.78f, w * 0.97f, h * 0.88f);
        boostR.set(w * 0.03f, h * 0.86f, w * 0.43f, h * 0.985f);

        float pad = mapR.width() * 0.015f;
        float rw = (mapR.width() - pad * 6f) / 5f;
        float rh = (mapR.height() - pad * 3f) / 2f;
        for (int i = 0; i < 10; i++) {
            int row = i / 5, col = i % 5;
            float x = mapR.left + pad + col * (rw + pad);
            float y = mapR.top + pad + row * (rh + pad);
            roomR[i].set(x, y, x + rw, y + rh);
        }
        float bw = boostR.width() / 3f;
        for (int i = 0; i < 3; i++) {
            bR[i].set(boostR.left + i * bw + 4f, boostR.top, boostR.left + (i + 1) * bw - 4f, boostR.bottom);
        }
    }

    private RectF tutRect(int step) {
        switch (step) {
            case 0: return mapR;
            case 1: return heartsR;
            case 2: return diaR;
            case 3: return incomeR;
            case 4: return boostR;
            case 5: tmp.set(shopR.left, shopR.top, galR.right, galR.bottom); return tmp;
            default: return roomR[0];
        }
    }

    private void panel(Canvas c, RectF r, String label, float size) {
        c.drawRoundRect(r, r.height() / 3f, r.height() / 3f, Ui.fill(0xAA000000));
        Ui.centerText(c, label, r.centerX(), r.centerY(), Ui.text(0xFFFFFFFF, size, true));
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawRect(0, 0, w, h, bgP);

        panel(c, heartsR, "♥ " + gs.totalHearts() + " / " + (Data.LEVELS.length * 3), h * 0.05f);
        panel(c, diaR, "💎 " + gs.diamonds(), h * 0.05f);
        drawIncome(c);
        c.drawCircle(gearR.centerX(), gearR.centerY(), gearR.width() / 2f, Ui.fill(0xAA000000));
        Ui.centerText(c, "⚙", gearR.centerX(), gearR.centerY(), Ui.text(0xFFFFFFFF, h * 0.055f, false));

        // Карта особняка
        c.drawRoundRect(mapR, 28f, 28f, Ui.fill(0xFF2A3350));
        for (int i = 0; i < 10; i++) drawRoom(c, i, h);

        // Героиня справа
        Ui.portrait(c, portraitR, Data.HCOLORS[0], Data.HINIT[0], Data.HNAMES[0]);
        Ui.button(c, shopR, "🛒 Магазин", 0xFF9B7EDE, 0xFFFFFFFF, h * 0.045f);
        Ui.button(c, galR, "🖼 Галерея", 0xFF9B7EDE, 0xFFFFFFFF, h * 0.045f);

        // Бустеры
        for (int i = 0; i < 3; i++) {
            c.drawRoundRect(bR[i], 22f, 22f, Ui.fill(0xFF4A4468));
            Ui.centerText(c, Data.BOOST_ICON[i], bR[i].centerX(), bR[i].centerY() - bR[i].height() * 0.08f,
                    Ui.text(0xFFFFFFFF, bR[i].height() * 0.5f, false));
            Ui.centerText(c, "x" + gs.booster(i), bR[i].centerX(), bR[i].bottom - bR[i].height() * 0.16f,
                    Ui.text(0xFFFFFFFF, bR[i].height() * 0.22f, true));
        }

        if (tut >= 0) drawTutorial(c, w, h);
        postInvalidateDelayed(500);
    }

    private void drawIncome(Canvas c) {
        float p = Math.min(1f, (System.currentTimeMillis() - gs.lastIncome()) / (float) INCOME_MS);
        boolean ready = p >= 1f;
        float cx = incomeR.centerX(), cy = incomeR.centerY(), rad = incomeR.width() / 2f;
        c.drawCircle(cx, cy, rad, Ui.fill(0xAA000000));
        Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(rad * 0.18f);
        arc.setColor(ready ? 0xFFFFD54F : 0xFFE0485F);
        RectF o = new RectF(cx - rad * 0.88f, cy - rad * 0.88f, cx + rad * 0.88f, cy + rad * 0.88f);
        c.drawArc(o, -90f, 360f * p, false, arc);
        Ui.centerText(c, "💰", cx, cy, Ui.text(0xFFFFFFFF, rad * 0.9f, false));
    }

    private void drawRoom(Canvas c, int i, int h) {
        RectF r = roomR[i];
        Data.Level lv = Data.LEVELS[i];
        boolean locked = !gs.unlocked(i);
        c.drawRoundRect(r, 22f, 22f, Ui.fill(locked ? 0xFF3A3F5C : 0xFF5C557F));
        Ui.centerText(c, lv.room, r.centerX(), r.top + r.height() * 0.13f,
                Ui.text(0xFFFFFFFF, r.height() * 0.11f, true));

        float rad = Math.min(r.width(), r.height()) * 0.24f;
        float cx = r.centerX(), cy = r.centerY() + r.height() * 0.02f;
        int col = locked ? 0xFF777777 : Data.HCOLORS[lv.heroine];
        c.drawCircle(cx, cy, rad, Ui.fill(col));
        String inner = locked ? "🔒" : (lv.heroine == 3 ? "★" : Data.HINIT[lv.heroine]);
        Ui.centerText(c, inner, cx, cy, Ui.text(0xFFFFFFFF, rad * 1.0f, true));

        if (locked) {
            Ui.centerText(c, "💎 " + lv.cost, r.centerX(), r.bottom - r.height() * 0.12f,
                    Ui.text(0xFFFFFFFF, r.height() * 0.11f, true));
        } else {
            int hearts = gs.hearts(i);
            float step = rad * 0.7f;
            for (int k = 0; k < 3; k++) {
                int hc = k < hearts ? 0xFFFF4D6D : 0x55FFFFFF;
                Ui.centerText(c, "♥", cx + (k - 1) * step, r.bottom - r.height() * 0.12f,
                        Ui.text(hc, r.height() * 0.14f, true));
            }
        }
    }

    private void drawTutorial(Canvas c, int w, int h) {
        RectF t = tutRect(tut);
        float pad = h * 0.01f;
        Path dim = new Path();
        dim.setFillType(Path.FillType.EVEN_ODD);
        dim.addRect(0, 0, w, h, Path.Direction.CW);
        dim.addRoundRect(t.left - pad, t.top - pad, t.right + pad, t.bottom + pad, 24f, 24f, Path.Direction.CW);
        c.drawPath(dim, Ui.fill(0xAA000000));

        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(5f);
        stroke.setColor(0xFFFFD54F);
        c.drawRoundRect(t.left - pad, t.top - pad, t.right + pad, t.bottom + pad, 24f, 24f, stroke);

        float bw = w * 0.5f, bh = h * 0.24f, bx = w * 0.2f;
        float by = t.centerY() < h * 0.5f ? h * 0.62f : h * 0.14f;
        RectF b = new RectF(bx, by, bx + bw, by + bh);
        c.drawRoundRect(b, 28f, 28f, Ui.fill(0xF2FFFFFF));
        Ui.centerText(c, "Саша", b.left + w * 0.05f, b.top + bh * 0.14f, Ui.text(Data.HCOLORS[0], h * 0.045f, true));
        TextPaint tp = Ui.text(0xFF2B2D42, h * 0.042f, false);
        Ui.wrapped(c, TUT_TEXT[tut], b.left + w * 0.02f, b.top + bh * 0.27f, (int) (bw - w * 0.04f), tp);
        Ui.centerText(c, "Нажми, чтобы продолжить", b.centerX(), b.bottom - bh * 0.1f,
                Ui.text(0xFF8E8EA8, h * 0.032f, false));
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) return true;
        if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
        float x = e.getX(), y = e.getY();

        if (tut >= 0) {
            tut++;
            if (tut >= TUT_TEXT.length) {
                tut = -1;
                gs.setTutorialDone(true);
            }
            invalidate();
            return true;
        }
        if (gearR.contains(x, y)) { a.showSettings(); return true; }
        if (shopR.contains(x, y)) { a.showShop(); return true; }
        if (galR.contains(x, y)) { a.showGallery(-1); return true; }
        if (incomeR.contains(x, y)) { claimIncome(); return true; }
        for (int i = 0; i < 3; i++) {
            if (bR[i].contains(x, y)) {
                Toast.makeText(a, Data.BOOST_NAME[i] + ": " + Data.BOOST_DESC[i] + " (есть " + gs.booster(i) + ")",
                        Toast.LENGTH_SHORT).show();
                return true;
            }
        }
        for (int i = 0; i < 10; i++) {
            if (roomR[i].contains(x, y)) {
                onRoomTap(i);
                return true;
            }
        }
        return true;
    }

    private void claimIncome() {
        long now = System.currentTimeMillis();
        if (now - gs.lastIncome() >= INCOME_MS) {
            gs.addDiamonds(INCOME_REWARD);
            gs.setLastIncome(now);
            Toast.makeText(a, "Прибыль компании: +" + INCOME_REWARD + " 💎", Toast.LENGTH_SHORT).show();
        } else {
            long left = (INCOME_MS - (now - gs.lastIncome())) / 1000L + 1L;
            Toast.makeText(a, "Прибыль будет готова через " + left + " с", Toast.LENGTH_SHORT).show();
        }
        invalidate();
    }

    private void onRoomTap(final int i) {
        final Data.Level lv = Data.LEVELS[i];
        if (!gs.unlocked(i)) {
            new AlertDialog.Builder(a)
                    .setTitle("Открыть комнату «" + lv.room + "»?")
                    .setMessage("Стоимость: " + lv.cost + " алмазов")
                    .setPositiveButton("Открыть", (d, wh) -> {
                        if (gs.spend(lv.cost)) {
                            gs.unlock(i);
                            invalidate();
                        } else {
                            Toast.makeText(a, "Не хватает алмазов", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
            return;
        }
        if (gs.hearts(i) >= 3) {
            Toast.makeText(a, "Комната пройдена. Сцена доступна в галерее.", Toast.LENGTH_SHORT).show();
            return;
        }
        a.startLevel(i);
    }
}
