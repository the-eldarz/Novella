package com.neighborvn;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * SVG-иконки вместо смайликов. Иконки лежат в этом файле как SVG-разметка (viewBox 24x24).
 * Свою иконку можно подменить файлом icon_<имя>.svg в корне репозитория (он попадёт в assets).
 * В тексте иконка пишется токеном [i:имя], например "[i:gem] 250". Цвет currentColor берётся из цвета текста.
 */
final class Icons {
    private Icons() {}

    private static final HashMap<String, String> SRC = new HashMap<>();
    private static final HashMap<String, Icon> CACHE = new HashMap<>();
    private static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);

    private static final class Shape {
        Path path = new Path();
        int fill = 0xFF000000;
        boolean fillNone, fillCur, strokeNone = true, strokeCur;
        int stroke;
        float sw = 1f, opacity = 1f;
        Paint.Cap cap = Paint.Cap.BUTT;
        Paint.Join join = Paint.Join.MITER;
    }

    private static final class Icon {
        float vb = 24f;
        final ArrayList<Shape> shapes = new ArrayList<>();
    }

    static void put(String n, String s) { SRC.put(n, s); }

    static {
        put("gem", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><polygon points=\"7,3 17,3 22,9 12,21 2,9\" fill=\"#35B6F2\"/><polygon points=\"7,3 12,9 2,9\" fill=\"#7FD6FA\"/><polygon points=\"7,3 17,3 12,9\" fill=\"#B9EBFD\"/><polygon points=\"17,3 22,9 12,9\" fill=\"#5BC4F5\"/><polygon points=\"2,9 12,9 12,21\" fill=\"#2A9FE0\"/><polygon points=\"22,9 12,9 12,21\" fill=\"#1E88C9\"/></svg>");
        put("ticket", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><rect x=\"2\" y=\"6\" width=\"20\" height=\"12\" rx=\"2.2\" fill=\"#F6B93B\"/><polygon points=\"8.30,8.20 9.24,10.71 11.91,10.83 9.82,12.49 10.53,15.07 8.30,13.60 6.07,15.07 6.78,12.49 4.69,10.83 7.36,10.71\" fill=\"#FFFFFF\"/><rect x=\"14.6\" y=\"7.6\" width=\"1.4\" height=\"2.2\" rx=\"0.5\" fill=\"#B8791A\"/><rect x=\"14.6\" y=\"10.9\" width=\"1.4\" height=\"2.2\" rx=\"0.5\" fill=\"#B8791A\"/><rect x=\"14.6\" y=\"14.2\" width=\"1.4\" height=\"2.2\" rx=\"0.5\" fill=\"#B8791A\"/><rect x=\"17.6\" y=\"9\" width=\"2.6\" height=\"6\" rx=\"1\" fill=\"#FFE29A\"/></svg>");
        put("heart", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M12 21 C12 21 3 14.6 3 8.6 C3 5.6 5.2 3.6 7.8 3.6 C9.6 3.6 11.2 4.6 12 6.1 C12.8 4.6 14.4 3.6 16.2 3.6 C18.8 3.6 21 5.6 21 8.6 C21 14.6 12 21 12 21 Z\" fill=\"currentColor\"/></svg>");
        put("heart_outline", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M12 21 C12 21 3 14.6 3 8.6 C3 5.6 5.2 3.6 7.8 3.6 C9.6 3.6 11.2 4.6 12 6.1 C12.8 4.6 14.4 3.6 16.2 3.6 C18.8 3.6 21 5.6 21 8.6 C21 14.6 12 21 12 21 Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linejoin=\"round\"/></svg>");
        put("crown", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M3 8 L7.5 12.2 L12 5 L16.5 12.2 L21 8 L19.2 18.5 H4.8 Z\" fill=\"#FFC83D\" stroke=\"#E39B00\" stroke-width=\"0.8\" stroke-linejoin=\"round\"/><rect x=\"4.8\" y=\"18.5\" width=\"14.4\" height=\"2.6\" rx=\"1\" fill=\"#E39B00\"/><path d=\"M10.7 14.2 C10.7 13.482 11.282 12.9 12 12.9 C12.718 12.9 13.3 13.482 13.3 14.2 C13.3 14.918 12.718 15.5 12 15.5 C11.282 15.5 10.7 14.918 10.7 14.2 Z\" fill=\"#FF5C7A\"/><path d=\"M7.1 15 C7.1 14.5029 7.50294 14.1 8 14.1 C8.49706 14.1 8.9 14.5029 8.9 15 C8.9 15.4971 8.49706 15.9 8 15.9 C7.50294 15.9 7.1 15.4971 7.1 15 Z\" fill=\"#6FD3FF\"/><path d=\"M15.1 15 C15.1 14.5029 15.5029 14.1 16 14.1 C16.4971 14.1 16.9 14.5029 16.9 15 C16.9 15.4971 16.4971 15.9 16 15.9 C15.5029 15.9 15.1 15.4971 15.1 15 Z\" fill=\"#6FD3FF\"/></svg>");
        put("gear", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M19.26 9.75 L22.05 10.27 L22.05 13.73 L19.26 14.25 L18.72 15.55 L20.33 17.89 L17.89 20.33 L15.55 18.72 L14.25 19.26 L13.73 22.05 L10.27 22.05 L9.75 19.26 L8.45 18.72 L6.11 20.33 L3.67 17.89 L5.28 15.55 L4.74 14.25 L1.95 13.73 L1.95 10.27 L4.74 9.75 L5.28 8.45 L3.67 6.11 L6.11 3.67 L8.45 5.28 L9.75 4.74 L10.27 1.95 L13.73 1.95 L14.25 4.74 L15.55 5.28 L17.89 3.67 L20.33 6.11 L18.72 8.45 Z M8.4 12 C8.4 10.0118 10.0118 8.4 12 8.4 C13.9882 8.4 15.6 10.0118 15.6 12 C15.6 13.9882 13.9882 15.6 12 15.6 C10.0118 15.6 8.4 13.9882 8.4 12 Z\" fill=\"currentColor\" fill-rule=\"evenodd\"/></svg>");
        put("bag", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M8.4 8 C5 11 3.8 14 3.8 16.6 C3.8 19.6 7 21.2 12 21.2 C17 21.2 20.2 19.6 20.2 16.6 C20.2 14 19 11 15.6 8 Z\" fill=\"#C98B2B\"/><path d=\"M8.2 2.8 H15.8 L14.6 6 H9.4 Z\" fill=\"#E3A63E\"/><rect x=\"8.6\" y=\"6\" width=\"6.8\" height=\"2.6\" rx=\"1\" fill=\"#E3A63E\"/><path d=\"M8.6 15 C8.6 13.1222 10.1222 11.6 12 11.6 C13.8778 11.6 15.4 13.1222 15.4 15 C15.4 16.8778 13.8778 18.4 12 18.4 C10.1222 18.4 8.6 16.8778 8.6 15 Z\" fill=\"#FFD95A\"/><rect x=\"11.3\" y=\"12.6\" width=\"1.4\" height=\"4.8\" rx=\"0.6\" fill=\"#C98B2B\"/></svg>");
        put("lock", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M8 10.5 V7.6 C8 5.4 9.8 3.6 12 3.6 C14.2 3.6 16 5.4 16 7.6 V10.5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.3\" stroke-linecap=\"round\"/><rect x=\"5\" y=\"10\" width=\"14\" height=\"11\" rx=\"2.4\" fill=\"currentColor\"/><path d=\"M10.4 14.6 C10.4 13.7163 11.1163 13 12 13 C12.8837 13 13.6 13.7163 13.6 14.6 C13.6 15.4837 12.8837 16.2 12 16.2 C11.1163 16.2 10.4 15.4837 10.4 14.6 Z\" fill=\"#000000\" opacity=\"0.35\"/><rect x=\"11.2\" y=\"15\" width=\"1.6\" height=\"3.2\" rx=\"0.7\" fill=\"#000000\" opacity=\"0.35\"/></svg>");
        put("play", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><polygon points=\"7,4.5 19.5,12 7,19.5\" fill=\"currentColor\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linejoin=\"round\"/></svg>");
        put("close", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M5.5 5.5 L18.5 18.5 M18.5 5.5 L5.5 18.5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"3\" stroke-linecap=\"round\"/></svg>");
        put("check", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M4.5 12.5 L9.8 17.8 L19.8 6.6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"3.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>");
        put("back", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M20 12 H5 M11.5 5.5 L5 12 L11.5 18.5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>");
        put("next", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M4 12 H19 M12.5 5.5 L19 12 L12.5 18.5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>");
        put("gift", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><rect x=\"3\" y=\"10\" width=\"18\" height=\"11\" rx=\"1.6\" fill=\"#E0485F\"/><rect x=\"2\" y=\"7\" width=\"20\" height=\"4.2\" rx=\"1.2\" fill=\"#F0687E\"/><rect x=\"10.4\" y=\"7\" width=\"3.2\" height=\"14\" fill=\"#FFD95A\"/><path d=\"M12 7 C10 1.8 5 2.6 6.6 5.8 C7.6 7.4 10.6 7 12 7 Z\" fill=\"#FFD95A\"/><path d=\"M12 7 C14 1.8 19 2.6 17.4 5.8 C16.4 7.4 13.4 7 12 7 Z\" fill=\"#FFD95A\"/></svg>");
        put("hammer", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><polygon points=\"10.2,12.8 12.8,10.2 20.8,18.2 18.2,20.8\" fill=\"#C98B5A\"/><polygon points=\"3.2,8.6 8.6,3.2 15.8,10.4 10.4,15.8\" fill=\"#9AA5B4\"/><polygon points=\"10.4,15.8 15.8,10.4 14.4,9 9,14.4\" fill=\"#6E7A8A\"/><polygon points=\"3.2,8.6 8.6,3.2 9.7,4.3 4.3,9.7\" fill=\"#C7CFDA\"/></svg>");
        put("shuffle", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M3 7 H7 C11.5 7 12.5 17 17 17 H19.5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.3\" stroke-linecap=\"round\"/><path d=\"M3 17 H7 C8.6 17 9.8 15.8 10.8 14.2 M13.2 9.8 C14.2 8.2 15.4 7 17 7 H19.5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.3\" stroke-linecap=\"round\"/><polygon points=\"18.5,3.8 23,7 18.5,10.2\" fill=\"currentColor\"/><polygon points=\"18.5,13.8 23,17 18.5,20.2\" fill=\"currentColor\"/></svg>");
        put("plus", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M12 4.5 V19.5 M4.5 12 H19.5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"3.4\" stroke-linecap=\"round\"/></svg>");
        put("bouquet", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M12 21 L8.5 12 M12 21 L12 11 M12 21 L15.5 12\" fill=\"none\" stroke=\"#3E9B4F\" stroke-width=\"1.6\" stroke-linecap=\"round\"/><path d=\"M4.9 9.4 C4.9 7.68792 6.28792 6.3 8 6.3 C9.71208 6.3 11.1 7.68792 11.1 9.4 C11.1 11.1121 9.71208 12.5 8 12.5 C6.28792 12.5 4.9 11.1121 4.9 9.4 Z\" fill=\"#FF7BAC\"/><path d=\"M12.9 9.4 C12.9 7.68792 14.2879 6.3 16 6.3 C17.7121 6.3 19.1 7.68792 19.1 9.4 C19.1 11.1121 17.7121 12.5 16 12.5 C14.2879 12.5 12.9 11.1121 12.9 9.4 Z\" fill=\"#FFB84D\"/><path d=\"M8.7 6.6 C8.7 4.77746 10.1775 3.3 12 3.3 C13.8225 3.3 15.3 4.77746 15.3 6.6 C15.3 8.42254 13.8225 9.9 12 9.9 C10.1775 9.9 8.7 8.42254 8.7 6.6 Z\" fill=\"#FF5C7A\"/><path d=\"M7 9.4 C7 8.84772 7.44772 8.4 8 8.4 C8.55228 8.4 9 8.84772 9 9.4 C9 9.95228 8.55228 10.4 8 10.4 C7.44772 10.4 7 9.95228 7 9.4 Z\" fill=\"#FFF3B0\"/><path d=\"M15 9.4 C15 8.84772 15.4477 8.4 16 8.4 C16.5523 8.4 17 8.84772 17 9.4 C17 9.95228 16.5523 10.4 16 10.4 C15.4477 10.4 15 9.95228 15 9.4 Z\" fill=\"#FFF3B0\"/><path d=\"M10.9 6.6 C10.9 5.99249 11.3925 5.5 12 5.5 C12.6075 5.5 13.1 5.99249 13.1 6.6 C13.1 7.20751 12.6075 7.7 12 7.7 C11.3925 7.7 10.9 7.20751 10.9 6.6 Z\" fill=\"#FFF3B0\"/><polygon points=\"6.2,13.2 17.8,13.2 12,22.6\" fill=\"#FFE8A8\"/><polygon points=\"9,13.2 15,13.2 12,22.6\" fill=\"#F3C969\"/></svg>");
        put("candy", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><polygon points=\"1.8,6.8 8.8,11 8.8,13 1.8,17.2\" fill=\"#FFB3D1\"/><polygon points=\"22.2,6.8 15.2,11 15.2,13 22.2,17.2\" fill=\"#FFB3D1\"/><path d=\"M6.4 12 C6.4 8.90721 8.90721 6.4 12 6.4 C15.0928 6.4 17.6 8.90721 17.6 12 C17.6 15.0928 15.0928 17.6 12 17.6 C8.90721 17.6 6.4 15.0928 6.4 12 Z\" fill=\"#FF5C9A\"/><path d=\"M8.3 16.2 C11 13 13 11 15.8 8.2 L17 9.6 C14.5 12 12.5 14 9.8 17.2 Z\" fill=\"#FFFFFF\" opacity=\"0.8\"/><path d=\"M8.7 10 C8.7 9.17157 9.37157 8.5 10.2 8.5 C11.0284 8.5 11.7 9.17157 11.7 10 C11.7 10.8284 11.0284 11.5 10.2 11.5 C9.37157 11.5 8.7 10.8284 8.7 10 Z\" fill=\"#FFFFFF\" opacity=\"0.5\"/></svg>");
        put("ribbon", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><polygon points=\"10.6,13 7.4,21.5 10.6,19.4 12,21.8\" fill=\"#E03A5E\"/><polygon points=\"13.4,13 16.6,21.5 13.4,19.4 12,21.8\" fill=\"#E03A5E\"/><path d=\"M12 12 C8 5.6 2.6 5.8 3 9.4 C3.4 12.6 8.4 14 12 12 Z\" fill=\"#FF5C7A\"/><path d=\"M12 12 C16 5.6 21.4 5.8 21 9.4 C20.6 12.6 15.6 14 12 12 Z\" fill=\"#FF5C7A\"/><path d=\"M9.7 12 C9.7 10.7297 10.7297 9.7 12 9.7 C13.2703 9.7 14.3 10.7297 14.3 12 C14.3 13.2703 13.2703 14.3 12 14.3 C10.7297 14.3 9.7 13.2703 9.7 12 Z\" fill=\"#E03A5E\"/></svg>");
        put("music", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><rect x=\"10.6\" y=\"3.6\" width=\"2.2\" height=\"13.6\" fill=\"currentColor\"/><path d=\"M5.2 17.4 C5.2 15.5222 6.72223 14 8.6 14 C10.4778 14 12 15.5222 12 17.4 C12 19.2778 10.4778 20.8 8.6 20.8 C6.72223 20.8 5.2 19.2778 5.2 17.4 Z\" fill=\"currentColor\"/><path d=\"M12.8 3.6 C15 4.6 18 5.8 18 9.4 C16 8.2 14.4 7.8 12.8 7.8 Z\" fill=\"currentColor\"/></svg>");
        put("speaker", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><polygon points=\"2.5,9 7,9 12.5,4.8 12.5,19.2 7,15 2.5,15\" fill=\"currentColor\" stroke=\"currentColor\" stroke-width=\"1\" stroke-linejoin=\"round\"/><path d=\"M15.6 9 C17.2 10.6 17.2 13.4 15.6 15\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M18.2 6.2 C21.4 9.4 21.4 14.6 18.2 17.8\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/></svg>");
        put("globe", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M3 12 C3 7.02944 7.02944 3 12 3 C16.9706 3 21 7.02944 21 12 C21 16.9706 16.9706 21 12 21 C7.02944 21 3 16.9706 3 12 Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M12 3 C7.6 7 7.6 17 12 21 C16.4 17 16.4 7 12 3 Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\" stroke-linejoin=\"round\"/><path d=\"M3 12 H21 M4.6 7.6 H19.4 M4.6 16.4 H19.4\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\"/></svg>");
        put("chevron_down", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><polygon points=\"5.5,8.5 18.5,8.5 12,16.5\" fill=\"currentColor\" stroke=\"currentColor\" stroke-width=\"1.2\" stroke-linejoin=\"round\"/></svg>");
        put("hand", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><polygon points=\"6,2.8 6,19.4 10.4,15.2 13.4,21.6 16.2,20.3 13.2,14 19.4,14\" fill=\"#FFFFFF\" stroke=\"#2B2D42\" stroke-width=\"1.5\" stroke-linejoin=\"round\"/></svg>");
        put("coffee", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M17.2 10 H19 C21.4 10 21.4 15.6 18.6 15.6 H17\" fill=\"none\" stroke=\"#F4EEE8\" stroke-width=\"1.9\" stroke-linecap=\"round\"/><path d=\"M3.8 9 H17.4 V15 C17.4 18.2 15.2 20 12.2 20 H9 C6 20 3.8 18.2 3.8 15 Z\" fill=\"#F4EEE8\"/><ellipse cx=\"10.6\" cy=\"9\" rx=\"6.8\" ry=\"1.7\" fill=\"#7B4A2A\"/><ellipse cx=\"11\" cy=\"21\" rx=\"8.4\" ry=\"1.4\" fill=\"#D9CFC7\"/><path d=\"M8 6.2 C6.8 4.8 9.2 3.6 8 2 M12.4 6.2 C11.2 4.8 13.6 3.6 12.4 2\" fill=\"none\" stroke=\"#FFFFFF\" stroke-width=\"1.3\" stroke-linecap=\"round\" opacity=\"0.85\"/></svg>");
        put("cake", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><rect x=\"3\" y=\"15\" width=\"18\" height=\"5.6\" rx=\"1.8\" fill=\"#E9A465\"/><rect x=\"3\" y=\"11.6\" width=\"18\" height=\"3.8\" fill=\"#FFF4E6\"/><rect x=\"3\" y=\"8\" width=\"18\" height=\"4.2\" rx=\"1.6\" fill=\"#E9A465\"/><ellipse cx=\"12\" cy=\"7.6\" rx=\"9\" ry=\"3\" fill=\"#FF8FB1\"/><ellipse cx=\"12\" cy=\"7\" rx=\"6.6\" ry=\"1.6\" fill=\"#FFB8CF\"/><path d=\"M9.9 4.4 C9.9 3.2402 10.8402 2.3 12 2.3 C13.1598 2.3 14.1 3.2402 14.1 4.4 C14.1 5.5598 13.1598 6.5 12 6.5 C10.8402 6.5 9.9 5.5598 9.9 4.4 Z\" fill=\"#E0293F\"/><path d=\"M12 2.4 C12.4 1.4 13.4 1 14 1.2\" fill=\"none\" stroke=\"#3E9B4F\" stroke-width=\"1\" stroke-linecap=\"round\"/></svg>");
        put("rose", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><rect x=\"11.2\" y=\"14\" width=\"1.7\" height=\"8\" rx=\"0.6\" fill=\"#3E9B4F\"/><path d=\"M12.9 18 C15.6 16.4 17.8 16.8 18.8 18.4 C16.8 20 14.4 19.8 12.9 18 Z\" fill=\"#4CAF50\"/><path d=\"M11.2 19 C8.8 17.8 6.8 18.2 6 19.6 C7.8 21 9.8 20.8 11.2 19 Z\" fill=\"#4CAF50\"/><path d=\"M5.6 9 C5.6 5.46538 8.46538 2.6 12 2.6 C15.5346 2.6 18.4 5.46538 18.4 9 C18.4 12.5346 15.5346 15.4 12 15.4 C8.46538 15.4 5.6 12.5346 5.6 9 Z\" fill=\"#E0344F\"/><path d=\"M8.6 9.4 C8.4 6.6 14.8 6.4 15.2 9.4 C15.4 12.2 9.8 12.6 10.2 9.8 C10.5 8.6 13 8.6 13 9.8\" fill=\"none\" stroke=\"#A31B33\" stroke-width=\"1.2\" stroke-linecap=\"round\"/></svg>");
        put("strawberry", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M12 21.4 C6 18.6 4.4 12.6 6 9.6 C7.4 7.6 10 7.8 12 8.8 C14 7.8 16.6 7.6 18 9.6 C19.6 12.6 18 18.6 12 21.4 Z\" fill=\"#F2384F\"/><ellipse cx=\"9\" cy=\"12.5\" rx=\"0.6\" ry=\"0.9\" fill=\"#FFE6A8\"/><ellipse cx=\"12\" cy=\"11.6\" rx=\"0.6\" ry=\"0.9\" fill=\"#FFE6A8\"/><ellipse cx=\"15\" cy=\"12.5\" rx=\"0.6\" ry=\"0.9\" fill=\"#FFE6A8\"/><ellipse cx=\"8.4\" cy=\"15.4\" rx=\"0.6\" ry=\"0.9\" fill=\"#FFE6A8\"/><ellipse cx=\"11.2\" cy=\"15\" rx=\"0.6\" ry=\"0.9\" fill=\"#FFE6A8\"/><ellipse cx=\"14\" cy=\"15.4\" rx=\"0.6\" ry=\"0.9\" fill=\"#FFE6A8\"/><ellipse cx=\"16\" cy=\"15.6\" rx=\"0.6\" ry=\"0.9\" fill=\"#FFE6A8\"/><ellipse cx=\"10\" cy=\"18\" rx=\"0.6\" ry=\"0.9\" fill=\"#FFE6A8\"/><ellipse cx=\"13\" cy=\"18\" rx=\"0.6\" ry=\"0.9\" fill=\"#FFE6A8\"/><path d=\"M12 9.2 L8.4 6.4 L10.8 6.8 L12 3.6 L13.2 6.8 L15.6 6.4 Z\" fill=\"#3FA34D\"/></svg>");
        put("honey", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M6 9 C6 8 7 7.5 8 7.5 H16 C17 7.5 18 8 18 9 V18 C18 20 16.6 21 15 21 H9 C7.4 21 6 20 6 18 Z\" fill=\"#F4A81D\"/><path d=\"M6 9.4 H18 V11 C16.6 11.9 15.6 11.2 14.6 12 C13.6 11.2 12.2 12 11.2 11.2 C9.6 11.9 7.6 11.6 6 11 Z\" fill=\"#FFC94D\"/><rect x=\"7\" y=\"4.4\" width=\"10\" height=\"3.4\" rx=\"1.2\" fill=\"#8B5A2B\"/><rect x=\"8.6\" y=\"13\" width=\"6.8\" height=\"5\" rx=\"1.2\" fill=\"#FFE9A8\"/><rect x=\"7.4\" y=\"11\" width=\"1.2\" height=\"7\" rx=\"0.6\" fill=\"#FFFFFF\" opacity=\"0.35\"/></svg>");
        put("sparkle", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M11 2.5 C11.8 8 15 11.2 20.5 12 C15 12.8 11.8 16 11 21.5 C10.2 16 7 12.8 1.5 12 C7 11.2 10.2 8 11 2.5 Z\" fill=\"#FFE066\"/><path d=\"M19 1.5 C19.3 3.6 20.2 4.5 22.3 4.8 C20.2 5.1 19.3 6 19 8.1 C18.7 6 17.8 5.1 15.7 4.8 C17.8 4.5 18.7 3.6 19 1.5 Z\" fill=\"#FFFFFF\"/><path d=\"M19.5 16.5 C19.7 17.8 20.2 18.3 21.5 18.5 C20.2 18.7 19.7 19.2 19.5 20.5 C19.3 19.2 18.8 18.7 17.5 18.5 C18.8 18.3 19.3 17.8 19.5 16.5 Z\" fill=\"#FFF3B0\"/></svg>");
        put("lips", "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\"><path d=\"M2.5 12 C5 11.4 8.5 11.4 12 12.2 C15.5 11.4 19 11.4 21.5 12 C19.5 17.8 15.5 19.4 12 19.4 C8.5 19.4 4.5 17.8 2.5 12 Z\" fill=\"#FF4A63\"/><path d=\"M2.5 12 C5 7.8 8.6 7.4 12 9.6 C15.4 7.4 19 7.8 21.5 12 C19 11.4 15.5 11.4 12 12.2 C8.5 11.4 5 11.4 2.5 12 Z\" fill=\"#E0243F\"/><path d=\"M7 14.6 C9.4 16 14.6 16 17 14.6\" fill=\"none\" stroke=\"#FFFFFF\" stroke-width=\"1.1\" stroke-linecap=\"round\" opacity=\"0.45\"/></svg>");
    }

    // ---------- рисование ----------

    static void draw(Canvas c, String name, float cx, float cy, float size, int tint) {
        draw(c, name, cx, cy, size, tint, 255);
    }

    static void draw(Canvas c, String name, float cx, float cy, float size, int tint, int alpha) {
        Icon ic = get(name);
        if (ic == null || size <= 0f) return;
        float s = size / ic.vb;
        c.save();
        c.translate(cx - size / 2f, cy - size / 2f);
        c.scale(s, s);
        for (Shape sh : ic.shapes) {
            if (!sh.fillNone) {
                int col = sh.fillCur ? tint : sh.fill;
                P.reset();
                P.setAntiAlias(true);
                P.setStyle(Paint.Style.FILL);
                P.setColor(col);
                P.setAlpha(Math.round(Color.alpha(col) * sh.opacity * alpha / 255f));
                c.drawPath(sh.path, P);
            }
            if (!sh.strokeNone) {
                int col = sh.strokeCur ? tint : sh.stroke;
                P.reset();
                P.setAntiAlias(true);
                P.setStyle(Paint.Style.STROKE);
                P.setStrokeWidth(sh.sw);
                P.setStrokeCap(sh.cap);
                P.setStrokeJoin(sh.join);
                P.setColor(col);
                P.setAlpha(Math.round(Color.alpha(col) * sh.opacity * alpha / 255f));
                c.drawPath(sh.path, P);
            }
        }
        c.restore();
    }

    // ---------- загрузка и разбор SVG ----------

    private static Icon get(String name) {
        Icon ic = CACHE.get(name);
        if (ic != null) return ic;
        if (CACHE.containsKey(name)) return null;
        String src = Art.text("icon_" + name + ".svg");
        if (src == null) src = SRC.get(name);
        if (src != null) {
            try {
                ic = parse(src);
            } catch (Exception ex) {
                ic = null;
            }
        }
        CACHE.put(name, ic);
        return ic;
    }

    private static Icon parse(String svg) throws Exception {
        Icon ic = new Icon();
        XmlPullParser xp = Xml.newPullParser();
        xp.setInput(new StringReader(svg));
        int ev = xp.getEventType();
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                String tag = xp.getName();
                if ("svg".equals(tag)) {
                    String vb = xp.getAttributeValue(null, "viewBox");
                    if (vb != null) {
                        String[] t = vb.trim().split("[ ,]+");
                        if (t.length == 4) ic.vb = Math.max(Float.parseFloat(t[2]), Float.parseFloat(t[3]));
                    }
                } else {
                    Shape sh = shape(xp, tag);
                    if (sh != null) ic.shapes.add(sh);
                }
            }
            ev = xp.next();
        }
        return ic;
    }

    private static float f(XmlPullParser xp, String n, float def) {
        String v = xp.getAttributeValue(null, n);
        if (v == null) return def;
        try {
            return Float.parseFloat(v);
        } catch (NumberFormatException ex) {
            return def;
        }
    }

    private static Shape shape(XmlPullParser xp, String tag) {
        Shape sh = new Shape();
        if ("path".equals(tag)) {
            String d = xp.getAttributeValue(null, "d");
            if (d == null) return null;
            parsePath(d, sh.path);
        } else if ("circle".equals(tag)) {
            sh.path.addCircle(f(xp, "cx", 0), f(xp, "cy", 0), f(xp, "r", 0), Path.Direction.CW);
        } else if ("ellipse".equals(tag)) {
            float cx = f(xp, "cx", 0), cy = f(xp, "cy", 0), rx = f(xp, "rx", 0), ry = f(xp, "ry", 0);
            sh.path.addOval(new android.graphics.RectF(cx - rx, cy - ry, cx + rx, cy + ry), Path.Direction.CW);
        } else if ("rect".equals(tag)) {
            float x = f(xp, "x", 0), y = f(xp, "y", 0), w = f(xp, "width", 0), h = f(xp, "height", 0);
            float rx = f(xp, "rx", 0);
            sh.path.addRoundRect(new android.graphics.RectF(x, y, x + w, y + h), rx, rx, Path.Direction.CW);
        } else if ("polygon".equals(tag) || "polyline".equals(tag)) {
            String pts = xp.getAttributeValue(null, "points");
            if (pts == null) return null;
            String[] t = pts.trim().split("[ ,]+");
            for (int i = 0; i + 1 < t.length; i += 2) {
                float x = Float.parseFloat(t[i]), y = Float.parseFloat(t[i + 1]);
                if (i == 0) sh.path.moveTo(x, y);
                else sh.path.lineTo(x, y);
            }
            if ("polygon".equals(tag)) sh.path.close();
        } else if ("line".equals(tag)) {
            sh.path.moveTo(f(xp, "x1", 0), f(xp, "y1", 0));
            sh.path.lineTo(f(xp, "x2", 0), f(xp, "y2", 0));
        } else {
            return null;
        }

        String fill = xp.getAttributeValue(null, "fill");
        if (fill == null) {
            sh.fill = 0xFF000000;
        } else if ("none".equals(fill)) {
            sh.fillNone = true;
        } else if ("currentColor".equals(fill)) {
            sh.fillCur = true;
        } else {
            sh.fill = color(fill);
        }
        String stroke = xp.getAttributeValue(null, "stroke");
        if (stroke != null && !"none".equals(stroke)) {
            sh.strokeNone = false;
            if ("currentColor".equals(stroke)) sh.strokeCur = true;
            else sh.stroke = color(stroke);
        }
        sh.sw = f(xp, "stroke-width", 1f);
        sh.opacity = f(xp, "opacity", 1f);
        if ("round".equals(xp.getAttributeValue(null, "stroke-linecap"))) sh.cap = Paint.Cap.ROUND;
        else if ("square".equals(xp.getAttributeValue(null, "stroke-linecap"))) sh.cap = Paint.Cap.SQUARE;
        if ("round".equals(xp.getAttributeValue(null, "stroke-linejoin"))) sh.join = Paint.Join.ROUND;
        else if ("bevel".equals(xp.getAttributeValue(null, "stroke-linejoin"))) sh.join = Paint.Join.BEVEL;
        if ("evenodd".equals(xp.getAttributeValue(null, "fill-rule"))) sh.path.setFillType(Path.FillType.EVEN_ODD);
        return sh;
    }

    private static int color(String s) {
        try {
            String t = s.trim();
            if (t.length() == 4 && t.charAt(0) == '#') {
                t = "#" + t.charAt(1) + t.charAt(1) + t.charAt(2) + t.charAt(2) + t.charAt(3) + t.charAt(3);
            }
            return Color.parseColor(t);
        } catch (Exception ex) {
            return 0xFF000000;
        }
    }

    // Разбор данных пути d: M L H V C S Q T Z (заглавные и строчные), без дуг.
    private static void parsePath(String d, Path p) {
        int[] pos = {0};
        char cmd = 0;
        float x = 0, y = 0, sx = 0, sy = 0, lcx = 0, lcy = 0;
        char prev = 0;
        int n = d.length();
        while (true) {
            skip(d, pos);
            if (pos[0] >= n) break;
            char ch = d.charAt(pos[0]);
            if (Character.isLetter(ch)) {
                cmd = ch;
                pos[0]++;
                if (cmd == 'Z' || cmd == 'z') {
                    p.close();
                    x = sx;
                    y = sy;
                    prev = 'Z';
                    continue;
                }
            } else if (cmd == 'M') {
                cmd = 'L';
            } else if (cmd == 'm') {
                cmd = 'l';
            }
            boolean rel = Character.isLowerCase(cmd);
            switch (Character.toUpperCase(cmd)) {
                case 'M': {
                    float a = num(d, pos), b = num(d, pos);
                    x = rel ? x + a : a;
                    y = rel ? y + b : b;
                    p.moveTo(x, y);
                    sx = x;
                    sy = y;
                    break;
                }
                case 'L': {
                    float a = num(d, pos), b = num(d, pos);
                    x = rel ? x + a : a;
                    y = rel ? y + b : b;
                    p.lineTo(x, y);
                    break;
                }
                case 'H': {
                    float a = num(d, pos);
                    x = rel ? x + a : a;
                    p.lineTo(x, y);
                    break;
                }
                case 'V': {
                    float b = num(d, pos);
                    y = rel ? y + b : b;
                    p.lineTo(x, y);
                    break;
                }
                case 'C': {
                    float x1 = num(d, pos), y1 = num(d, pos), x2 = num(d, pos), y2 = num(d, pos);
                    float x3 = num(d, pos), y3 = num(d, pos);
                    if (rel) { x1 += x; y1 += y; x2 += x; y2 += y; x3 += x; y3 += y; }
                    p.cubicTo(x1, y1, x2, y2, x3, y3);
                    lcx = x2;
                    lcy = y2;
                    x = x3;
                    y = y3;
                    break;
                }
                case 'S': {
                    float x2 = num(d, pos), y2 = num(d, pos), x3 = num(d, pos), y3 = num(d, pos);
                    if (rel) { x2 += x; y2 += y; x3 += x; y3 += y; }
                    float x1 = (prev == 'C' || prev == 'S') ? 2 * x - lcx : x;
                    float y1 = (prev == 'C' || prev == 'S') ? 2 * y - lcy : y;
                    p.cubicTo(x1, y1, x2, y2, x3, y3);
                    lcx = x2;
                    lcy = y2;
                    x = x3;
                    y = y3;
                    break;
                }
                case 'Q': {
                    float x1 = num(d, pos), y1 = num(d, pos), x2 = num(d, pos), y2 = num(d, pos);
                    if (rel) { x1 += x; y1 += y; x2 += x; y2 += y; }
                    p.quadTo(x1, y1, x2, y2);
                    lcx = x1;
                    lcy = y1;
                    x = x2;
                    y = y2;
                    break;
                }
                case 'T': {
                    float x2 = num(d, pos), y2 = num(d, pos);
                    if (rel) { x2 += x; y2 += y; }
                    float x1 = (prev == 'Q' || prev == 'T') ? 2 * x - lcx : x;
                    float y1 = (prev == 'Q' || prev == 'T') ? 2 * y - lcy : y;
                    p.quadTo(x1, y1, x2, y2);
                    lcx = x1;
                    lcy = y1;
                    x = x2;
                    y = y2;
                    break;
                }
                default:
                    return; // неподдерживаемая команда (например, дуга): рисуем то, что успели
            }
            prev = Character.toUpperCase(cmd);
        }
    }

    private static void skip(String d, int[] pos) {
        while (pos[0] < d.length()) {
            char ch = d.charAt(pos[0]);
            if (ch == ' ' || ch == ',' || ch == '\n' || ch == '\t' || ch == '\r') pos[0]++;
            else break;
        }
    }

    private static float num(String d, int[] pos) {
        skip(d, pos);
        int i = pos[0], n = d.length();
        int st = i;
        if (i < n && (d.charAt(i) == '-' || d.charAt(i) == '+')) i++;
        boolean dot = false;
        while (i < n) {
            char ch = d.charAt(i);
            if (ch >= '0' && ch <= '9') i++;
            else if (ch == '.' && !dot) { dot = true; i++; }
            else break;
        }
        if (i < n && (d.charAt(i) == 'e' || d.charAt(i) == 'E')) {
            i++;
            if (i < n && (d.charAt(i) == '-' || d.charAt(i) == '+')) i++;
            while (i < n && d.charAt(i) >= '0' && d.charAt(i) <= '9') i++;
        }
        pos[0] = i;
        if (i == st) return 0f;
        return Float.parseFloat(d.substring(st, i));
    }
}
