package com.neighborvn;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Movie;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

/** Меню в стиле оригинала: светлые надписи с сиреневым контуром, орнамент у выбранного пункта. */
final class MenuView extends View {
    private static final String[] LABEL = {"История", "Галерея", "Настройки", "Выход"};

    private final MainActivity a;
    private final boolean hasVideo;
    private final Runnable onBgTap;
    private final RectF[] btn = new RectF[4];
    private final Movie gif;
    private final long t0 = System.currentTimeMillis();
    private int sel = 0;
    private String ver = "v ?";
    private Paint bgP, shadeP;

    MenuView(MainActivity a, boolean hasVideo, Runnable onBgTap) {
        super(a);
        this.a = a;
        this.hasVideo = hasVideo;
        this.onBgTap = onBgTap;
        for (int i = 0; i < 4; i++) btn[i] = new RectF();
        try {
            ver = "v " + a.getPackageManager().getPackageInfo(a.getPackageName(), 0).versionName;
        } catch (Exception ex) {
            // оставляем «v ?»
        }
        gif = hasVideo ? null : Art.movie("menu");
        if (gif != null) setLayerType(LAYER_TYPE_SOFTWARE, null);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        bgP = new Paint();
        bgP.setShader(new LinearGradient(0, 0, w, h, 0xFF3B1F4F, 0xFF1F2A44, Shader.TileMode.CLAMP));
        shadeP = new Paint();
        shadeP.setShader(new LinearGradient(0, 0, w * 0.6f, 0, 0x88000000, 0x00000000, Shader.TileMode.CLAMP));
        float bw = w * 0.34f, bh = h * 0.12f, x = w * 0.17f - bw / 2f + w * 0.17f, y0 = h * 0.34f, gap = h * 0.025f;
        for (int i = 0; i < 4; i++) {
            btn[i].set(x, y0 + i * (bh + gap), x + bw, y0 + i * (bh + gap) + bh);
        }
    }

    private void ornament(Canvas c, float cx, float cy, float r) {
        Paint f = Ui.fill(0xFFEDE3FF);
        Paint st = new Paint(Paint.ANTI_ALIAS_FLAG);
        st.setStyle(Paint.Style.STROKE);
        st.setStrokeWidth(r * 0.16f);
        st.setColor(0xFFB48CE6);
        for (int k = 0; k < 2; k++) {
            c.save();
            c.rotate(k * 45f, cx, cy);
            RectF q = new RectF(cx - r * 0.7f, cy - r * 0.7f, cx + r * 0.7f, cy + r * 0.7f);
            c.drawRoundRect(q, r * 0.2f, r * 0.2f, f);
            c.drawRoundRect(q, r * 0.2f, r * 0.2f, st);
            c.restore();
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (!hasVideo) {
            if (gif != null) {
                int dur = Math.max(1, gif.duration());
                gif.setTime((int) ((System.currentTimeMillis() - t0) % dur));
                float s = Math.max(w / (float) gif.width(), h / (float) gif.height());
                c.save();
                c.translate((w - gif.width() * s) / 2f, (h - gif.height() * s) / 2f);
                c.scale(s, s);
                gif.draw(c, 0, 0);
                c.restore();
                c.drawRect(0, 0, w, h, shadeP);
                postInvalidateOnAnimation();
            } else {
                Bitmap bg = Art.bitmap("menu");
                if (bg != null) {
                    Ui.cover(c, bg, w, h);
                    c.drawRect(0, 0, w, h, shadeP);
                } else {
                    c.drawRect(0, 0, w, h, bgP);
                    for (int i = 0; i < 3; i++) {
                        RectF r = new RectF(w * (0.62f + 0.12f * i), h * 0.12f, w * (0.72f + 0.12f * i), h * 0.92f);
                        Ui.figure(c, r, i);
                    }
                }
            }
        } else {
            c.drawRect(0, 0, w, h, shadeP);
        }

        Ui.outlined(c, "Milf Manor", btn[0].centerX(), h * 0.15f, h * 0.11f, 0xFFFFFFFF, 0xFFB02A55);

        boolean galleryOpen = a.gs.anyScene();
        for (int i = 0; i < 4; i++) {
            boolean locked = i == 1 && !galleryOpen;
            float cx = btn[i].centerX(), cy = btn[i].centerY();
            Ui.menuText(c, LABEL[i], cx, cy, h * 0.085f, locked);
            if (i == sel) {
                android.text.TextPaint tp = Ui.text(0xFFFFFFFF, h * 0.085f, true);
                float tw = tp.measureText(LABEL[i]) / 2f + h * 0.07f;
                ornament(c, cx - tw, cy, h * 0.04f);
                ornament(c, cx + tw, cy, h * 0.04f);
            }
            if (locked) {
                Ui.centerText(c, "[i:lock]", cx, cy, Ui.text(0xFF000000, h * 0.13f, false));
            }
        }
        Ui.centerText(c, ver, w * 0.05f, h * 0.975f, Ui.text(0xAAFFFFFF, h * 0.03f, false));
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
            for (int i = 0; i < 4; i++) if (btn[i].contains(x, y)) { sel = i; invalidate(); }
            return true;
        }
        if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
        if (btn[0].contains(x, y)) {
            Sound.sfx("sfx_click");
            a.startStory();
        } else if (btn[1].contains(x, y)) {
            Sound.sfx("sfx_click");
            if (a.gs.anyScene()) a.openGallery(true);
            else Toast.makeText(a, "Галерея откроется после первой сцены", Toast.LENGTH_SHORT).show();
        } else if (btn[2].contains(x, y)) {
            Sound.sfx("sfx_click");
            a.showSettings(false);
        } else if (btn[3].contains(x, y)) {
            a.finish();
        } else if (onBgTap != null) {
            // тап по пустому месту: другая видео-сцена меню
            Sound.sfx("sfx_next");
            onBgTap.run();
        }
        return true;
    }
}
