package com.neighborvn;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

/** Главное меню: История, Галерея (закрыта до первой сцены), Настройки, Выход. Фон: menu.jpg/png в assets. */
final class MenuView extends View {
    private static final String[] LABEL = {"История", "Галерея", "Настройки", "Выход"};
    private static final int[] COLOR = {0xFFE0485F, 0xFF9B7EDE, 0xFF5C8FD6, 0xFF6B6F8E};

    private final MainActivity a;
    private final RectF[] btn = new RectF[4];
    private Paint bgP, shadeP;

    MenuView(MainActivity a) {
        super(a);
        this.a = a;
        for (int i = 0; i < 4; i++) btn[i] = new RectF();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        bgP = new Paint();
        bgP.setShader(new LinearGradient(0, 0, w, h, 0xFF3B1F4F, 0xFF1F2A44, Shader.TileMode.CLAMP));
        shadeP = new Paint();
        shadeP.setShader(new LinearGradient(0, 0, w * 0.55f, 0, 0xCC000000, 0x00000000, Shader.TileMode.CLAMP));
        float bw = w * 0.30f, bh = h * 0.115f, x = w * 0.07f, y0 = h * 0.36f, gap = h * 0.04f;
        for (int i = 0; i < 4; i++) btn[i].set(x, y0 + i * (bh + gap), x + bw, y0 + i * (bh + gap) + bh);
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        Bitmap bg = Art.bitmap("menu");
        if (bg != null) {
            Ui.cover(c, bg, w, h);
            c.drawRect(0, 0, w, h, shadeP);
        } else {
            c.drawRect(0, 0, w, h, bgP);
            for (int i = 0; i < 3; i++) {
                RectF r = new RectF(w * (0.50f + 0.16f * i), h * 0.12f, w * (0.64f + 0.16f * i), h * 0.92f);
                Ui.figure(c, r, i);
            }
        }
        Ui.outlined(c, "Milf Manor", w * 0.22f, h * 0.17f, h * 0.12f, 0xFFFFFFFF, 0xFFB02A55);
        Ui.outlined(c, "♥ ♥ ♥", w * 0.22f, h * 0.28f, h * 0.06f, 0xFFFF6B8B, 0xFF5A1230);

        boolean galleryOpen = a.gs.anyScene();
        for (int i = 0; i < 4; i++) {
            boolean locked = i == 1 && !galleryOpen;
            Ui.button(c, btn[i], locked ? "🔒 " + LABEL[i] : LABEL[i],
                    locked ? 0xFF55556B : COLOR[i], locked ? 0xAAFFFFFF : 0xFFFFFFFF, h * 0.05f);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) return true;
        if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
        float x = e.getX(), y = e.getY();
        if (btn[0].contains(x, y)) {
            a.startStory();
        } else if (btn[1].contains(x, y)) {
            if (a.gs.anyScene()) a.openGallery(true);
            else Toast.makeText(a, "Галерея откроется после первой сцены", Toast.LENGTH_SHORT).show();
        } else if (btn[2].contains(x, y)) {
            a.showSettings(false);
        } else if (btn[3].contains(x, y)) {
            a.finish();
        }
        return true;
    }
}
