package com.neighborvn;

import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.VideoView;

/**
 * Главное меню. Фон: menu.mp4 (видео), либо menu.gif (анимация), либо menu.jpg/png (картинка).
 * Кнопки рисует MenuView поверх.
 */
final class MenuScreen extends FrameLayout {
    private VideoView video;

    MenuScreen(MainActivity a) {
        super(a);
        setBackgroundColor(Color.BLACK);
        String vp = Art.video("menu");
        if (vp != null) {
            video = new VideoView(a);
            addView(video, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));
            video.setVideoPath(vp);
            video.setOnPreparedListener(mp -> {
                mp.setLooping(true);
                mp.setVolume(0f, 0f);
            });
            video.start();
        }
        addView(new MenuView(a, video != null), new LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    @Override
    protected void onDetachedFromWindow() {
        if (video != null) video.stopPlayback();
        super.onDetachedFromWindow();
    }
}
