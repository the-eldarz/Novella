package com.neighborvn;

import android.graphics.Color;
import android.media.MediaPlayer;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

/**
 * Главное меню. Фон: две видео-сцены menu1.mp4 и menu2.mp4. Тап по пустому месту экрана
 * (не по кнопке) переключает сцену. Если есть только menu.mp4, играет он; если видео нет совсем,
 * работает gif/картинка/заглушка в MenuView. Кнопки рисует MenuView поверх.
 */
final class MenuScreen extends FrameLayout {
    private static int lastScene = 0; // чтобы после возврата из настроек осталась та же сцена

    /** Как заполнять экран видео: STRETCH (растянуть точно по экрану), COVER (без искажений, края обрезаются) или CONTAIN (целиком, по бокам чёрные полосы). */
    private static final int FIT = FillVideoView.STRETCH;

    private FillVideoView video;
    private final View fade;
    private final String[] paths = new String[2];
    private int scene = 0;
    private boolean switching = false;

    MenuScreen(MainActivity a) {
        super(a);
        setBackgroundColor(Color.BLACK);

        paths[0] = Art.video("menu1");
        paths[1] = Art.video("menu2");
        if (paths[0] == null && paths[1] == null) paths[0] = Art.video("menu");
        if (paths[0] == null) { paths[0] = paths[1]; paths[1] = null; }
        boolean two = paths[0] != null && paths[1] != null;
        scene = two ? lastScene % 2 : 0;

        if (paths[0] != null) {
            video = new FillVideoView(a, FIT);
            addView(video, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));
            video.setOnPreparedListener(this::onPrepared);
            video.setOnInfoListener((mp, what, extra) -> {
                if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) fadeIn();
                return false;
            });
            video.setVideoPath(paths[scene]);
            video.start();
        }

        MenuView mv = new MenuView(a, video != null, two ? this::nextScene : null);
        addView(mv, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // чёрная вуаль для плавной смены сцен (лежит над видео, под кнопками не мешает: не принимает касания)
        fade = new View(a);
        fade.setBackgroundColor(Color.BLACK);
        fade.setAlpha(0f);
        fade.setClickable(false);
        addView(fade, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        fade.setVisibility(GONE);
    }

    private void onPrepared(MediaPlayer mp) {
        mp.setLooping(true);
        mp.setVolume(0f, 0f);
        if (video != null) video.setVideoSize(mp.getVideoWidth(), mp.getVideoHeight());
    }

    /** Переключение menu1 <-> menu2. */
    void nextScene() {
        if (video == null || paths[1] == null || switching) return;
        switching = true;
        scene = 1 - scene;
        lastScene = scene;
        fade.setVisibility(VISIBLE);
        fade.animate().alpha(1f).setDuration(160).withEndAction(() -> {
            video.stopPlayback();
            video.setVideoPath(paths[scene]);
            video.start();
            // подстраховка, если событие «начало показа» не придёт
            fade.postDelayed(this::fadeIn, 900);
        }).start();
    }

    private void fadeIn() {
        if (!switching) return;
        switching = false;
        fade.animate().alpha(0f).setDuration(200).withEndAction(() -> fade.setVisibility(GONE)).start();
    }

    @Override
    protected void onDetachedFromWindow() {
        fade.animate().cancel();
        if (video != null) video.stopPlayback();
        super.onDetachedFromWindow();
    }
}
