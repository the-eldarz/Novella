package com.neighborvn;

import android.content.Context;
import android.content.SharedPreferences;

/** Сохранение прогресса. */
final class GameState {
    private final SharedPreferences sp;

    GameState(Context c) {
        sp = c.getSharedPreferences("milf_manor", Context.MODE_PRIVATE);
    }

    String name() { return sp.getString("name", ""); }
    void setName(String n) { sp.edit().putString("name", n).apply(); }

    int diamonds() { return sp.getInt("dia", 200); }
    void addDiamonds(int d) { sp.edit().putInt("dia", diamonds() + d).apply(); }
    boolean spend(int d) {
        if (diamonds() < d) return false;
        addDiamonds(-d);
        return true;
    }

    boolean tutorialDone() { return sp.getBoolean("tut", false); }
    void setTutorialDone(boolean v) { sp.edit().putBoolean("tut", v).apply(); }

    int hearts(int level) { return sp.getInt("h" + level, 0); }
    void setHearts(int level, int v) { sp.edit().putInt("h" + level, v).apply(); }
    int totalHearts() {
        int s = 0;
        for (int i = 0; i < Data.LEVELS.length; i++) s += hearts(i);
        return s;
    }

    boolean unlocked(int level) { return level == 0 || sp.getBoolean("u" + level, false); }
    void unlock(int level) { sp.edit().putBoolean("u" + level, true).apply(); }

    int booster(int i) { return sp.getInt("b" + i, 3); }
    void addBooster(int i, int d) { sp.edit().putInt("b" + i, booster(i) + d).apply(); }

    int gift(int i) { return sp.getInt("g" + i, 0); }
    void addGift(int i, int d) { sp.edit().putInt("g" + i, gift(i) + d).apply(); }

    int aff(int heroine) { return sp.getInt("a" + heroine, 0); }
    void addAff(int heroine, int d) { sp.edit().putInt("a" + heroine, aff(heroine) + d).apply(); }

    long lastIncome() { return sp.getLong("inc", 0L); }
    void setLastIncome(long t) { sp.edit().putLong("inc", t).apply(); }

    void reset() { sp.edit().clear().apply(); }
}
