package com.neighborvn;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;

/**
 * Сцена благодарности. Берёт из assets: scene_&lt;id&gt;.mp4 (видео) либо scene_&lt;id&gt;.jpg/.png/.webp (картинка).
 * Нет файла: показывается анимация-заглушка. Сцена идёт, пока игрок не нажмёт «Выход».
 */
final class SceneScreen extends FrameLayout {
    private VideoView video;
    private final Runnable done;
    private boolean left = false;

    SceneScreen(MainActivity a, int level, Runnable done) {
        super(a);
        this.done = done;
        Data.Level lv = Data.LEVELS[level];
        setBackgroundColor(Color.BLACK);

        final String base = "scene_" + lv.id;
        String vp = Art.video(base);
        Bitmap img = vp == null ? Art.bitmap(base) : null;
        boolean placeholder = false;

        if (vp != null) {
            video = new VideoView(a);
            addView(video, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));
            video.setVideoPath(vp);
            video.setOnPreparedListener(mp -> mp.setLooping(true));
            video.start();
        } else if (img != null) {
            ImageView iv = new ImageView(a);
            iv.setImageBitmap(img);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            addView(iv, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            placeholder = true;
            addView(new SceneView(a, level), new LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }

        // Подпись: нажатие на сцену скрывает/показывает её
        final TextView cap = new TextView(a);
        cap.setText(lv.scene);
        cap.setTextColor(Color.WHITE);
        cap.setTextSize(18);
        cap.setGravity(Gravity.CENTER);
        cap.setPadding(40, 20, 40, 20);
        GradientDrawable cb = new GradientDrawable();
        cb.setColor(0xAA000000);
        cb.setCornerRadius(30f);
        cap.setBackground(cb);
        if (!placeholder) {
            LayoutParams cp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            cp.bottomMargin = 40;
            addView(cap, cp);
            setOnClickListener(v -> cap.setVisibility(cap.getVisibility() == VISIBLE ? INVISIBLE : VISIBLE));
        }

        // Кнопка «Выход»
        TextView exit = new TextView(a);
        exit.setText("Выход ✕");
        exit.setTextColor(Color.WHITE);
        exit.setTextSize(20);
        exit.setGravity(Gravity.CENTER);
        exit.setPadding(50, 22, 50, 22);
        GradientDrawable eb = new GradientDrawable();
        eb.setColor(0xDDE0485F);
        eb.setCornerRadius(60f);
        exit.setBackground(eb);
        exit.setOnClickListener((View v) -> leave());
        LayoutParams ep = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        ep.topMargin = 30;
        ep.rightMargin = 30;
        addView(exit, ep);
    }

    private void leave() {
        if (left) return;
        left = true;
        if (video != null) video.stopPlayback();
        done.run();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (video != null) video.stopPlayback();
        super.onDetachedFromWindow();
    }
}
