package com.neighborvn;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;

/**
 * Сцена благодарности из трёх подсцен, без названий и подписей. Для каждой берётся из assets:
 * scene_<id>_1, scene_<id>_2, scene_<id>_3 с расширением .mp4 (видео) либо .jpg/.png/.webp (картинка).
 * Для первой подсцены, если файла нет, пробуется старое имя scene_<id>.
 * Нет файла: показывается анимация-заглушка. Кнопка «Далее» ведёт к следующей подсцене, «Выход» закрывает сцену.
 */
final class SceneScreen extends FrameLayout {
    private final MainActivity a;
    private final int level;
    private final Runnable done;
    private final FrameLayout stageBox;
    private final DotsView dots;
    private final View next;
    private VideoView video;
    private int cur = -1;
    private boolean left = false;

    /** Маленькая SVG-иконка для кнопок. */
    private static final class IconView extends View {
        private final String icon;
        private final int tint;

        IconView(Context c, String icon, int tint) {
            super(c);
            this.icon = icon;
            this.tint = tint;
        }

        @Override
        protected void onDraw(Canvas c) {
            Icons.draw(c, icon, getWidth() / 2f, getHeight() / 2f, Math.min(getWidth(), getHeight()), tint);
        }
    }

    /** Индикатор подсцен: кружки, заполнен текущий. */
    private static final class DotsView extends View {
        private final int count;
        private int sel = 0;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        DotsView(Context c, int count) {
            super(c);
            this.count = count;
        }

        void set(int i) {
            sel = i;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float h = getHeight(), r = h * 0.2f, gap = h * 0.62f;
            float total = (count - 1) * gap;
            float x0 = getWidth() / 2f - total / 2f;
            for (int i = 0; i < count; i++) {
                p.setStyle(i == sel ? Paint.Style.FILL : Paint.Style.STROKE);
                p.setStrokeWidth(r * 0.35f);
                p.setColor(Color.WHITE);
                c.drawCircle(x0 + i * gap, h / 2f, i == sel ? r : r * 0.82f, p);
            }
        }
    }

    private LinearLayout button(String label, String icon, int color, boolean iconFirst) {
        float d = getResources().getDisplayMetrics().density;
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setPadding((int) (22 * d), (int) (10 * d), (int) (22 * d), (int) (10 * d));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(60f);
        row.setBackground(bg);

        TextView t = new TextView(a);
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(20);
        t.setGravity(Gravity.CENTER);
        IconView iv = new IconView(a, icon, Color.WHITE);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams((int) (22 * d), (int) (22 * d));
        if (iconFirst) {
            ip.rightMargin = (int) (8 * d);
            row.addView(iv, ip);
            row.addView(t);
        } else {
            ip.leftMargin = (int) (8 * d);
            row.addView(t);
            row.addView(iv, ip);
        }
        return row;
    }

    SceneScreen(MainActivity a, int level, Runnable done) {
        super(a);
        this.a = a;
        this.level = level;
        this.done = done;
        setBackgroundColor(Color.BLACK);
        float d = getResources().getDisplayMetrics().density;

        stageBox = new FrameLayout(a);
        addView(stageBox, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Левый верхний угол: индикатор подсцен и кнопка «Далее»
        LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        dots = new DotsView(a, Data.SUB_COUNT);
        GradientDrawable db = new GradientDrawable();
        db.setColor(0xAA000000);
        db.setCornerRadius(60f);
        dots.setBackground(db);
        bar.addView(dots, new LinearLayout.LayoutParams((int) (84 * d), (int) (44 * d)));

        next = button("Далее", "next", 0xDD7A5CC8, false);
        next.setOnClickListener((View v) -> show(cur + 1));
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        np.leftMargin = (int) (10 * d);
        bar.addView(next, np);

        LayoutParams bp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        bp.topMargin = 30;
        bp.leftMargin = 30;
        addView(bar, bp);

        // Кнопка «Выход» (всегда доступна)
        View exit = button("Выход", "close", 0xDDE0485F, false);
        exit.setOnClickListener((View v) -> leave());
        LayoutParams ep = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        ep.topMargin = 30;
        ep.rightMargin = 30;
        addView(exit, ep);

        show(0);
    }

    private void show(int i) {
        if (i < 0 || i >= Data.SUB_COUNT) return;
        if (video != null) {
            video.stopPlayback();
            video = null;
        }
        stageBox.removeAllViews();
        cur = i;

        String base = "scene_" + Data.LEVELS[level].id + "_" + (i + 1);
        String vp = Art.video(base);
        Bitmap img = vp == null ? Art.bitmap(base) : null;
        if (i == 0 && vp == null && img == null) {
            base = "scene_" + Data.LEVELS[level].id;
            vp = Art.video(base);
            img = vp == null ? Art.bitmap(base) : null;
        }

        if (vp != null) {
            video = new VideoView(a);
            stageBox.addView(video, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));
            video.setVideoPath(vp);
            video.setOnPreparedListener(mp -> mp.setLooping(true));
            video.start();
        } else if (img != null) {
            ImageView iv = new ImageView(a);
            iv.setImageBitmap(img);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            stageBox.addView(iv, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            stageBox.addView(new SceneView(a, level, i), new LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }

        dots.set(i);
        next.setVisibility(i + 1 < Data.SUB_COUNT ? VISIBLE : GONE);
    }

    private void leave() {
        if (left) return;
        left = true;
        if (video != null) video.stopPlayback();
        done.run();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (video != null) video.stopPlayback();
        super.onDetachedFromWindow();
    }
}
