package com.neighborvn;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.text.TextPaint;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;

/**
 * Двери лифта между меню и картой: створки сдвигаются к центру, пока за ними
 * меняется экран, держатся, потом раздвигаются. На правой створке название игры.
 * Необязательный звук: sfx_door (.ogg/.mp3).
 */
final class ElevatorDoors extends View {
    private static final String TITLE = "Milf Manor";

    private final Runnable atClosed;
    private float p = 0f; // 0 открыты, 1 закрыты
    private final Paint leftP = new Paint(), rightP = new Paint();
    private final Paint seam = Ui.fill(0xFF5E7585);
    private final Paint shade = new Paint();
    private int sw = -1, sh = -1;

    ElevatorDoors(Context c, Runnable atClosed) {
        super(c);
        this.atClosed = atClosed;
    }

    void start() {
        Sound.sfx("sfx_door");
        ValueAnimator close = ValueAnimator.ofFloat(0f, 1f);
        close.setDuration(650);
        close.setInterpolator(new DecelerateInterpolator(1.6f));
        close.addUpdateListener(va -> {
            p = (float) va.getAnimatedValue();
            invalidate();
        });
        close.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator an) {
                p = 1f;
                invalidate();
                atClosed.run();
                postDelayed(ElevatorDoors.this::openDoors, 550);
            }
        });
        close.start();
    }

    private void openDoors() {
        Sound.sfx("sfx_door");
        ValueAnimator open = ValueAnimator.ofFloat(1f, 0f);
        open.setDuration(800);
        open.setInterpolator(new AccelerateDecelerateInterpolator());
        open.addUpdateListener(va -> {
            p = (float) va.getAnimatedValue();
            invalidate();
        });
        open.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator an) {
                ViewParent par = getParent();
                if (par instanceof ViewGroup) ((ViewGroup) par).removeView(ElevatorDoors.this);
            }
        });
        open.start();
    }

    private void build(int w, int h) {
        float half = w / 2f;
        leftP.setShader(new LinearGradient(0, 0, half, 0,
                new int[]{0xFFC9DBE6, 0xFFB4CAD8, 0xFF8EA6B6}, new float[]{0f, 0.75f, 1f}, Shader.TileMode.CLAMP));
        rightP.setShader(new LinearGradient(0, 0, half, 0,
                new int[]{0xFF8EA6B6, 0xFFB4CAD8, 0xFFC9DBE6}, new float[]{0f, 0.25f, 1f}, Shader.TileMode.CLAMP));
        shade.setShader(new LinearGradient(0, 0, 0, h,
                new int[]{0x22FFFFFF, 0x00000000, 0x22000000}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        sw = w;
        sh = h;
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w != sw || h != sh) build(w, h);
        float half = w / 2f;

        // левая створка: от -half (открыта) до 0 (закрыта)
        float lx = -half + half * p;
        c.save();
        c.translate(lx, 0);
        c.drawRect(0, 0, half, h, leftP);
        c.drawRect(0, 0, half, h, shade);
        c.drawRect(half - 3f, 0, half, h, seam);
        c.restore();

        // правая створка: от w+... (открыта) до half (закрыта)
        float rx = w - half * p;
        c.save();
        c.translate(rx, 0);
        c.drawRect(0, 0, half, h, rightP);
        c.drawRect(0, 0, half, h, shade);
        c.drawRect(0, 0, 3f, h, seam);
        float cx = half * 0.5f, cy = h * 0.55f, size = h * 0.085f;
        TextPaint tp = Ui.text(0xFFFFFFFF, size, true);
        float tw = tp.measureText(TITLE), pad = size * 0.5f;
        c.save();
        c.rotate(-4f, cx, cy);
        RectF plate = new RectF(cx - tw / 2f - pad, cy - size * 0.75f, cx + tw / 2f + pad, cy + size * 0.75f);
        c.drawRoundRect(plate, size * 0.25f, size * 0.25f, Ui.fill(0xFFE0486F));
        Ui.outlined(c, TITLE, cx, cy, size, 0xFFFFFFFF, 0xFFB02A55);
        c.restore();
        c.restore();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        return true; // пока двери едут, касания не проходят
    }
}
