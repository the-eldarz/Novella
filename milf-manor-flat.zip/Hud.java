package com.neighborvn;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

/** Общие элементы интерфейса в стиле оригинала: фон с узором, шеврон «назад», бустеры и валюта. */
final class Hud {
    private Hud() {}

    /** Узорный фон: свой файл map_bg (картинка) либо узор из полос и точек. */
    static Bitmap pattern(int w, int h, int base, int stripe, int dot) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawRect(0, 0, w, h, Ui.fill(base));
        Paint sp = Ui.fill(stripe);
        float t = h * 0.07f;
        for (int i = -2; i < 12; i++) {
            android.graphics.Path p = new android.graphics.Path();
            float y0 = h * 0.08f * i;
            p.moveTo(0, y0);
            p.lineTo(w, y0 - h * 0.22f);
            p.lineTo(w, y0 - h * 0.22f + t);
            p.lineTo(0, y0 + t);
            p.close();
            if (i % 3 == 0) c.drawPath(p, sp);
        }
        Paint dp = Ui.fill(dot);
        float step = h * 0.09f, r = step * 0.22f;
        for (int row = 0; row * step < h + step; row++) {
            for (int col = 0; col * step < w + step; col++) {
                float x = col * step + ((row & 1) == 0 ? 0 : step / 2f);
                c.drawCircle(x, row * step, r, dp);
            }
        }
        return b;
    }

    static void backChevron(Canvas c, RectF r) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(r.width() * 0.22f);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setColor(0xFFFFFFFF);
        android.graphics.Path path = new android.graphics.Path();
        path.moveTo(r.right - r.width() * 0.15f, r.top);
        path.lineTo(r.left + r.width() * 0.15f, r.centerY());
        path.lineTo(r.right - r.width() * 0.15f, r.bottom);
        Paint sh = new Paint(p);
        sh.setColor(0x66000000);
        c.save();
        c.translate(r.width() * 0.08f, r.width() * 0.08f);
        c.drawPath(path, sh);
        c.restore();
        c.drawPath(path, p);
    }

    /** Нижняя полоса бустеров (наклонные карточки), возвращает прямоугольники для нажатий. */
    static void boosters(Canvas c, RectF[] r, GameState gs, int h) {
        for (int i = 0; i < r.length; i++) {
            Ui.slant(c, r[i], null, 0xFF9B7EDE, 0xFFFFFFFF, 0);
            Ui.centerText(c, Data.BOOST_ICON[i], r[i].centerX(), r[i].centerY(),
                    Ui.text(0xFFFFFFFF, r[i].height() * 0.55f, false));
            Ui.outlined(c, String.valueOf(gs.booster(i)), r[i].centerX(), r[i].bottom + r[i].height() * 0.18f,
                    r[i].height() * 0.28f, 0xFFFFFFFF, 0xFF5A3A9C);
        }
    }

    static void currency(Canvas c, GameState gs, float right, float cy, float size) {
        String d = String.valueOf(gs.diamonds());
        TextPaintHelper.right(c, "💎 " + d, right, cy, size);
        TextPaintHelper.right(c, "🎟 " + gs.tokens(), right - size * (d.length() * 0.62f + 3.6f), cy, size);
    }

    /** Мелкий помощник для текста, выровненного по правому краю. */
    static final class TextPaintHelper {
        static void right(Canvas c, String s, float right, float cy, float size) {
            android.text.TextPaint st = Ui.text(0xFF3A2060, size, true);
            st.setStyle(Paint.Style.STROKE);
            st.setStrokeWidth(size * 0.16f);
            st.setStrokeJoin(Paint.Join.ROUND);
            st.setTextAlign(Paint.Align.RIGHT);
            android.text.TextPaint fp = Ui.text(0xFFFFFFFF, size, true);
            fp.setTextAlign(Paint.Align.RIGHT);
            Paint.FontMetrics fm = fp.getFontMetrics();
            float y = cy - (fm.ascent + fm.descent) / 2f;
            c.drawText(s, right, y, st);
            c.drawText(s, right, y, fp);
        }
    }
}
