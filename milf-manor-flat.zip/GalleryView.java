package com.neighborvn;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

/** Галерея: выбираешь героиню, затем уровень и пересматриваешь её сцену благодарности. */
final class GalleryView extends View {
    private final MainActivity a;
    private final GameState gs;
    private final int sel;
    private final ArrayList<Integer> levelIdx = new ArrayList<>();
    private final RectF backR = new RectF();
    private final RectF[] cardR = new RectF[5];
    private final RectF[] giftR = new RectF[3];
    private Paint bgP;

    GalleryView(MainActivity a, int sel) {
        super(a);
        this.a = a;
        this.gs = a.gs;
        this.sel = sel;
        for (int i = 0; i < 5; i++) cardR[i] = new RectF();
        for (int i = 0; i < 3; i++) giftR[i] = new RectF();
        if (sel >= 0) {
            for (int i = 0; i < Data.LEVELS.length; i++) {
                if (Data.LEVELS[i].heroine == sel) levelIdx.add(i);
            }
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        bgP = new Paint();
        bgP.setShader(new LinearGradient(0, 0, 0, h, 0xFF3B3355, 0xFF1F2A44, Shader.TileMode.CLAMP));
        backR.set(w * 0.02f, h * 0.03f, w * 0.14f, h * 0.11f);
        if (sel < 0) {
            float cw = w * 0.24f, gap = (w - 3 * cw) / 4f;
            for (int i = 0; i < 3; i++) {
                float x = gap + i * (cw + gap);
                cardR[i].set(x, h * 0.15f, x + cw, h * 0.70f);
                giftR[i].set(x + cw * 0.08f, h * 0.82f, x + cw * 0.92f, h * 0.92f);
            }
        } else {
            int n = Math.max(1, levelIdx.size());
            float gap = w * 0.02f;
            float cw = Math.min(w * 0.26f, (w * 0.94f - (n - 1) * gap) / n);
            float total = n * cw + (n - 1) * gap;
            float x0 = (w - total) / 2f;
            for (int i = 0; i < n; i++) {
                float x = x0 + i * (cw + gap);
                cardR[i].set(x, h * 0.2f, x + cw, h * 0.85f);
            }
        }
    }

    private int scenesOpen(int heroine) {
        int n = 0;
        for (int i = 0; i < Data.LEVELS.length; i++) {
            if (Data.LEVELS[i].heroine == heroine && gs.hearts(i) >= 3) n++;
        }
        return n;
    }

    private int scenesTotal(int heroine) {
        int n = 0;
        for (int i = 0; i < Data.LEVELS.length; i++) if (Data.LEVELS[i].heroine == heroine) n++;
        return n;
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawRect(0, 0, w, h, bgP);
        Ui.button(c, backR, "← Назад", 0xAA000000, 0xFFFFFFFF, h * 0.04f);
        String title = sel < 0 ? "Галерея" : Data.HNAMES[sel];
        Ui.centerText(c, title, w * 0.5f, h * 0.07f, Ui.text(0xFFFFFFFF, h * 0.065f, true));

        if (sel < 0) {
            for (int i = 0; i < 3; i++) {
                Ui.plate(c, cardR[i], Data.HCOLORS[i], 30f);
                RectF in = new RectF(cardR[i]);
                in.inset(cardR[i].width() * 0.04f, cardR[i].width() * 0.04f);
                Ui.face(c, in, i, 24f);
                Ui.outlined(c, Data.HNAMES[i], in.centerX(), in.bottom - in.height() * 0.07f, h * 0.05f,
                        0xFFFFFFFF, 0xFF000000);
                String info = "Сцены: " + scenesOpen(i) + "/" + scenesTotal(i) + "   ♥ " + gs.aff(i);
                Ui.centerText(c, info, cardR[i].centerX(), h * 0.77f, Ui.text(0xFFFFFFFF, h * 0.04f, true));
                Ui.button(c, giftR[i], "🎁 Подарить", 0xFF9B7EDE, 0xFFFFFFFF, h * 0.04f);
            }
        } else {
            for (int i = 0; i < levelIdx.size(); i++) {
                int li = levelIdx.get(i);
                Data.Level lv = Data.LEVELS[li];
                boolean open = gs.hearts(li) >= 3;
                RectF r = cardR[i];
                Ui.plate(c, r, open ? Data.HCOLORS[sel] : 0xFF3A3F5C, 30f);
                Ui.centerText(c, open ? "▶" : "🔒", r.centerX(), r.top + r.height() * 0.30f,
                        Ui.text(0xFFFFFFFF, r.height() * 0.22f, true));
                Ui.centerText(c, lv.room, r.centerX(), r.top + r.height() * 0.58f,
                        Ui.text(0xFFFFFFFF, h * 0.05f, true));
                Ui.wrapped(c, open ? lv.title : "Пройди комнату, чтобы открыть сцену",
                        r.left + r.width() * 0.08f, r.top + r.height() * 0.68f,
                        (int) (r.width() * 0.84f), Ui.text(0xDDFFFFFF, h * 0.038f, false));
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) return true;
        if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
        float x = e.getX(), y = e.getY();
        if (backR.contains(x, y)) {
            if (sel >= 0) a.showGallery(-1);
            else a.leaveGallery();
            return true;
        }
        if (sel < 0) {
            for (int i = 0; i < 3; i++) {
                if (giftR[i].contains(x, y)) {
                    giveGift(i);
                    return true;
                }
            }
            for (int i = 0; i < 3; i++) {
                if (cardR[i].contains(x, y)) {
                    a.showGallery(i);
                    return true;
                }
            }
        } else {
            for (int i = 0; i < levelIdx.size(); i++) {
                final int li = levelIdx.get(i);
                if (cardR[i].contains(x, y)) {
                    if (gs.hearts(li) >= 3) {
                        a.showScene(li, () -> a.showGallery(sel));
                    } else {
                        Toast.makeText(a, "Сначала пройди комнату «" + Data.LEVELS[li].room + "»",
                                Toast.LENGTH_SHORT).show();
                    }
                    return true;
                }
            }
        }
        return true;
    }

    private void giveGift(int heroine) {
        for (int g = 0; g < 3; g++) {
            if (gs.gift(g) > 0) {
                gs.addGift(g, -1);
                gs.addAff(heroine, Data.GIFT_AFF[g]);
                Toast.makeText(a, Data.HNAMES[heroine] + " в восторге: " + Data.GIFT_NAME[g],
                        Toast.LENGTH_SHORT).show();
                a.hearts.burst(giftR[heroine].centerX(), giftR[heroine].centerY(), 16);
                invalidate();
                return;
            }
        }
        Toast.makeText(a, "У тебя нет подарков. Купи их в магазине.", Toast.LENGTH_SHORT).show();
    }
}
