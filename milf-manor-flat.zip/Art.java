package com.neighborvn;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Movie;
import android.graphics.Typeface;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;

/**
 * Загрузка картинок и видео из assets. Если файла нет, возвращается null,
 * и игра рисует заглушку. Расширения: .png .webp .jpg .jpeg (видео .mp4).
 */
final class Art {
    private Art() {}

    private static Context ctx;
    private static final HashMap<String, Bitmap> cache = new HashMap<>();
    private static final HashSet<String> none = new HashSet<>();
    private static final String[] EXT = {".png", ".webp", ".jpg", ".jpeg"};

    static Typeface font;

    static void init(Context c) {
        ctx = c.getApplicationContext();
        for (String n : new String[]{"font.ttf", "font.otf"}) {
            try {
                font = Typeface.createFromAsset(ctx.getAssets(), n);
                break;
            } catch (Exception ex) {
                // нет своего шрифта: берём системный
            }
        }
        File[] old = ctx.getCacheDir().listFiles();
        if (old != null) {
            for (File f : old) if (f.getName().endsWith(".mp4")) f.delete();
        }
    }

    static Bitmap bitmap(String base) {
        if (ctx == null) return null;
        Bitmap b = cache.get(base);
        if (b != null) return b;
        if (none.contains(base)) return null;
        for (String e : EXT) {
            String n = base + e;
            try {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                InputStream in = ctx.getAssets().open(n);
                BitmapFactory.decodeStream(in, null, o);
                in.close();
                int s = 1;
                while (Math.max(o.outWidth, o.outHeight) / s > 2200) s *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = s;
                in = ctx.getAssets().open(n);
                b = BitmapFactory.decodeStream(in, null, o2);
                in.close();
                if (b != null) {
                    cache.put(base, b);
                    return b;
                }
            } catch (IOException ex) {
                // пробуем следующее расширение
            }
        }
        none.add(base);
        return null;
    }

    /** Копирует base.mp4 из assets во временную папку и возвращает путь, либо null. */
    static String video(String base) {
        if (ctx == null) return null;
        File out = new File(ctx.getCacheDir(), base + ".mp4");
        if (out.exists() && out.length() > 0) return out.getAbsolutePath();
        try {
            InputStream in = ctx.getAssets().open(base + ".mp4");
            FileOutputStream os = new FileOutputStream(out);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            os.close();
            in.close();
            return out.getAbsolutePath();
        } catch (IOException ex) {
            out.delete();
            return null;
        }
    }

    /** Текстовый файл из assets (например, icon_gem.svg) либо null. */
    static String text(String name) {
        if (ctx == null) return null;
        try {
            InputStream in = ctx.getAssets().open(name);
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            return new String(bo.toByteArray(), "UTF-8");
        } catch (IOException ex) {
            return null;
        }
    }

    /** Анимированный gif (base.gif) для фона меню. */
    static Movie movie(String base) {
        if (ctx == null) return null;
        try {
            InputStream in = ctx.getAssets().open(base + ".gif");
            Movie m = Movie.decodeStream(in);
            in.close();
            return m;
        } catch (IOException ex) {
            return null;
        }
    }

    static boolean hasVideo(String base) {
        if (ctx == null) return false;
        try {
            ctx.getAssets().open(base + ".mp4").close();
            return true;
        } catch (IOException ex) {
            return false;
        }
    }
}
