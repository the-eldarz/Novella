package com.neighborvn;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;

/**
 * Загрузка картинок и видео из assets. Если файла нет, возвращается null,
 * и игра рисует заглушку. Расширения: .png .webp .jpg .jpeg (видео .mp4).
 */
final class Art {
    private Art() {}

    private static Context ctx;
    private static final HashMap<String, Bitmap> cache = new HashMap<>();
    private static final HashSet<String> none = new HashSet<>();
    private static final String[] EXT = {".png", ".webp", ".jpg", ".jpeg"};

    static void init(Context c) {
        ctx = c.getApplicationContext();
        File[] old = ctx.getCacheDir().listFiles();
        if (old != null) {
            for (File f : old) if (f.getName().endsWith(".mp4")) f.delete();
        }
    }

    static Bitmap bitmap(String base) {
        if (ctx == null) return null;
        Bitmap b = cache.get(base);
        if (b != null) return b;
        if (none.contains(base)) return null;
        for (String e : EXT) {
            String n = base + e;
            try {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                InputStream in = ctx.getAssets().open(n);
                BitmapFactory.decodeStream(in, null, o);
                in.close();
                int s = 1;
                while (Math.max(o.outWidth, o.outHeight) / s > 2200) s *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = s;
                in = ctx.getAssets().open(n);
                b = BitmapFactory.decodeStream(in, null, o2);
                in.close();
                if (b != null) {
                    cache.put(base, b);
                    return b;
                }
            } catch (IOException ex) {
                // пробуем следующее расширение
            }
        }
        none.add(base);
        return null;
    }

    /** Копирует base.mp4 из assets во временную папку и возвращает путь, либо null. */
    static String video(String base) {
        if (ctx == null) return null;
        File out = new File(ctx.getCacheDir(), base + ".mp4");
        if (out.exists() && out.length() > 0) return out.getAbsolutePath();
        try {
            InputStream in = ctx.getAssets().open(base + ".mp4");
            FileOutputStream os = new FileOutputStream(out);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            os.close();
            in.close();
            return out.getAbsolutePath();
        } catch (IOException ex) {
            out.delete();
            return null;
        }
    }
}
