package com.neighborvn;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.text.TextPaint;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

/** Экран диалога: печатающийся текст, портрет героини, выбор из двух ответов. */
final class DialogueView extends View {
    private final ArrayList<Data.Line> q = new ArrayList<>();
    private final String name;
    private final android.graphics.Bitmap bgBmp;
    private final Runnable done;
    private int idx = 0;
    private int portraitWho;
    private float reveal = 0f;
    private boolean finished = false;
    private boolean running = false;
    private long lastT;

    private final RectF boxR = new RectF();
    private final RectF portR = new RectF();
    private final RectF tagR = new RectF();
    private final RectF[] optR = {new RectF(), new RectF()};
    private Paint bgP;
    private final Paint boxP = Ui.fill(0xEEFFFFFF);
    private TextPaint textP;
    private TextPaint nameP;

    DialogueView(MainActivity a, int heroine, Data.Line[] lines, String name, String bg, Runnable done) {
        super(a);
        this.name = name;
        this.bgBmp = bg == null ? null : Art.bitmap(bg);
        this.done = done;
        this.portraitWho = heroine;
        for (Data.Line l : lines) q.add(l);
        syncPortrait();
    }

    private void syncPortrait() {
        Data.Line l = q.get(idx);
        if (l.who <= 2) portraitWho = l.who;
    }

    private String fmt(String s) {
        return s.replace("{name}", name);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            long n = System.nanoTime();
            float dt = Math.min(0.05f, (n - lastT) / 1e9f);
            lastT = n;
            reveal += dt * 45f;
            invalidate();
            if (running) postOnAnimation(this);
        }
    };

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        running = true;
        lastT = System.nanoTime();
        postOnAnimation(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        super.onDetachedFromWindow();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        boxR.set(w * 0.04f, h * 0.66f, w * 0.96f, h * 0.97f);
        portR.set(w * 0.58f, h * 0.02f, w * 0.98f, h * 0.72f);
        optR[0].set(w * 0.08f, h * 0.22f, w * 0.60f, h * 0.34f);
        optR[1].set(w * 0.08f, h * 0.38f, w * 0.60f, h * 0.50f);
        textP = Ui.text(0xFF2B2D42, h * 0.052f, false);
        nameP = Ui.text(0xFFFFFFFF, h * 0.05f, true);
        updateBg(h);
    }

    private void updateBg(int h) {
        int base = Data.HCOLORS[portraitWho];
        bgP = new Paint();
        bgP.setShader(new LinearGradient(0, 0, 0, h, Ui.darken(base, 0.35f), Ui.darken(base, 0.8f),
                Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        updateBg(h);
        if (bgBmp != null) {
            Ui.cover(c, bgBmp, w, h);
            c.drawRect(0, 0, w, h, Ui.fill(0x33000000));
        } else {
            c.drawRect(0, 0, w, h, bgP);
        }
        Ui.figure(c, portR, portraitWho);

        Data.Line l = q.get(idx);
        String full = fmt(l.text);
        int n = Math.min(full.length(), (int) reveal);
        boolean complete = n >= full.length();

        c.drawRoundRect(boxR, 36f, 36f, boxP);

        String speaker = l.who <= 2 ? Data.HNAMES[l.who] : (l.who == 3 ? name : "");
        if (!speaker.isEmpty()) {
            float tw = nameP.measureText(speaker) + w * 0.04f;
            tagR.set(boxR.left + w * 0.02f, boxR.top - h * 0.07f, boxR.left + w * 0.02f + tw, boxR.top + h * 0.005f);
            int tagColor = l.who <= 2 ? Data.HCOLORS[l.who] : 0xFF3A506B;
            c.drawRoundRect(tagR, 24f, 24f, Ui.fill(tagColor));
            Ui.centerText(c, speaker, tagR.centerX(), tagR.centerY(), nameP);
        }

        float pad = w * 0.025f;
        Ui.wrapped(c, full.substring(0, n), boxR.left + pad, boxR.top + pad * 1.2f,
                (int) (boxR.width() - 2 * pad), textP);

        if (complete && l.opts == null) {
            Ui.centerText(c, "▶", boxR.right - pad, boxR.bottom - pad, Ui.text(0xFFE07A8F, h * 0.05f, true));
        }
        if (complete && l.opts != null) {
            for (int i = 0; i < 2; i++) {
                Ui.button(c, optR[i], fmt(l.opts[i]), 0xFFFFFFFF, 0xFF2B2D42, h * 0.045f);
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) return true;
        if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
        Data.Line l = q.get(idx);
        int len = fmt(l.text).length();
        if (reveal < len) {
            reveal = len;
            invalidate();
            return true;
        }
        if (l.opts != null) {
            for (int i = 0; i < 2; i++) {
                if (optR[i].contains(e.getX(), e.getY())) {
                    q.add(idx + 1, new Data.Line(l.reactWho, l.reacts[i]));
                    advance();
                    return true;
                }
            }
            return true;
        }
        advance();
        return true;
    }

    private void advance() {
        idx++;
        if (idx >= q.size()) {
            if (!finished) {
                finished = true;
                running = false;
                done.run();
            }
            return;
        }
        reveal = 0f;
        syncPortrait();
        invalidate();
    }
}
