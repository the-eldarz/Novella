package com.neighborvn;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.text.TextPaint;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

/**
 * Экран диалога. Героиня крупно за плашкой, имя над плашкой слева, печатающийся текст.
 * Выбора ответов нет. Когда говорит игрок (слова или мысли), героиня чуть отдаляется и темнеет.
 */
final class DialogueView extends View {
    private final ArrayList<Data.Line> q = new ArrayList<>();
    private final String name;
    private final android.graphics.Bitmap bgBmp;
    private final Runnable done;
    private int idx = 0;
    private int portraitWho;
    private float reveal = 0f;
    private float dim = 0f; // 0: героиня говорит или рассказчик, 1: говорит игрок
    private boolean finished = false;
    private boolean running = false;
    private long lastT;

    private final RectF boxR = new RectF();
    private final RectF portR = new RectF();
    private Paint bgP;
    private int bgWho = -1;
    private final Paint boxP = Ui.fill(0xC8FFFFFF);
    private final Paint boxRim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private TextPaint nameP, nameStroke;
    private float textSize;

    DialogueView(MainActivity a, int heroine, Data.Line[] lines, String name, String bg, Runnable done) {
        super(a);
        this.name = name;
        this.bgBmp = bg == null ? null : Art.bitmap(bg);
        this.done = done;
        this.portraitWho = heroine;
        for (Data.Line l : lines) q.add(l);
        boxRim.setStyle(Paint.Style.STROKE);
        boxRim.setColor(0x88FFFFFF);
        boxRim.setStrokeWidth(3f);
        syncPortrait();
        dim = target();
    }

    private void syncPortrait() {
        Data.Line l = q.get(idx);
        if (l.who <= 2) portraitWho = l.who;
    }

    private float target() {
        if (idx >= q.size()) return dim; // диалог уже закончился, кадр дорисовывается
        return q.get(idx).who == 3 ? 1f : 0f;
    }

    private String fmt(String s) {
        return s.replace("{name}", name);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (finished || idx >= q.size()) return;
            long n = System.nanoTime();
            float dt = Math.min(0.05f, (n - lastT) / 1e9f);
            lastT = n;
            reveal += dt * 45f;
            dim += (target() - dim) * Math.min(1f, dt * 9f);
            invalidate();
            if (running) postOnAnimation(this);
        }
    };

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        running = true;
        lastT = System.nanoTime();
        postOnAnimation(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        super.onDetachedFromWindow();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        boxR.set(w * 0.10f, h * 0.70f, w * 0.90f, h * 0.96f);
        // героиня крупно: ноги уходят за плашку и за край экрана
        portR.set(w * 0.40f, 0f, w * 1.04f, h * 1.16f);
        textSize = h * 0.05f;
        nameP = Ui.text(0xFFFFFFFF, h * 0.06f, true);
        nameStroke = Ui.text(0xFF2A1740, h * 0.06f, true);
        nameStroke.setStyle(Paint.Style.STROKE);
        nameStroke.setStrokeWidth(h * 0.012f);
        nameStroke.setStrokeJoin(Paint.Join.ROUND);
        bgWho = -1;
    }

    private void updateBg(int h) {
        if (bgWho == portraitWho) return;
        bgWho = portraitWho;
        int base = Data.HCOLORS[portraitWho];
        bgP = new Paint();
        bgP.setShader(new LinearGradient(0, 0, 0, h, Ui.darken(base, 0.35f), Ui.darken(base, 0.8f),
                Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        updateBg(h);
        if (bgBmp != null) {
            Ui.cover(c, bgBmp, w, h);
            c.drawRect(0, 0, w, h, Ui.fill(0x33000000));
        } else {
            c.drawRect(0, 0, w, h, bgP);
        }

        // Героиня: когда говорит игрок, отходит назад (меньше, чуть в сторону и вниз) и темнеет
        c.save();
        float sc = 1f - 0.08f * dim;
        c.translate(w * 0.03f * dim, h * 0.03f * dim);
        c.scale(sc, sc, portR.centerX(), portR.bottom);
        Ui.figure(c, portR, portraitWho, dim);
        c.restore();

        if (idx >= q.size()) return;
        Data.Line l = q.get(idx);
        String full = fmt(l.text);
        int n = Math.min(full.length(), (int) reveal);
        boolean complete = n >= full.length();

        // Плашка с текстом: полупрозрачная
        c.drawRoundRect(boxR, 40f, 40f, boxP);
        c.drawRoundRect(boxR, 40f, 40f, boxRim);

        // Имя над плашкой слева, без цветной подложки
        String speaker = l.who <= 2 ? Data.HNAMES[l.who] : (l.who == 3 ? name : "");
        if (!speaker.isEmpty()) {
            float nx = boxR.left + w * 0.025f, ny = boxR.top - h * 0.025f;
            nameP.setColor(l.who <= 2 ? Ui.lighten(Data.HCOLORS[l.who], 1.1f) : 0xFFFFFFFF);
            nameP.setTextAlign(Paint.Align.LEFT);
            nameStroke.setTextAlign(Paint.Align.LEFT);
            c.drawText(speaker, nx, ny, nameStroke);
            c.drawText(speaker, nx, ny, nameP);
        }

        int textColor = l.who == 3 ? 0xFF5B6B92 : (l.who == 4 ? 0xFF6E5B66 : 0xFFB8715A);
        TextPaint tp = Ui.text(textColor, textSize, true);
        float pad = w * 0.03f;
        Ui.wrapped(c, full.substring(0, n), boxR.left + pad, boxR.top + pad * 0.9f,
                (int) (boxR.width() - 2 * pad), tp);

        if (complete) {
            float k = (float) (0.5 + 0.5 * Math.sin(System.nanoTime() / 2.2e8));
            Icons.draw(c, "play", boxR.right - pad, boxR.bottom - pad * 0.9f, h * 0.05f, 0xFFE07A8F,
                    (int) (120 + 135 * k));
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) return true;
        if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
        if (idx >= q.size()) return true;
        int len = fmt(q.get(idx).text).length();
        if (reveal < len) {
            reveal = len;
            invalidate();
            return true;
        }
        advance();
        return true;
    }

    private void advance() {
        idx++;
        if (idx >= q.size()) {
            if (!finished) {
                finished = true;
                running = false;
                done.run();
            }
            return;
        }
        reveal = 0f;
        syncPortrait();
        invalidate();
    }
}
