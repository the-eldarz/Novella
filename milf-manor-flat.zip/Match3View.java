package com.neighborvn;

import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.text.TextPaint;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Random;

/** Головоломка «три в ряд» с целями, ходами и бустерами. */
final class Match3View extends View {
    interface Listener {
        void onWin();
        void onLose();
        void onExit();
    }

    static final int COLS = 6, ROWS = 7, TYPES = 6;
    static final String[] EMOJI = {"[i:coffee]", "[i:cake]", "[i:rose]", "[i:gem]", "[i:strawberry]", "[i:honey]"};
    static final int[] COL = {0xFFB5733F, 0xFFF48FB1, 0xFFE53950, 0xFF42A5F5, 0xFFFF7043, 0xFFFFC107};
    private static final float SPEED = 8f; // клеток в секунду

    private static final int IDLE = 0, SWAP = 1, SWAPBACK = 2, CLEAR = 3, FALL = 4, WIN = 5, LOSE = 6;

    private final MainActivity a;
    private final GameState gs;
    private final Listener lis;
    private final int level, sub, who;

    private final int[][] g = new int[ROWS][COLS];
    private final float[][] ox = new float[ROWS][COLS];
    private final float[][] oy = new float[ROWS][COLS];
    private final float[][] sc = new float[ROWS][COLS];
    private final boolean[][] mk = new boolean[ROWS][COLS];
    private final int[] goalT = new int[3];
    private final int[] goalLeft = new int[3];
    private final int[] sw = new int[4];
    private int moves, phase = IDLE;
    private float clearT;
    private final Random rnd = new Random();
    private int selR = -1, selC = -1, downR = -1, downC = -1;
    private float downX, downY;
    private boolean hammer;
    private float idle;
    private int hintA = -1, hintB = -1;
    private String bubble;

    private float cell, bx, by;
    private final RectF boardR = new RectF(), exitR = new RectF(), bubbleR = new RectF(), portR = new RectF(),
            cardR = new RectF(), retryBtn = new RectF(), extraBtn = new RectF();
    private final RectF[] bR = new RectF[3];
    private Paint bgP;
    private final Paint tileP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Bitmap[] tileBmp = new Bitmap[TYPES];
    private Bitmap bgBmp;
    private final Paint bmpP = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final RectF tmpR = new RectF();
    private boolean running;
    private long lastT;

    Match3View(MainActivity a, int level, int sub, Listener lis) {
        super(a);
        this.a = a;
        this.gs = a.gs;
        this.level = level;
        this.sub = sub;
        this.lis = lis;
        int hr = Data.LEVELS[level].heroine;
        this.who = hr;
        for (int i = 0; i < 3; i++) bR[i] = new RectF();
        int base = (level + sub) % TYPES;
        for (int i = 0; i < 3; i++) {
            goalT[i] = (base + i * 2) % TYPES;
            goalLeft[i] = 5 + (level + 2 * sub) / 2;
        }
        moves = 15 + (level + 2 * sub) / 2;
        newBoard();
        if (level == 0 && sub == 0) {
            bubble = "Меняй местами соседние предметы, чтобы собрать три и больше в ряд. "
                    + "Выполни цели слева, пока не кончились ходы. Нажми, чтобы начать.";
        }
    }

    // ---------- логика ----------

    private void newBoard() {
        do {
            for (int r = 0; r < ROWS; r++) {
                for (int c = 0; c < COLS; c++) {
                    int t, tries = 0;
                    do {
                        t = rnd.nextInt(TYPES);
                        tries++;
                    } while (tries < 20 && makesRun(r, c, t));
                    g[r][c] = t;
                    ox[r][c] = 0f;
                    oy[r][c] = 0f;
                    sc[r][c] = 1f;
                    mk[r][c] = false;
                }
            }
        } while (!hasMove());
    }

    private boolean makesRun(int r, int c, int t) {
        if (c >= 2 && g[r][c - 1] == t && g[r][c - 2] == t) return true;
        return r >= 2 && g[r - 1][c] == t && g[r - 2][c] == t;
    }

    private boolean anyMatch() {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                int t = g[r][c];
                if (t < 0) continue;
                if (c + 2 < COLS && g[r][c + 1] == t && g[r][c + 2] == t) return true;
                if (r + 2 < ROWS && g[r + 1][c] == t && g[r + 2][c] == t) return true;
            }
        }
        return false;
    }

    private void swapRaw(int r1, int c1, int r2, int c2) {
        int t = g[r1][c1];
        g[r1][c1] = g[r2][c2];
        g[r2][c2] = t;
    }

    private boolean hasMove() {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (c + 1 < COLS) {
                    swapRaw(r, c, r, c + 1);
                    boolean m = anyMatch();
                    swapRaw(r, c, r, c + 1);
                    if (m) return true;
                }
                if (r + 1 < ROWS) {
                    swapRaw(r, c, r + 1, c);
                    boolean m = anyMatch();
                    swapRaw(r, c, r + 1, c);
                    if (m) return true;
                }
            }
        }
        return false;
    }

    private boolean findMatches() {
        boolean any = false;
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) mk[r][c] = false;
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                int t = g[r][c];
                if (t < 0) continue;
                if (c + 2 < COLS && g[r][c + 1] == t && g[r][c + 2] == t) {
                    mk[r][c] = mk[r][c + 1] = mk[r][c + 2] = true;
                    any = true;
                }
                if (r + 2 < ROWS && g[r + 1][c] == t && g[r + 2][c] == t) {
                    mk[r][c] = mk[r + 1][c] = mk[r + 2][c] = true;
                    any = true;
                }
            }
        }
        return any;
    }

    private void commitMarks() {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (!mk[r][c]) continue;
                int t = g[r][c];
                for (int i = 0; i < 3; i++) {
                    if (goalT[i] == t && goalLeft[i] > 0) goalLeft[i]--;
                }
            }
        }
    }

    private void swapAnim(int r1, int c1, int r2, int c2) {
        swapRaw(r1, c1, r2, c2);
        ox[r1][c1] = c2 - c1;
        oy[r1][c1] = r2 - r1;
        ox[r2][c2] = c1 - c2;
        oy[r2][c2] = r1 - r2;
    }

    private void startSwap(int r1, int c1, int r2, int c2) {
        sw[0] = r1; sw[1] = c1; sw[2] = r2; sw[3] = c2;
        swapAnim(r1, c1, r2, c2);
        phase = SWAP;
    }

    private void removeAndCollapse() {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (mk[r][c]) {
                    g[r][c] = -1;
                    mk[r][c] = false;
                    sc[r][c] = 1f;
                }
            }
        }
        for (int c = 0; c < COLS; c++) {
            int w = ROWS - 1;
            for (int r = ROWS - 1; r >= 0; r--) {
                if (g[r][c] >= 0) {
                    if (r != w) {
                        g[w][c] = g[r][c];
                        g[r][c] = -1;
                        oy[w][c] = r - w;
                        ox[w][c] = 0f;
                        sc[w][c] = 1f;
                    }
                    w--;
                }
            }
            for (int r = w; r >= 0; r--) {
                g[r][c] = rnd.nextInt(TYPES);
                oy[r][c] = -(w + 1);
                ox[r][c] = 0f;
                sc[r][c] = 1f;
            }
        }
    }

    private boolean settle(float dt) {
        boolean all = true;
        float step = SPEED * dt;
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                float x = ox[r][c];
                if (x != 0f) {
                    if (Math.abs(x) <= step) ox[r][c] = 0f;
                    else { ox[r][c] = x - Math.signum(x) * step; all = false; }
                }
                float y = oy[r][c];
                if (y != 0f) {
                    if (Math.abs(y) <= step) oy[r][c] = 0f;
                    else { oy[r][c] = y - Math.signum(y) * step; all = false; }
                }
            }
        }
        return all;
    }

    private void endTurn() {
        boolean done = true;
        for (int i = 0; i < 3; i++) if (goalLeft[i] > 0) done = false;
        if (done) {
            phase = WIN;
        } else if (moves <= 0) {
            phase = LOSE;
        } else {
            if (!hasMove()) newBoard();
            phase = IDLE;
        }
    }

    private void update(float dt) {
        if (phase == WIN || phase == LOSE) return;
        if (phase != IDLE) {
            idle = 0f;
            hintA = hintB = -1;
        } else if (gs.hintsOn() && bubble == null && !hammer) {
            idle += dt;
            if (idle > 6f && hintA < 0) findHint();
        }
        boolean settled = settle(dt);
        switch (phase) {
            case SWAP:
                if (settled) {
                    if (findMatches()) {
                        moves--;
                        commitMarks();
                        phase = CLEAR;
                        clearT = 0f;
                    } else {
                        swapAnim(sw[0], sw[1], sw[2], sw[3]);
                        phase = SWAPBACK;
                    }
                }
                break;
            case SWAPBACK:
                if (settled) phase = IDLE;
                break;
            case CLEAR:
                clearT += dt;
                float k = Math.max(0f, 1f - clearT / 0.18f);
                for (int r = 0; r < ROWS; r++) {
                    for (int c = 0; c < COLS; c++) if (mk[r][c]) sc[r][c] = k;
                }
                if (clearT >= 0.18f) {
                    removeAndCollapse();
                    phase = FALL;
                }
                break;
            case FALL:
                if (settled) {
                    if (findMatches()) {
                        commitMarks();
                        phase = CLEAR;
                        clearT = 0f;
                    } else {
                        endTurn();
                    }
                }
                break;
            default:
                break;
        }
    }

    // ---------- бустеры ----------

    private void useBooster(final int i) {
        if (phase != IDLE) return;
        if (i == 0 && hammer) {
            hammer = false;
            bubble = null;
            return;
        }
        if (gs.booster(i) <= 0) {
            Toast.makeText(a, "Бустеры закончились. Купи их в магазине.", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(a)
                .setTitle("Использовать бустер?")
                .setMessage(Data.BOOST_ICON[i] + " " + Data.BOOST_NAME[i] + ": " + Data.BOOST_DESC[i]
                        + "\nОсталось: " + gs.booster(i))
                .setPositiveButton("Да", (d, w) -> doBooster(i))
                .setNegativeButton("Нет", null)
                .show();
    }

    private void doBooster(int i) {
        if (phase != IDLE || gs.booster(i) <= 0) return;
        if (i == 0) {
            hammer = true;
            bubble = "Нажми на предмет, который хочешь убрать. Ещё раз на молоток, чтобы отменить.";
        } else if (i == 1) {
            gs.addBooster(1, -1);
            newBoard();
        } else {
            gs.addBooster(2, -1);
            moves += 5;
        }
    }

    // ---------- подсказка ----------

    private void findHint() {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (c + 1 < COLS) {
                    swapRaw(r, c, r, c + 1);
                    boolean m = anyMatch();
                    swapRaw(r, c, r, c + 1);
                    if (m) { hintA = r * COLS + c; hintB = r * COLS + c + 1; return; }
                }
                if (r + 1 < ROWS) {
                    swapRaw(r, c, r + 1, c);
                    boolean m = anyMatch();
                    swapRaw(r, c, r + 1, c);
                    if (m) { hintA = r * COLS + c; hintB = (r + 1) * COLS + c; return; }
                }
            }
        }
    }

    private void applyHammer(int r, int c) {
        gs.addBooster(0, -1);
        hammer = false;
        bubble = null;
        for (int rr = 0; rr < ROWS; rr++) for (int cc = 0; cc < COLS; cc++) mk[rr][cc] = false;
        mk[r][c] = true;
        commitMarks();
        phase = CLEAR;
        clearT = 0f;
    }

    // ---------- цикл и размеры ----------

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            long n = System.nanoTime();
            float dt = Math.min(0.05f, (n - lastT) / 1e9f);
            lastT = n;
            update(dt);
            invalidate();
            if (running) postOnAnimation(this);
        }
    };

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        running = true;
        lastT = System.nanoTime();
        postOnAnimation(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        super.onDetachedFromWindow();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        cell = Math.min(h * 0.74f / ROWS, w * 0.42f / COLS);
        bx = w * 0.31f;
        by = h * 0.06f;
        boardR.set(bx, by, bx + cell * COLS, by + cell * ROWS);
        float bwid = cell * COLS / 3f;
        float bY = boardR.bottom + h * 0.045f;
        float bH = h * 0.10f;
        for (int i = 0; i < 3; i++) {
            bR[i].set(bx + i * bwid + 6f, bY, bx + (i + 1) * bwid - 6f, bY + bH);
        }
        exitR.set(w * 0.02f, h * 0.02f, w * 0.02f + h * 0.08f, h * 0.02f + h * 0.08f);
        bubbleR.set(w * 0.62f, h * 0.05f, w * 0.97f, h * 0.30f);
        portR.set(w * 0.64f, 0f, w * 1.0f, h);
        float cw = w * 0.5f, ch = h * 0.4f;
        cardR.set((w - cw) / 2f, (h - ch) / 2f, (w + cw) / 2f, (h + ch) / 2f);
        retryBtn.set(cardR.left + cw * 0.06f, cardR.bottom - ch * 0.32f, cardR.centerX() - cw * 0.02f, cardR.bottom - ch * 0.08f);
        extraBtn.set(cardR.centerX() + cw * 0.02f, cardR.bottom - ch * 0.32f, cardR.right - cw * 0.06f, cardR.bottom - ch * 0.08f);
        int base = Data.HCOLORS[who];
        bgP = new Paint();
        bgP.setShader(new LinearGradient(0, 0, 0, h, Ui.darken(base, 0.35f), Ui.darken(base, 0.75f), Shader.TileMode.CLAMP));
        bgBmp = Art.bitmap(Data.LEVELS[level].bg());
        buildTiles();
    }

    /** Рисует 3D-плитки один раз в картинки: тень, толщина, градиент, блик и предмет. */
    private void buildTiles() {
        int sz = Math.max(8, (int) Math.ceil(cell));
        for (int t = 0; t < TYPES; t++) {
            Bitmap b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(b);
            float pad = sz * 0.07f;
            float depth = sz * 0.07f;
            RectF body = new RectF(pad, pad, sz - pad, sz - pad - depth);
            float rad = sz * 0.26f;

            Paint sh = Ui.fill(0x66000000);
            sh.setMaskFilter(new BlurMaskFilter(sz * 0.045f, BlurMaskFilter.Blur.NORMAL));
            RectF shR = new RectF(body);
            shR.offset(0, depth * 1.25f);
            cv.drawRoundRect(shR, rad, rad, sh);

            RectF under = new RectF(body);
            under.offset(0, depth);
            cv.drawRoundRect(under, rad, rad, Ui.fill(Ui.darken(COL[t], 0.55f)));

            Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
            bp.setShader(new LinearGradient(0, body.top, 0, body.bottom,
                    Ui.lighten(COL[t], 1.2f), Ui.darken(COL[t], 0.88f), Shader.TileMode.CLAMP));
            cv.drawRoundRect(body, rad, rad, bp);

            Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
            rim.setStyle(Paint.Style.STROKE);
            rim.setStrokeWidth(sz * 0.03f);
            rim.setShader(new LinearGradient(0, body.top, 0, body.bottom, 0xAAFFFFFF, 0x33000000, Shader.TileMode.CLAMP));
            RectF rr = new RectF(body);
            rr.inset(sz * 0.015f, sz * 0.015f);
            cv.drawRoundRect(rr, rad, rad, rim);

            RectF gl = new RectF(body.left + sz * 0.08f, body.top + sz * 0.05f,
                    body.right - sz * 0.08f, body.top + body.height() * 0.42f);
            Paint gp = new Paint(Paint.ANTI_ALIAS_FLAG);
            gp.setShader(new LinearGradient(0, gl.top, 0, gl.bottom, 0x99FFFFFF, 0x08FFFFFF, Shader.TileMode.CLAMP));
            cv.drawRoundRect(gl, rad * 0.8f, rad * 0.8f, gp);

            TextPaint tp = Ui.text(0xFFFFFFFF, sz * 0.62f, false);
            tp.setShadowLayer(sz * 0.03f, 0, sz * 0.03f, 0x77000000);
            Ui.centerText(cv, EMOJI[t], body.centerX(), body.centerY() + sz * 0.01f, tp);
            tileBmp[t] = b;
        }
    }

    // ---------- рисование ----------

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (bgBmp != null) {
            Ui.cover(c, bgBmp, w, h);
            c.drawRect(0, 0, w, h, Ui.fill(0x44000000));
        } else {
            c.drawRect(0, 0, w, h, bgP);
        }
        Ui.figure(c, portR, who);

        // Выход и заголовок
        Ui.plate(c, exitR, 0xFF3A3358, exitR.height() / 2f);
        Ui.centerText(c, "[i:close]", exitR.centerX(), exitR.centerY(), Ui.text(0xFFFFFFFF, h * 0.05f, true));
        Ui.outlined(c, Data.LEVELS[level].room + " · " + (sub + 1) + "/3", w * 0.17f, h * 0.07f, h * 0.042f,
                0xFFFFFFFF, 0xFF2A1740);

        // Ходы (кольцо)
        float mx = w * 0.14f, my = h * 0.25f, mr = h * 0.095f;
        c.drawCircle(mx, my + mr * 0.08f, mr, Ui.fill(0x66000000));
        c.drawCircle(mx, my, mr, Ui.fill(0xDD3A2060));
        Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(mr * 0.2f);
        ring.setShader(new LinearGradient(0, my - mr, 0, my + mr, 0xFFF0B3FF, 0xFF9B5BD6, Shader.TileMode.CLAMP));
        c.drawCircle(mx, my, mr * 0.9f, ring);
        Ui.outlined(c, String.valueOf(moves), mx, my - mr * 0.1f, mr * 0.95f, 0xFFFFFFFF, 0xFF5A2D8C);
        Ui.centerText(c, "ходы", mx, my + mr * 0.62f, Ui.text(0xCCFFFFFF, mr * 0.3f, false));

        // Цели
        float gs2 = h * 0.12f;
        for (int i = 0; i < 3; i++) {
            float gy = h * 0.46f + i * h * 0.16f;
            RectF d = new RectF(w * 0.08f - gs2 / 2f, gy - gs2 / 2f, w * 0.08f + gs2 / 2f, gy + gs2 / 2f);
            c.drawBitmap(tileBmp[goalT[i]], null, d, bmpP);
            boolean ok = goalLeft[i] <= 0;
            Ui.outlined(c, ok ? "[i:check]" : String.valueOf(goalLeft[i]), w * 0.19f, gy, h * 0.075f,
                    ok ? 0xFF9CFF9C : 0xFFFFFFFF, 0xFF2A1740);
        }

        // Поле в объёмной рамке
        RectF fr = new RectF(boardR);
        fr.inset(-cell * 0.14f, -cell * 0.14f);
        Ui.plate(c, fr, 0xFFB486E3, cell * 0.3f);
        c.drawRoundRect(boardR, cell * 0.18f, cell * 0.18f, Ui.fill(0xCCFFE9F3));
        c.save();
        c.clipRect(boardR);
        for (int r = 0; r < ROWS; r++) {
            for (int cc = 0; cc < COLS; cc++) {
                if (((r + cc) & 1) == 0) {
                    c.drawRect(bx + cc * cell, by + r * cell, bx + (cc + 1) * cell, by + (r + 1) * cell,
                            Ui.fill(0x22A050C0));
                }
            }
        }
        float pulse = 1.08f + 0.03f * (float) Math.sin(System.nanoTime() / 1.2e8);
        for (int r = 0; r < ROWS; r++) {
            for (int cc = 0; cc < COLS; cc++) {
                int t = g[r][cc];
                if (t < 0) continue;
                float s = sc[r][cc];
                if (s <= 0.02f) continue;
                boolean selected = r == selR && cc == selC;
                if (selected) s *= pulse;
                float cx = bx + (cc + 0.5f + ox[r][cc]) * cell;
                float cy = by + (r + 0.5f + oy[r][cc]) * cell;
                float half = cell * 0.5f * s;
                tmpR.set(cx - half, cy - half, cx + half, cy + half);
                if (selected) {
                    tileP.setStyle(Paint.Style.STROKE);
                    tileP.setStrokeWidth(cell * 0.06f);
                    tileP.setColor(0xFFFFFFFF);
                    c.drawRoundRect(tmpR, cell * 0.28f, cell * 0.28f, tileP);
                }
                c.drawBitmap(tileBmp[t], null, tmpR, bmpP);
            }
        }
        if (hintA >= 0 && phase == IDLE) drawHint(c);
        c.restore();

        // Бустеры
        for (int i = 0; i < 3; i++) {
            int col = (i == 0 && hammer) ? 0xFFE9B949 : 0xFF8C6BD1;
            Ui.plate(c, bR[i], col, 22f);
            Ui.centerText(c, Data.BOOST_ICON[i], bR[i].centerX() - bR[i].width() * 0.15f, bR[i].centerY(),
                    Ui.text(0xFFFFFFFF, bR[i].height() * 0.5f, false));
            Ui.outlined(c, "x" + gs.booster(i), bR[i].centerX() + bR[i].width() * 0.22f, bR[i].centerY(),
                    bR[i].height() * 0.3f, 0xFFFFFFFF, 0xFF3A2060);
        }

        // Подсказка
        if (bubble != null) {
            c.drawRoundRect(bubbleR, 28f, 28f, Ui.fill(0xF2FFFFFF));
            Ui.wrapped(c, bubble, bubbleR.left + w * 0.015f, bubbleR.top + h * 0.02f,
                    (int) (bubbleR.width() - w * 0.03f), Ui.text(0xFF2B2D42, h * 0.036f, false));
        }

        // Итоги
        if (phase == WIN || phase == LOSE) {
            c.drawRect(0, 0, w, h, Ui.fill(0xAA000000));
            Ui.plate(c, cardR, 0xFFFFFFFF, 36f);
            if (phase == WIN) {
                Ui.centerText(c, "Победа! [i:heart]", cardR.centerX(), cardR.top + cardR.height() * 0.28f,
                        Ui.text(0xFFE0485F, h * 0.09f, true));
                Ui.centerText(c, "+20 [i:gem]", cardR.centerX(), cardR.top + cardR.height() * 0.58f,
                        Ui.text(0xFF2B2D42, h * 0.06f, true));
                Ui.centerText(c, "Нажми, чтобы продолжить", cardR.centerX(), cardR.bottom - cardR.height() * 0.15f,
                        Ui.text(0xFF8E8EA8, h * 0.04f, false));
            } else {
                Ui.centerText(c, "Ходы закончились", cardR.centerX(), cardR.top + cardR.height() * 0.28f,
                        Ui.text(0xFF2B2D42, h * 0.07f, true));
                Ui.button(c, retryBtn, "Заново", 0xFF9B7EDE, 0xFFFFFFFF, h * 0.045f);
                Ui.button(c, extraBtn, "+5 ходов (30 [i:gem])", 0xFFE0485F, 0xFFFFFFFF, h * 0.04f);
            }
        }
    }

    private void drawHint(Canvas c) {
        float k = (float) (0.5 + 0.5 * Math.sin(System.nanoTime() / 2.5e8));
        tileP.setStyle(Paint.Style.STROKE);
        tileP.setStrokeWidth(cell * 0.07f);
        tileP.setColor(0xFFFFE066);
        tileP.setAlpha((int) (110 + 145 * k));
        int[] ids = {hintA, hintB};
        for (int id : ids) {
            int r = id / COLS, cc = id % COLS;
            tmpR.set(bx + cc * cell + cell * 0.04f, by + r * cell + cell * 0.04f,
                    bx + (cc + 1) * cell - cell * 0.04f, by + (r + 1) * cell - cell * 0.04f);
            c.drawRoundRect(tmpR, cell * 0.28f, cell * 0.28f, tileP);
        }
        tileP.setAlpha(255);
        float ax = bx + (hintA % COLS + 0.5f) * cell, ay = by + (hintA / COLS + 0.5f) * cell;
        float bxx = bx + (hintB % COLS + 0.5f) * cell, byy = by + (hintB / COLS + 0.5f) * cell;
        float t = (System.nanoTime() / 1e9f * 1.1f) % 1f;
        float e = t < 0.7f ? t / 0.7f : 1f;
        Ui.centerText(c, "[i:hand]", ax + (bxx - ax) * e + cell * 0.12f, ay + (byy - ay) * e + cell * 0.28f,
                Ui.text(0xFFFFFFFF, cell * 0.6f, false));
    }

    // ---------- ввод ----------

    private int rowAt(float y) {
        if (y < by || y >= by + cell * ROWS) return -1;
        return (int) ((y - by) / cell);
    }

    private int colAt(float x) {
        if (x < bx || x >= bx + cell * COLS) return -1;
        return (int) ((x - bx) / cell);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_DOWN) {
            idle = 0f;
            hintA = hintB = -1;
            downX = x;
            downY = y;
            downR = rowAt(y);
            downC = colAt(x);
            return true;
        }
        if (act == MotionEvent.ACTION_UP) handleUp(x, y);
        return true;
    }

    private void handleUp(float x, float y) {
        if (phase == WIN) {
            lis.onWin();
            return;
        }
        if (phase == LOSE) {
            if (retryBtn.contains(x, y)) {
                lis.onLose();
            } else if (extraBtn.contains(x, y)) {
                if (gs.spend(30)) {
                    moves += 5;
                    phase = IDLE;
                } else {
                    Toast.makeText(a, "Не хватает алмазов", Toast.LENGTH_SHORT).show();
                }
            } else if (exitR.contains(x, y)) {
                lis.onExit();
            }
            return;
        }
        if (exitR.contains(x, y)) {
            lis.onExit();
            return;
        }
        if (bubble != null && !hammer) {
            bubble = null;
            return;
        }
        for (int i = 0; i < 3; i++) {
            if (bR[i].contains(x, y)) {
                useBooster(i);
                return;
            }
        }
        if (phase != IDLE || downR < 0 || downC < 0) return;
        if (hammer) {
            applyHammer(downR, downC);
            return;
        }
        float dx = x - downX, dy = y - downY;
        if (Math.max(Math.abs(dx), Math.abs(dy)) > cell * 0.3f) {
            int r2 = downR, c2 = downC;
            if (Math.abs(dx) > Math.abs(dy)) c2 += dx > 0 ? 1 : -1;
            else r2 += dy > 0 ? 1 : -1;
            selR = selC = -1;
            if (r2 >= 0 && r2 < ROWS && c2 >= 0 && c2 < COLS) startSwap(downR, downC, r2, c2);
            return;
        }
        if (selR < 0) {
            selR = downR;
            selC = downC;
        } else if (selR == downR && selC == downC) {
            selR = selC = -1;
        } else if (Math.abs(selR - downR) + Math.abs(selC - downC) == 1) {
            int r1 = selR, c1 = selC;
            selR = selC = -1;
            startSwap(r1, c1, downR, downC);
        } else {
            selR = downR;
            selC = downC;
        }
    }
}
