package com.neighborvn;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.text.TextPaint;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.util.Random;

/** Головоломка «три в ряд» с целями, ходами и бустерами. */
final class Match3View extends View {
    interface Listener {
        void onWin();
        void onLose();
        void onExit();
    }

    static final int COLS = 6, ROWS = 7, TYPES = 6;
    static final String[] EMOJI = {"☕", "🍰", "🌹", "💎", "🍓", "🍯"};
    static final int[] COL = {0xFFC58B5E, 0xFFF6B3CB, 0xFFE4566B, 0xFF63B7E6, 0xFFFF8A5B, 0xFFF2C94C};
    private static final float SPEED = 8f; // клеток в секунду

    private static final int IDLE = 0, SWAP = 1, SWAPBACK = 2, CLEAR = 3, FALL = 4, WIN = 5, LOSE = 6;

    private final MainActivity a;
    private final GameState gs;
    private final Listener lis;
    private final int level, sub, who;

    private final int[][] g = new int[ROWS][COLS];
    private final float[][] ox = new float[ROWS][COLS];
    private final float[][] oy = new float[ROWS][COLS];
    private final float[][] sc = new float[ROWS][COLS];
    private final boolean[][] mk = new boolean[ROWS][COLS];
    private final int[] goalT = new int[3];
    private final int[] goalLeft = new int[3];
    private final int[] sw = new int[4];
    private int moves, phase = IDLE;
    private float clearT;
    private final Random rnd = new Random();
    private int selR = -1, selC = -1, downR = -1, downC = -1;
    private float downX, downY;
    private boolean hammer;
    private String bubble;

    private float cell, bx, by;
    private final RectF boardR = new RectF(), exitR = new RectF(), bubbleR = new RectF(), portR = new RectF(),
            cardR = new RectF(), retryBtn = new RectF(), extraBtn = new RectF();
    private final RectF[] bR = new RectF[3];
    private Paint bgP;
    private final Paint tileP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private TextPaint emojiP;
    private boolean running;
    private long lastT;

    Match3View(MainActivity a, int level, int sub, Listener lis) {
        super(a);
        this.a = a;
        this.gs = a.gs;
        this.level = level;
        this.sub = sub;
        this.lis = lis;
        int hr = Data.LEVELS[level].heroine;
        this.who = hr == 3 ? 0 : hr;
        for (int i = 0; i < 3; i++) bR[i] = new RectF();
        int base = (level + sub) % TYPES;
        for (int i = 0; i < 3; i++) {
            goalT[i] = (base + i * 2) % TYPES;
            goalLeft[i] = 5 + (level + 2 * sub) / 2;
        }
        moves = 15 + (level + 2 * sub) / 2;
        newBoard();
        if (level == 0 && sub == 0) {
            bubble = "Меняй местами соседние предметы, чтобы собрать три и больше в ряд. "
                    + "Выполни цели слева, пока не кончились ходы. Нажми, чтобы начать.";
        }
    }

    // ---------- логика ----------

    private void newBoard() {
        do {
            for (int r = 0; r < ROWS; r++) {
                for (int c = 0; c < COLS; c++) {
                    int t, tries = 0;
                    do {
                        t = rnd.nextInt(TYPES);
                        tries++;
                    } while (tries < 20 && makesRun(r, c, t));
                    g[r][c] = t;
                    ox[r][c] = 0f;
                    oy[r][c] = 0f;
                    sc[r][c] = 1f;
                    mk[r][c] = false;
                }
            }
        } while (!hasMove());
    }

    private boolean makesRun(int r, int c, int t) {
        if (c >= 2 && g[r][c - 1] == t && g[r][c - 2] == t) return true;
        return r >= 2 && g[r - 1][c] == t && g[r - 2][c] == t;
    }

    private boolean anyMatch() {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                int t = g[r][c];
                if (t < 0) continue;
                if (c + 2 < COLS && g[r][c + 1] == t && g[r][c + 2] == t) return true;
                if (r + 2 < ROWS && g[r + 1][c] == t && g[r + 2][c] == t) return true;
            }
        }
        return false;
    }

    private void swapRaw(int r1, int c1, int r2, int c2) {
        int t = g[r1][c1];
        g[r1][c1] = g[r2][c2];
        g[r2][c2] = t;
    }

    private boolean hasMove() {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (c + 1 < COLS) {
                    swapRaw(r, c, r, c + 1);
                    boolean m = anyMatch();
                    swapRaw(r, c, r, c + 1);
                    if (m) return true;
                }
                if (r + 1 < ROWS) {
                    swapRaw(r, c, r + 1, c);
                    boolean m = anyMatch();
                    swapRaw(r, c, r + 1, c);
                    if (m) return true;
                }
            }
        }
        return false;
    }

    private boolean findMatches() {
        boolean any = false;
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) mk[r][c] = false;
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                int t = g[r][c];
                if (t < 0) continue;
                if (c + 2 < COLS && g[r][c + 1] == t && g[r][c + 2] == t) {
                    mk[r][c] = mk[r][c + 1] = mk[r][c + 2] = true;
                    any = true;
                }
                if (r + 2 < ROWS && g[r + 1][c] == t && g[r + 2][c] == t) {
                    mk[r][c] = mk[r + 1][c] = mk[r + 2][c] = true;
                    any = true;
                }
            }
        }
        return any;
    }

    private void commitMarks() {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (!mk[r][c]) continue;
                int t = g[r][c];
                for (int i = 0; i < 3; i++) {
                    if (goalT[i] == t && goalLeft[i] > 0) goalLeft[i]--;
                }
            }
        }
    }

    private void swapAnim(int r1, int c1, int r2, int c2) {
        swapRaw(r1, c1, r2, c2);
        ox[r1][c1] = c2 - c1;
        oy[r1][c1] = r2 - r1;
        ox[r2][c2] = c1 - c2;
        oy[r2][c2] = r1 - r2;
    }

    private void startSwap(int r1, int c1, int r2, int c2) {
        sw[0] = r1; sw[1] = c1; sw[2] = r2; sw[3] = c2;
        swapAnim(r1, c1, r2, c2);
        phase = SWAP;
    }

    private void removeAndCollapse() {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                if (mk[r][c]) {
                    g[r][c] = -1;
                    mk[r][c] = false;
                    sc[r][c] = 1f;
                }
            }
        }
        for (int c = 0; c < COLS; c++) {
            int w = ROWS - 1;
            for (int r = ROWS - 1; r >= 0; r--) {
                if (g[r][c] >= 0) {
                    if (r != w) {
                        g[w][c] = g[r][c];
                        g[r][c] = -1;
                        oy[w][c] = r - w;
                        ox[w][c] = 0f;
                        sc[w][c] = 1f;
                    }
                    w--;
                }
            }
            for (int r = w; r >= 0; r--) {
                g[r][c] = rnd.nextInt(TYPES);
                oy[r][c] = -(w + 1);
                ox[r][c] = 0f;
                sc[r][c] = 1f;
            }
        }
    }

    private boolean settle(float dt) {
        boolean all = true;
        float step = SPEED * dt;
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                float x = ox[r][c];
                if (x != 0f) {
                    if (Math.abs(x) <= step) ox[r][c] = 0f;
                    else { ox[r][c] = x - Math.signum(x) * step; all = false; }
                }
                float y = oy[r][c];
                if (y != 0f) {
                    if (Math.abs(y) <= step) oy[r][c] = 0f;
                    else { oy[r][c] = y - Math.signum(y) * step; all = false; }
                }
            }
        }
        return all;
    }

    private void endTurn() {
        boolean done = true;
        for (int i = 0; i < 3; i++) if (goalLeft[i] > 0) done = false;
        if (done) {
            phase = WIN;
        } else if (moves <= 0) {
            phase = LOSE;
        } else {
            if (!hasMove()) newBoard();
            phase = IDLE;
        }
    }

    private void update(float dt) {
        if (phase == WIN || phase == LOSE) return;
        boolean settled = settle(dt);
        switch (phase) {
            case SWAP:
                if (settled) {
                    if (findMatches()) {
                        moves--;
                        commitMarks();
                        phase = CLEAR;
                        clearT = 0f;
                    } else {
                        swapAnim(sw[0], sw[1], sw[2], sw[3]);
                        phase = SWAPBACK;
                    }
                }
                break;
            case SWAPBACK:
                if (settled) phase = IDLE;
                break;
            case CLEAR:
                clearT += dt;
                float k = Math.max(0f, 1f - clearT / 0.18f);
                for (int r = 0; r < ROWS; r++) {
                    for (int c = 0; c < COLS; c++) if (mk[r][c]) sc[r][c] = k;
                }
                if (clearT >= 0.18f) {
                    removeAndCollapse();
                    phase = FALL;
                }
                break;
            case FALL:
                if (settled) {
                    if (findMatches()) {
                        commitMarks();
                        phase = CLEAR;
                        clearT = 0f;
                    } else {
                        endTurn();
                    }
                }
                break;
            default:
                break;
        }
    }

    // ---------- бустеры ----------

    private void useBooster(int i) {
        if (phase != IDLE) return;
        if (gs.booster(i) <= 0) {
            Toast.makeText(a, "Бустеры закончились. Купи их в магазине.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (i == 0) {
            hammer = !hammer;
            bubble = hammer ? "Нажми на предмет, который хочешь убрать." : null;
        } else if (i == 1) {
            gs.addBooster(1, -1);
            newBoard();
        } else {
            gs.addBooster(2, -1);
            moves += 5;
        }
    }

    private void applyHammer(int r, int c) {
        gs.addBooster(0, -1);
        hammer = false;
        bubble = null;
        for (int rr = 0; rr < ROWS; rr++) for (int cc = 0; cc < COLS; cc++) mk[rr][cc] = false;
        mk[r][c] = true;
        commitMarks();
        phase = CLEAR;
        clearT = 0f;
    }

    // ---------- цикл и размеры ----------

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            long n = System.nanoTime();
            float dt = Math.min(0.05f, (n - lastT) / 1e9f);
            lastT = n;
            update(dt);
            invalidate();
            if (running) postOnAnimation(this);
        }
    };

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        running = true;
        lastT = System.nanoTime();
        postOnAnimation(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        super.onDetachedFromWindow();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        cell = Math.min(h * 0.70f / ROWS, w * 0.42f / COLS);
        bx = w * 0.30f;
        by = h * 0.08f;
        boardR.set(bx, by, bx + cell * COLS, by + cell * ROWS);
        float bwid = cell * COLS / 3f;
        float bY = boardR.bottom + h * 0.03f;
        float bH = h * 0.12f;
        for (int i = 0; i < 3; i++) {
            bR[i].set(bx + i * bwid + 6f, bY, bx + (i + 1) * bwid - 6f, bY + bH);
        }
        exitR.set(w * 0.02f, h * 0.02f, w * 0.02f + h * 0.08f, h * 0.02f + h * 0.08f);
        bubbleR.set(w * 0.70f, h * 0.06f, w * 0.98f, h * 0.40f);
        portR.set(w * 0.74f, h * 0.43f, w * 0.98f, h * 0.97f);
        float cw = w * 0.5f, ch = h * 0.4f;
        cardR.set((w - cw) / 2f, (h - ch) / 2f, (w + cw) / 2f, (h + ch) / 2f);
        retryBtn.set(cardR.left + cw * 0.06f, cardR.bottom - ch * 0.32f, cardR.centerX() - cw * 0.02f, cardR.bottom - ch * 0.08f);
        extraBtn.set(cardR.centerX() + cw * 0.02f, cardR.bottom - ch * 0.32f, cardR.right - cw * 0.06f, cardR.bottom - ch * 0.08f);
        int base = Data.HCOLORS[who];
        bgP = new Paint();
        bgP.setShader(new LinearGradient(0, 0, 0, h, Ui.darken(base, 0.35f), Ui.darken(base, 0.75f), Shader.TileMode.CLAMP));
        emojiP = Ui.text(0xFFFFFFFF, cell * 0.5f, false);
    }

    // ---------- рисование ----------

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawRect(0, 0, w, h, bgP);

        // Заголовок и выход
        c.drawCircle(exitR.centerX(), exitR.centerY(), exitR.width() / 2f, Ui.fill(0xAA000000));
        Ui.centerText(c, "✕", exitR.centerX(), exitR.centerY(), Ui.text(0xFFFFFFFF, h * 0.05f, true));
        Ui.centerText(c, Data.LEVELS[level].room + " · " + (sub + 1) + "/3", w * 0.15f, h * 0.07f,
                Ui.text(0xFFFFFFFF, h * 0.042f, true));

        // Ходы и цели
        float mx = w * 0.14f, my = h * 0.25f, mr = h * 0.09f;
        c.drawCircle(mx, my, mr, Ui.fill(0xAA000000));
        Ui.centerText(c, String.valueOf(moves), mx, my - mr * 0.1f, Ui.text(0xFFFFFFFF, mr * 0.95f, true));
        Ui.centerText(c, "ходы", mx, my + mr * 0.62f, Ui.text(0xCCFFFFFF, mr * 0.3f, false));
        for (int i = 0; i < 3; i++) {
            float gy = h * 0.46f + i * h * 0.16f;
            c.drawCircle(w * 0.08f, gy, h * 0.05f, Ui.fill(COL[goalT[i]]));
            Ui.centerText(c, EMOJI[goalT[i]], w * 0.08f, gy, Ui.text(0xFFFFFFFF, h * 0.05f, false));
            String s = goalLeft[i] > 0 ? String.valueOf(goalLeft[i]) : "✓";
            Ui.centerText(c, s, w * 0.19f, gy, Ui.text(goalLeft[i] > 0 ? 0xFFFFFFFF : 0xFF9CFF9C, h * 0.07f, true));
        }

        // Поле
        c.drawRoundRect(boardR, 24f, 24f, Ui.fill(0x66000000));
        c.save();
        c.clipRect(boardR);
        for (int r = 0; r < ROWS; r++) {
            for (int cc = 0; cc < COLS; cc++) {
                int t = g[r][cc];
                if (t < 0) continue;
                float s = sc[r][cc];
                if (s <= 0.02f) continue;
                float cx = bx + (cc + 0.5f + ox[r][cc]) * cell;
                float cy = by + (r + 0.5f + oy[r][cc]) * cell;
                tileP.setStyle(Paint.Style.FILL);
                tileP.setColor(COL[t]);
                c.drawCircle(cx, cy, cell * 0.43f * s, tileP);
                emojiP.setTextSize(cell * 0.5f * s);
                Ui.centerText(c, EMOJI[t], cx, cy, emojiP);
                if (r == selR && cc == selC) {
                    tileP.setStyle(Paint.Style.STROKE);
                    tileP.setStrokeWidth(cell * 0.07f);
                    tileP.setColor(0xFFFFFFFF);
                    c.drawCircle(cx, cy, cell * 0.46f, tileP);
                }
            }
        }
        c.restore();

        // Бустеры
        for (int i = 0; i < 3; i++) {
            int col = (i == 0 && hammer) ? 0xFFFFD54F : 0xFF4A4468;
            c.drawRoundRect(bR[i], 22f, 22f, Ui.fill(col));
            Ui.centerText(c, Data.BOOST_ICON[i], bR[i].centerX() - bR[i].width() * 0.15f, bR[i].centerY(),
                    Ui.text(0xFFFFFFFF, bR[i].height() * 0.5f, false));
            Ui.centerText(c, "x" + gs.booster(i), bR[i].centerX() + bR[i].width() * 0.22f, bR[i].centerY(),
                    Ui.text(0xFFFFFFFF, bR[i].height() * 0.3f, true));
        }

        // Героиня и подсказка
        Ui.portrait(c, portR, Data.HCOLORS[who], Data.HINIT[who], Data.HNAMES[who]);
        if (bubble != null) {
            c.drawRoundRect(bubbleR, 28f, 28f, Ui.fill(0xF2FFFFFF));
            Ui.wrapped(c, bubble, bubbleR.left + w * 0.015f, bubbleR.top + h * 0.02f,
                    (int) (bubbleR.width() - w * 0.03f), Ui.text(0xFF2B2D42, h * 0.036f, false));
        }

        // Итоги
        if (phase == WIN || phase == LOSE) {
            c.drawRect(0, 0, w, h, Ui.fill(0xAA000000));
            c.drawRoundRect(cardR, 36f, 36f, Ui.fill(0xFFFFFFFF));
            if (phase == WIN) {
                Ui.centerText(c, "Победа! ♥", cardR.centerX(), cardR.top + cardR.height() * 0.28f,
                        Ui.text(0xFFE0485F, h * 0.09f, true));
                Ui.centerText(c, "+20 💎", cardR.centerX(), cardR.top + cardR.height() * 0.58f,
                        Ui.text(0xFF2B2D42, h * 0.06f, true));
                Ui.centerText(c, "Нажми, чтобы продолжить", cardR.centerX(), cardR.bottom - cardR.height() * 0.15f,
                        Ui.text(0xFF8E8EA8, h * 0.04f, false));
            } else {
                Ui.centerText(c, "Ходы закончились", cardR.centerX(), cardR.top + cardR.height() * 0.28f,
                        Ui.text(0xFF2B2D42, h * 0.07f, true));
                Ui.button(c, retryBtn, "Заново", 0xFF9B7EDE, 0xFFFFFFFF, h * 0.045f);
                Ui.button(c, extraBtn, "+5 ходов (30 💎)", 0xFFE0485F, 0xFFFFFFFF, h * 0.04f);
            }
        }
    }

    // ---------- ввод ----------

    private int rowAt(float y) {
        if (y < by || y >= by + cell * ROWS) return -1;
        return (int) ((y - by) / cell);
    }

    private int colAt(float x) {
        if (x < bx || x >= bx + cell * COLS) return -1;
        return (int) ((x - bx) / cell);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_DOWN) {
            downX = x;
            downY = y;
            downR = rowAt(y);
            downC = colAt(x);
            return true;
        }
        if (act == MotionEvent.ACTION_UP) handleUp(x, y);
        return true;
    }

    private void handleUp(float x, float y) {
        if (phase == WIN) {
            lis.onWin();
            return;
        }
        if (phase == LOSE) {
            if (retryBtn.contains(x, y)) {
                lis.onLose();
            } else if (extraBtn.contains(x, y)) {
                if (gs.spend(30)) {
                    moves += 5;
                    phase = IDLE;
                } else {
                    Toast.makeText(a, "Не хватает алмазов", Toast.LENGTH_SHORT).show();
                }
            } else if (exitR.contains(x, y)) {
                lis.onExit();
            }
            return;
        }
        if (exitR.contains(x, y)) {
            lis.onExit();
            return;
        }
        if (bubble != null && !hammer) {
            bubble = null;
            return;
        }
        for (int i = 0; i < 3; i++) {
            if (bR[i].contains(x, y)) {
                useBooster(i);
                return;
            }
        }
        if (phase != IDLE || downR < 0 || downC < 0) return;
        if (hammer) {
            applyHammer(downR, downC);
            return;
        }
        float dx = x - downX, dy = y - downY;
        if (Math.max(Math.abs(dx), Math.abs(dy)) > cell * 0.3f) {
            int r2 = downR, c2 = downC;
            if (Math.abs(dx) > Math.abs(dy)) c2 += dx > 0 ? 1 : -1;
            else r2 += dy > 0 ? 1 : -1;
            selR = selC = -1;
            if (r2 >= 0 && r2 < ROWS && c2 >= 0 && c2 < COLS) startSwap(downR, downC, r2, c2);
            return;
        }
        if (selR < 0) {
            selR = downR;
            selC = downC;
        } else if (selR == downR && selC == downC) {
            selR = selC = -1;
        } else if (Math.abs(selR - downR) + Math.abs(selC - downC) == 1) {
            int r1 = selR, c1 = selC;
            selR = selC = -1;
            startSwap(r1, c1, downR, downC);
        } else {
            selR = downR;
            selC = downC;
        }
    }
}
