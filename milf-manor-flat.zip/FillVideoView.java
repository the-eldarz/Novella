package com.neighborvn;

import android.content.Context;
import android.widget.VideoView;

/**
 * Видео на весь экран без чёрных полос.
 * COVER: растягивает с сохранением пропорций, лишнее по краям обрезается (без искажений).
 * STRETCH: растягивает точно по экрану, пропорции не сохраняются (картинка сплющится).
 * CONTAIN: видео целиком по центру с сохранением пропорций, по краям чёрные полосы.
 */
final class FillVideoView extends VideoView {
    static final int COVER = 0, STRETCH = 1, CONTAIN = 2;

    private final int mode;
    private int vw, vh;

    FillVideoView(Context c, int mode) {
        super(c);
        this.mode = mode;
    }

    void setVideoSize(int w, int h) {
        vw = w;
        vh = h;
        requestLayout();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int pw = MeasureSpec.getSize(widthSpec), ph = MeasureSpec.getSize(heightSpec);
        if (mode == STRETCH || vw <= 0 || vh <= 0) {
            setMeasuredDimension(pw, ph);
            return;
        }
        float sx = pw / (float) vw, sy = ph / (float) vh;
        float s = mode == CONTAIN ? Math.min(sx, sy) : Math.max(sx, sy);
        setMeasuredDimension(Math.round(vw * s), Math.round(vh * s));
    }
}
