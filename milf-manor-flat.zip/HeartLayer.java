package com.neighborvn;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import java.util.ArrayList;
import java.util.Random;

/** Слой поверх всех экранов: при каждом касании вокруг места нажатия вылетают сердечки. */
final class HeartLayer extends View {
    private static final class P {
        float x, y, vx, vy, age, life, size;
        int color;
    }

    private static final int[] COLORS = {0xFFFF4D6D, 0xFFFF7A9C, 0xFFFFB3C6, 0xFFFF2E63};

    private final ArrayList<P> ps = new ArrayList<>();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rnd = new Random();
    private final float density;
    private long last;

    HeartLayer(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        paint.setTextAlign(Paint.Align.CENTER);
        setClickable(false);
    }

    void burst(float x, float y, int n) {
        if (ps.isEmpty()) last = System.nanoTime();
        for (int i = 0; i < n; i++) {
            P p = new P();
            p.x = x + (rnd.nextFloat() - 0.5f) * 30f * density;
            p.y = y;
            p.vx = (rnd.nextFloat() - 0.5f) * 170f * density;
            p.vy = -(60f + rnd.nextFloat() * 150f) * density;
            p.life = 0.8f + rnd.nextFloat() * 0.6f;
            p.size = (14f + rnd.nextFloat() * 16f) * density;
            p.color = COLORS[rnd.nextInt(COLORS.length)];
            ps.add(p);
        }
        postInvalidateOnAnimation();
    }

    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        for (int i = ps.size() - 1; i >= 0; i--) {
            P p = ps.get(i);
            p.age += dt;
            if (p.age >= p.life) {
                ps.remove(i);
                continue;
            }
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.vy += 40f * density * dt;
            float a = 1f - p.age / p.life;
            paint.setColor(p.color);
            paint.setAlpha((int) (255 * a));
            paint.setTextSize(p.size);
            c.drawText("♥", p.x, p.y, paint);
        }
        if (!ps.isEmpty()) postInvalidateOnAnimation();
    }
}
