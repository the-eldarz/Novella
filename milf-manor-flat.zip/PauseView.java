package com.neighborvn;

import android.graphics.Canvas;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** Пауза: розовая панель с тремя кнопками, как в оригинале. Рисуется поверх карты. */
final class PauseView extends View {
    private static final String[] LABEL = {"Продолжить", "Настройки", "Меню"};

    private final MainActivity a;
    private final RectF panelR = new RectF(), titleR = new RectF();
    private final RectF[] btn = new RectF[3];

    PauseView(MainActivity a) {
        super(a);
        this.a = a;
        for (int i = 0; i < 3; i++) btn[i] = new RectF();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        panelR.set(w * 0.35f, h * 0.19f, w * 0.65f, h * 0.80f);
        titleR.set(w * 0.37f, h * 0.08f, w * 0.63f, h * 0.20f);
        float bw = panelR.width() * 0.78f, x = panelR.centerX() - bw / 2f;
        float bh = h * 0.115f, y0 = h * 0.30f, gap = h * 0.04f;
        for (int i = 0; i < 3; i++) btn[i].set(x, y0 + i * (bh + gap), x + bw, y0 + i * (bh + gap) + bh);
    }

    @Override
    protected void onDraw(Canvas c) {
        int h = getHeight();
        c.drawRoundRect(panelR, 24f, 24f, Ui.fill(0xFFEEC2E8));
        c.drawRoundRect(titleR.left, titleR.top, titleR.right, panelR.top + 30f, 24f, 24f, Ui.fill(0xFFFFFFFF));
        Ui.centerText(c, "Пауза", titleR.centerX(), titleR.top + titleR.height() * 0.45f,
                Ui.text(0xFFE07A9F, h * 0.075f, true));
        for (int i = 0; i < 3; i++) Ui.slant(c, btn[i], LABEL[i], 0xFFE0869F, 0xFFFFFFFF, h * 0.05f);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
        float x = e.getX(), y = e.getY();
        if (btn[0].contains(x, y)) {
            Sound.sfx("sfx_click");
            a.closeOverlay();
        } else if (btn[1].contains(x, y)) {
            Sound.sfx("sfx_click");
            a.showSettings(true);
        } else if (btn[2].contains(x, y)) {
            Sound.sfx("sfx_click");
            a.showMenu();
        } else if (!panelR.contains(x, y)) {
            a.closeOverlay();
        }
        return true;
    }
}
