package com.neighborvn;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

/** Магазин: бустеры (верхний ряд) и подарки (нижний ряд) за алмазы. */
final class ShopView extends View {
    private final MainActivity a;
    private final GameState gs;
    private final RectF backR = new RectF();
    private final RectF[] card = new RectF[6];
    private Paint bgP;

    ShopView(MainActivity a) {
        super(a);
        this.a = a;
        this.gs = a.gs;
        for (int i = 0; i < 6; i++) card[i] = new RectF();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        bgP = new Paint();
        bgP.setShader(new LinearGradient(0, 0, 0, h, 0xFF3B3355, 0xFF1F2A44, Shader.TileMode.CLAMP));
        backR.set(w * 0.02f, h * 0.03f, w * 0.14f, h * 0.11f);
        float cw = w * 0.28f, gap = (w - 3 * cw) / 4f;
        for (int i = 0; i < 6; i++) {
            int row = i / 3, col = i % 3;
            float x = gap + col * (cw + gap);
            float y = row == 0 ? h * 0.18f : h * 0.58f;
            card[i].set(x, y, x + cw, y + h * 0.36f);
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawRect(0, 0, w, h, bgP);
        Ui.button(c, backR, "← Назад", 0xAA000000, 0xFFFFFFFF, h * 0.04f);
        Ui.centerText(c, "Магазин", w * 0.5f, h * 0.07f, Ui.text(0xFFFFFFFF, h * 0.065f, true));
        Ui.centerText(c, "💎 " + gs.diamonds(), w * 0.88f, h * 0.07f, Ui.text(0xFFFFFFFF, h * 0.055f, true));
        Ui.centerText(c, "Бустеры", w * 0.08f, h * 0.15f, Ui.text(0xCCFFFFFF, h * 0.035f, true));
        Ui.centerText(c, "Подарки", w * 0.08f, h * 0.55f, Ui.text(0xCCFFFFFF, h * 0.035f, true));

        for (int i = 0; i < 6; i++) {
            boolean booster = i < 3;
            int k = i % 3;
            RectF r = card[i];
            c.drawRoundRect(r, 28f, 28f, Ui.fill(0xFF4A4468));
            Ui.centerText(c, booster ? Data.BOOST_ICON[k] : Data.GIFT_ICON[k], r.centerX(),
                    r.top + r.height() * 0.24f, Ui.text(0xFFFFFFFF, r.height() * 0.28f, false));
            Ui.centerText(c, booster ? Data.BOOST_NAME[k] : Data.GIFT_NAME[k], r.centerX(),
                    r.top + r.height() * 0.48f, Ui.text(0xFFFFFFFF, h * 0.042f, true));
            Ui.centerText(c, booster ? Data.BOOST_DESC[k] : Data.GIFT_DESC[k], r.centerX(),
                    r.top + r.height() * 0.62f, Ui.text(0xCCFFFFFF, h * 0.032f, false));
            int price = booster ? Data.BOOST_PRICE[k] : Data.GIFT_PRICE[k];
            int have = booster ? gs.booster(k) : gs.gift(k);
            Ui.centerText(c, "💎 " + price + "    есть: " + have, r.centerX(),
                    r.top + r.height() * 0.84f, Ui.text(0xFFFFD54F, h * 0.04f, true));
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) return true;
        if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
        float x = e.getX(), y = e.getY();
        if (backR.contains(x, y)) {
            a.showMap();
            return true;
        }
        for (int i = 0; i < 6; i++) {
            if (card[i].contains(x, y)) {
                buy(i);
                return true;
            }
        }
        return true;
    }

    private void buy(int i) {
        boolean booster = i < 3;
        int k = i % 3;
        int price = booster ? Data.BOOST_PRICE[k] : Data.GIFT_PRICE[k];
        if (!gs.spend(price)) {
            Toast.makeText(a, "Не хватает алмазов", Toast.LENGTH_SHORT).show();
            return;
        }
        if (booster) gs.addBooster(k, 1);
        else gs.addGift(k, 1);
        Toast.makeText(a, "Куплено: " + (booster ? Data.BOOST_NAME[k] : Data.GIFT_NAME[k]),
                Toast.LENGTH_SHORT).show();
        invalidate();
    }
}
