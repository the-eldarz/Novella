package com.neighborvn;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.text.TextPaint;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

/** Магазин в стиле оригинала: сетка фиолетовых карточек на розовом узорном фоне. */
final class ShopView extends View {
    private static final int COUNT = 7;
    private static final String[] ICON = {Data.BOOST_ICON[0], Data.BOOST_ICON[1], Data.BOOST_ICON[2], "🎟",
            Data.GIFT_ICON[0], Data.GIFT_ICON[1], Data.GIFT_ICON[2]};
    private static final String[] NAME = {Data.BOOST_NAME[0], Data.BOOST_NAME[1], Data.BOOST_NAME[2], "Жетон казино",
            Data.GIFT_NAME[0], Data.GIFT_NAME[1], Data.GIFT_NAME[2]};
    private static final String[] DESC = {Data.BOOST_DESC[0], Data.BOOST_DESC[1], Data.BOOST_DESC[2],
            "Одно вращение колеса в казино", Data.GIFT_DESC[0], Data.GIFT_DESC[1], Data.GIFT_DESC[2]};
    private static final int[] PRICE = {Data.BOOST_PRICE[0], Data.BOOST_PRICE[1], Data.BOOST_PRICE[2],
            Data.TOKEN_PRICE, Data.GIFT_PRICE[0], Data.GIFT_PRICE[1], Data.GIFT_PRICE[2]};

    private final MainActivity a;
    private final GameState gs;
    private final RectF panelR = new RectF(), curR = new RectF();
    private final RectF[] card = new RectF[COUNT];
    private final RectF[] bR = new RectF[3];
    private Bitmap bg;

    ShopView(MainActivity a) {
        super(a);
        this.a = a;
        this.gs = a.gs;
        for (int i = 0; i < COUNT; i++) card[i] = new RectF();
        for (int i = 0; i < 3; i++) bR[i] = new RectF();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        bg = Hud.pattern(w, h, 0xFFE9B8DD, 0xFFF1C9E8, 0xFFF6D8F0);
        panelR.set(w * 0.07f, h * 0.05f, w * 0.88f, h * 0.84f);
        float gap = w * 0.012f;
        float cw = (panelR.width() - gap * 4f) / 3f;
        float ch = (panelR.height() - gap * 4f) / 3f;
        for (int i = 0; i < COUNT; i++) {
            int row = i / 3, col = i % 3;
            float x = panelR.left + gap + col * (cw + gap);
            float y = panelR.top + gap + row * (ch + gap);
            card[i].set(x, y, x + cw, y + ch);
        }
        curR.set(w * 0.74f, h * 0.90f, w * 0.99f, h * 0.99f);
        float bw = w * 0.075f;
        for (int i = 0; i < 3; i++) {
            bR[i].set(w * 0.34f + i * bw * 1.05f, h * 0.885f, w * 0.34f + i * bw * 1.05f + bw, h * 0.97f);
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawBitmap(bg, 0, 0, null);
        Hud.backChevron(c, new RectF(w * 0.012f, h * 0.36f, w * 0.04f, h * 0.60f));

        c.drawRoundRect(panelR, 30f, 30f, Ui.fill(0xFF8E8EA0));
        RectF in = new RectF(panelR);
        in.inset(w * 0.004f, w * 0.004f);
        c.drawRoundRect(in, 28f, 28f, Ui.fill(0xFFD6D6E4));

        for (int i = 0; i < COUNT; i++) {
            RectF r = card[i];
            Ui.plate(c, r, 0xFF9B63C8, 26f);
            float ch = r.height();
            Ui.centerText(c, ICON[i], r.left + ch * 0.45f, r.centerY(), Ui.text(0xFFFFFFFF, ch * 0.42f, false));
            float tx = r.left + ch * 0.9f;
            float tw = r.right - tx - ch * 0.08f;
            TextPaint np = Ui.text(0xFFFFFFFF, ch * 0.17f, true);
            while (np.measureText(NAME[i]) > tw && np.getTextSize() > 8f) np.setTextSize(np.getTextSize() - 1f);
            np.setTextAlign(android.graphics.Paint.Align.LEFT);
            c.drawText(NAME[i], tx, r.top + ch * 0.26f, np);
            Ui.wrapped(c, DESC[i], tx, r.top + ch * 0.32f, (int) tw, Ui.text(0xFFF0E6FF, ch * 0.105f, false));
            Ui.outlined(c, PRICE[i] + " 💎", r.right - ch * 0.5f, r.bottom - ch * 0.17f, ch * 0.17f,
                    0xFFFFFFFF, 0xFF5A2D8C);
            Ui.outlined(c, "есть: " + owned(i), r.left + ch * 0.45f, r.bottom - ch * 0.17f, ch * 0.11f,
                    0xFFFFFFFF, 0xFF5A2D8C);
        }

        Hud.boosters(c, bR, gs, h);
        Hud.currency(c, gs, curR.right, curR.centerY(), h * 0.055f);
    }

    private int owned(int i) {
        if (i < 3) return gs.booster(i);
        if (i == 3) return gs.tokens();
        return gs.gift(i - 4);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) return true;
        if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
        float x = e.getX(), y = e.getY();
        if (x < getWidth() * 0.07f && y > getHeight() * 0.30f && y < getHeight() * 0.66f) {
            a.showMap();
            return true;
        }
        for (int i = 0; i < COUNT; i++) {
            if (card[i].contains(x, y)) {
                buy(i);
                return true;
            }
        }
        return true;
    }

    private void buy(int i) {
        if (!gs.spend(PRICE[i])) {
            Toast.makeText(a, "Не хватает алмазов", Toast.LENGTH_SHORT).show();
            return;
        }
        if (i < 3) gs.addBooster(i, 1);
        else if (i == 3) gs.addTokens(1);
        else gs.addGift(i - 4, 1);
        Toast.makeText(a, "Куплено: " + NAME[i], Toast.LENGTH_SHORT).show();
        invalidate();
    }
}
