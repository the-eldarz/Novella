package com.neighborvn;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;

import java.util.HashMap;
import java.util.HashSet;

/**
 * Звук игры. Файлы кладутся в корень репозитория (или в assets) и подхватываются автоматически:
 *   музыка: music (одна на всю игру, играет по кругу без перезапуска; .mp3 / .ogg / .m4a / .wav)
 *   эффекты: sfx_click, sfx_pop, sfx_win, sfx_lose, sfx_next
 * Нет файла: просто тишина (или продолжает играть предыдущая музыка), игра не падает.
 * Громкость берётся из настроек (ползунки музыки и эффектов).
 */
final class Sound {
    private Sound() {}

    private static final String[] EXT = {".mp3", ".ogg", ".m4a", ".wav"};

    private static Context ctx;
    private static GameState gs;
    private static MediaPlayer mp;
    private static String curMusic = null;
    private static SoundPool pool;
    private static final HashMap<String, Integer> ids = new HashMap<>();
    private static final HashSet<String> missing = new HashSet<>();
    private static long lastSfx = 0;

    static void init(Context c, GameState g) {
        ctx = c.getApplicationContext();
        gs = g;
        if (pool == null) {
            pool = new SoundPool.Builder()
                    .setMaxStreams(6)
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build())
                    .build();
        }
    }

    /** Запускает зацикленную музыку. Если файла нет, текущая музыка не прерывается. */
    static void music(String base) {
        if (ctx == null) return;
        if (base.equals(curMusic) && mp != null) return;
        AssetFileDescriptor fd = open(base);
        if (fd == null) return;
        stopMusic();
        try {
            mp = new MediaPlayer();
            mp.setDataSource(fd.getFileDescriptor(), fd.getStartOffset(), fd.getLength());
            fd.close();
            mp.setLooping(true);
            float v = gs.music();
            mp.setVolume(v, v);
            mp.prepare();
            mp.start();
            curMusic = base;
        } catch (Exception ex) {
            stopMusic();
        }
    }

    static void stopMusic() {
        if (mp != null) {
            try { mp.stop(); } catch (Exception ex) { /* уже остановлен */ }
            mp.release();
            mp = null;
        }
        curMusic = null;
    }

    /** Короткий эффект. */
    static void sfx(String base) {
        if (ctx == null || pool == null) return;
        long now = System.currentTimeMillis();
        if (now - lastSfx < 40) return;
        lastSfx = now;
        Integer id = ids.get(base);
        if (id == null) {
            if (missing.contains(base)) return;
            AssetFileDescriptor fd = open(base);
            if (fd == null) {
                missing.add(base);
                return;
            }
            id = pool.load(fd, 1);
            ids.put(base, id);
            try { fd.close(); } catch (Exception ex) { /* ignore */ }
            return; // первый раз эффект только загружается, звучать начнёт со следующего
        }
        float v = gs.sfx();
        pool.play(id, v, v, 1, 0, 1f);
    }

    /** Загружает эффекты заранее, чтобы первый клик тоже звучал. */
    static void preload(String... names) {
        if (ctx == null || pool == null) return;
        for (String n : names) {
            if (ids.containsKey(n) || missing.contains(n)) continue;
            AssetFileDescriptor fd = open(n);
            if (fd == null) {
                missing.add(n);
                continue;
            }
            ids.put(n, pool.load(fd, 1));
            try { fd.close(); } catch (Exception ex) { /* ignore */ }
        }
    }

    /** Вызывается из настроек при движении ползунка музыки. */
    static void applyMusicVolume() {
        if (mp != null) {
            float v = gs.music();
            mp.setVolume(v, v);
        }
    }

    static void pause() {
        if (mp != null && mp.isPlaying()) mp.pause();
    }

    static void resume() {
        if (mp != null && !mp.isPlaying()) mp.start();
    }

    static void release() {
        stopMusic();
        if (pool != null) {
            pool.release();
            pool = null;
        }
        ids.clear();
    }

    private static AssetFileDescriptor open(String base) {
        for (String e : EXT) {
            try {
                return ctx.getAssets().openFd(base + e);
            } catch (Exception ex) {
                // пробуем следующее расширение
            }
        }
        return null;
    }
}
