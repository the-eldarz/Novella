package com.neighborvn;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

/**
 * Сцена благодарности. Сейчас это простая анимация-заглушка:
 * героиня подходит, появляется поцелуй и сердечки. Потом сюда можно вставить свой арт или видео.
 */
final class SceneView extends View {
    private final MainActivity a;
    private final Data.Level lv;
    private final Runnable done;
    private final long t0 = System.nanoTime();
    private long shift = 0L;
    private boolean k1, k2, k3;
    private final RectF r = new RectF();

    SceneView(MainActivity a, int level, Runnable done) {
        super(a);
        this.a = a;
        this.lv = Data.LEVELS[level];
        this.done = done;
    }

    private float time() {
        return (System.nanoTime() - t0 + shift) / 1e9f;
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        float t = time();

        Paint bg = new Paint();
        bg.setShader(new LinearGradient(0, 0, 0, h, 0xFF3A1F3F, 0xFFB5546B, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, bg);

        // Игрок (силуэт)
        float px = w * 0.30f;
        c.drawCircle(px, h * 0.30f, h * 0.08f, Ui.fill(0xFF1E1E33));
        r.set(px - h * 0.13f, h * 0.40f, px + h * 0.13f, h * 0.80f);
        c.drawRoundRect(r, h * 0.06f, h * 0.06f, Ui.fill(0xFF1E1E33));
        Ui.centerText(c, a.gs.name(), px, h * 0.86f, Ui.text(0xFFFFFFFF, h * 0.05f, true));

        // Героиня подходит
        float p = Math.min(1f, t / 1.2f);
        float e = 1f - (1f - p) * (1f - p);
        float grow = 1f + 0.06f * Math.min(1f, Math.max(0f, (t - 1.2f) / 0.8f));
        if (lv.heroine == 3) {
            for (int i = 0; i < 3; i++) {
                float cx = w * (0.54f + 0.18f * i) + (1f - e) * w * 0.2f;
                float pw = w * 0.15f * grow, ph = h * 0.6f * grow;
                r.set(cx - pw / 2f, h * 0.50f - ph / 2f, cx + pw / 2f, h * 0.50f + ph / 2f);
                Ui.portrait(c, r, Data.HCOLORS[i], Data.HINIT[i], Data.HNAMES[i]);
            }
        } else {
            float cx = w * 0.80f + (w * 0.58f - w * 0.80f) * e;
            float pw = w * 0.24f * grow, ph = h * 0.78f * grow;
            r.set(cx - pw / 2f, h * 0.50f - ph / 2f, cx + pw / 2f, h * 0.50f + ph / 2f);
            Ui.portrait(c, r, Data.HCOLORS[lv.heroine], Data.HINIT[lv.heroine], Data.HNAMES[lv.heroine]);
        }

        // Поцелуй и сердечки
        if (t > 1.8f) {
            float s = Math.min(1f, (t - 1.8f) * 4f);
            Ui.centerText(c, "💋", w * 0.42f, h * 0.38f, Ui.text(0xFFFFFFFF, h * 0.12f * s, false));
        }
        if (t > 1.8f && !k1) { k1 = true; a.hearts.burst(w * 0.45f, h * 0.40f, 14); }
        if (t > 2.3f && !k2) { k2 = true; a.hearts.burst(w * 0.50f, h * 0.35f, 14); }
        if (t > 2.8f && !k3) { k3 = true; a.hearts.burst(w * 0.40f, h * 0.35f, 14); }

        // Подпись
        if (t > 2.4f) {
            float al = Math.min(1f, (t - 2.4f) / 0.6f);
            r.set(w * 0.06f, h * 0.84f, w * 0.94f, h * 0.97f);
            Paint boxP = Ui.fill(0xFFFFFFFF);
            boxP.setAlpha((int) (235 * al));
            c.drawRoundRect(r, 30f, 30f, boxP);
            android.text.TextPaint tp = Ui.text(0xFF2B2D42, h * 0.045f, false);
            tp.setAlpha((int) (255 * al));
            Ui.wrapped(c, lv.scene, r.left + w * 0.02f, r.top + h * 0.015f, (int) (r.width() - w * 0.04f), tp);
        }
        if (t > 3.2f) {
            Ui.centerText(c, "Нажми, чтобы продолжить", w * 0.5f, h * 0.80f,
                    Ui.text(0xCCFFFFFF, h * 0.04f, false));
        }
        postInvalidateOnAnimation();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) return true;
        if (e.getActionMasked() == MotionEvent.ACTION_UP) {
            float t = time();
            if (t < 3.2f) {
                shift += (long) ((3.3f - t) * 1e9f);
                invalidate();
            } else {
                done.run();
            }
        }
        return true;
    }
}
