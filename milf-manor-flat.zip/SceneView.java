package com.neighborvn;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

/**
 * Подсцена благодарности: простая анимация-заглушка без подписей (stage 0, 1, 2).
 * Героиня подходит и появляется значок: искры, сердце, поцелуй. Потом можно вставить свой арт или видео.
 */
final class SceneView extends View {
    private final MainActivity a;
    private final Data.Level lv;
    private final int level, stage;
    private static final float[] END_X = {0.68f, 0.62f, 0.58f};
    private static final String[] SYMBOL = {"[i:sparkle]", "[i:heart_outline]", "[i:lips]"};
    private final long t0 = System.nanoTime();
    private long shift = 0L;
    private boolean k1, k2, k3;
    private final RectF r = new RectF();

    SceneView(MainActivity a, int level, int stage) {
        super(a);
        this.a = a;
        this.level = level;
        this.stage = Math.max(0, Math.min(2, stage));
        this.lv = Data.LEVELS[level];
    }

    private float time() {
        return (System.nanoTime() - t0 + shift) / 1e9f;
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        float t = time();

        Paint bg = new Paint();
        bg.setShader(new LinearGradient(0, 0, 0, h, 0xFF3A1F3F, 0xFFB5546B, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, bg);

        // Игрок (силуэт)
        float px = w * 0.30f;
        c.drawCircle(px, h * 0.30f, h * 0.08f, Ui.fill(0xFF1E1E33));
        r.set(px - h * 0.13f, h * 0.40f, px + h * 0.13f, h * 0.80f);
        c.drawRoundRect(r, h * 0.06f, h * 0.06f, Ui.fill(0xFF1E1E33));
        Ui.centerText(c, a.gs.name(), px, h * 0.86f, Ui.text(0xFFFFFFFF, h * 0.05f, true));

        // Героиня подходит
        float p = Math.min(1f, t / 1.2f);
        float e = 1f - (1f - p) * (1f - p);
        float grow = 1f + 0.06f * Math.min(1f, Math.max(0f, (t - 1.2f) / 0.8f));
        {
            float cx = w * 0.80f + (w * END_X[stage] - w * 0.80f) * e;
            float pw = w * 0.24f * grow, ph = h * 0.78f * grow;
            r.set(cx - pw / 2f, h * 0.50f - ph / 2f, cx + pw / 2f, h * 0.50f + ph / 2f);
            Ui.figure(c, r, lv.heroine);
        }

        // Поцелуй и сердечки
        if (t > 1.8f) {
            float s = Math.min(1f, (t - 1.8f) * 4f);
            Ui.centerText(c, SYMBOL[stage], w * 0.42f, h * 0.38f, Ui.text(0xFFFFFFFF, h * 0.12f * s, false));
        }
        if (t > 1.8f && !k1) { k1 = true; a.hearts.burst(w * 0.45f, h * 0.40f, 14); }
        if (stage >= 1 && t > 2.3f && !k2) { k2 = true; a.hearts.burst(w * 0.50f, h * 0.35f, 14); }
        if (stage >= 2 && t > 2.8f && !k3) { k3 = true; a.hearts.burst(w * 0.40f, h * 0.35f, 14); }

        postInvalidateOnAnimation();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) return true;
        if (e.getActionMasked() == MotionEvent.ACTION_UP) {
            float t = time();
            if (t < 3.2f) {
                shift += (long) ((3.3f - t) * 1e9f);
                invalidate();
            }
        }
        return true;
    }
}
